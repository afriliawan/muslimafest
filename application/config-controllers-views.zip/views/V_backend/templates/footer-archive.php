      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Hops <?= date('Y'); ?></span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="<?= base_url('C_auth'); ?>">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
  <script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?= base_url('assets/'); ?>vendor/jquery-easing/jquery.easing.min.js"></script>
  <!-- <script type="text/javascript" src="jquery-1.4.js"></script> -->
  <script type="text/javascript">
    $(document).ready(function() {
    $('#max_nohp').keyup(function() {
    var len = this.value.length;
    if (len >= 12) {
    this.value = this.value.substring(0, 13);
    }
    });
    });
  </script>

  <!--Bootstrap AdminLTE-->
  
<!-- jQuery -->
<script src="<?=base_url('assets/adminLTE/'); ?>plugins/jquery/jquery.min.js"></script>
<script src="<?=base_url('assets/'); ?>js/jquery-3.5.1.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!--Token Field-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tokenfield/0.12.0/bootstrap-tokenfield.js"></script>  
<!-- Bootstrap 4 -->
<script src="<?=base_url('assets/adminLTE/'); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url('assets/adminLTE/'); ?>dist/js/adminlte.min.js"></script>
<!-- Page level plugins -->
<script src="<?=base_url('assets/'); ?>vendor/chart.js/Chart.min.js"></script>
<script src="<?=base_url('assets/'); ?>js/demo/chart-area-demo.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=base_url('assets/adminLTE/'); ?>dist/js/demo.js"></script>
<!-- Summernote -->
<script src="<?=base_url('assets/adminLTE/'); ?>plugins/summernote/summernote-bs4.min.js"></script>
<script src="<?=base_url('assets/'); ?>js/image-picker.js"></script>
<script src="<?=base_url('assets/'); ?>js/image-picker.min.js"></script>
<script>
  $(function () {
    // Summernote
    $('.textarea').summernote()
  })
</script>


<script src="<?= base_url('assets/'); ?>dataTables/datatables.min.js"></script>
<script>
      $('.custom-file-input').on('change', function() {
        let fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
      }); //JQuery mencari custom file input, lalu ketika kita ubah isinya, ambil nama filenya lalu nama filenya simpan kedalam isi dari input ini

      $(document).ready( function () {
    $('#dataTable').DataTable();
} );
  </script>

<script>
    $('.image-picker').imagepicker();
</script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myDIV *").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<script>
    $(document).ready(function() {
        // Untuk sunting
        $('#edit-data-user').on('show.bs.modal', function(event) {
            var div = $(event.relatedTarget) // Tombol dimana modal di tampilkan
            var modal = $(this)

            // Isi nilai pada field
            modal.find('#id').attr("value", div.data('id'));
            modal.find('#name').attr("value", div.data('name'));
            modal.find('#slug').attr("value", div.data('slug'));
        });
    });
</script>

<script>
  $(document).ready(function(){
      
    $('#search_data').tokenfield({
        autocomplete :{
            source: function(request, response)
            {
                jQuery.get('https://beta.hops.id/wp-json/wp/v2/tags', {
                    search : request.term,
                    per_page : 5,

                }, function(data){
                    // jsonData = JSON.parse(data);
                  console.log(data);
                    i=0;
                    tag = [];
                    while(i<data.length-1){
                        tag[i]=data[i].name
                      i++;
                    }
                    console.log(tag);
                    response(tag);
                });
            },
            delay: 100
        }
    });

    $('#search').click(function(){
        $('#country_name').text($('#search_data').val());
    });

  });
</script>