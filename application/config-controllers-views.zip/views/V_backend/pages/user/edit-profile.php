<section class="grid">
    <article>
		<div class="title-article">Ubah Profil</div>
	
		<div class="box-article pwd">
			<div class="auth-field">
			<?= form_open_multipart('C_user/editProfile'); ?>
				<!-- <div class="row-full">
					<label>Username:</label>
					<input readonly type="text" id="username" name="username" placeholder="Boy Suroboy" style="color: #7A7A7A;">
				</div>
				<div class="row-full" style="margin-top: 20px;">
					<label>Email:</label>
					<input readonly type="text" id="email" name="email" placeholder="boysuro@gmail.com" style="color: #7A7A7A;">
				</div> -->
				<div class="row-full" style="margin-top: 20px;">
					<label>Nama Lengkap:</label>
					<input type="text" id="name" name="name" value="<?= $user['name']; ?>" placeholder="Masukkan nama lengkap..">
				</div>
				<!-- <div class="r<section class="grid">
    <article>
		<div class="title-article">Ubah Profil</div>
	
		<div class="box-article pwd">
			<div class="auth-field">
			<?= form_open_multipart('C_user/editProfile'); ?>
				<!-- <div class="row-full">
					<label>Username:</label>
					<input readonly type="text" id="username" name="username" placeholder="Boy Suroboy" style="color: #7A7A7A;">
				</div>
				<div class="row-full" style="margin-top: 20px;">
					<label>Email:</label>
					<input readonly type="text" id="email" name="email" placeholder="boysuro@gmail.com" style="color: #7A7A7A;">
				</div> -->
				<div class="row-full" style="margin-top: 20px;">
					<label>Nama Lengkap:</label>
					<input type="text" id="name" name="name" value="<?= $user['name']; ?>" placeholder="Masukkan nama lengkap..">
				</div>
				<div class="row-full" style="margin-top: 20px;">
					<label>No. HP:</label>
					<input type="text" id="mobile-no" name="mobile-no" placeholder="Nomor HP..">
				</div>
				<div class="row-full" style="margin-top: 20px;">
					<label>No. KTP:</label>
					<input type="text" id="ktp-no" name="ktp-no" placeholder="Nomor KTP..">
				</div>
				<div class="row-full" style="margin-top: 20px;">
					<label>No. Rekening:</label>
					<input type="text" id="rek-no" name="rek-no" placeholder="Nomor rekening..">
				</div>
				<div class="row-full" style="margin-top: 50px;">
					<div class="content">
						<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
						
						<div class="box-input">
								<labels>Foto profil :</labels>
							<form id="form1" style="margin-right: 147px;" runat="server">
								<input type="file" style="margin-left:-166px;"  name="thumbnail" id="file-7" accept="image/*" class="inputfile inputfile-6" data-multiple-caption="{count} files selected" multiple/>
								<label for="file-7" style="width:1000px;margin-top:-20px!important;margin-right:-134px;"></label>
							</div>
						</div>
					</div>
					<!-- /container -->
				<div class="row-full" style="margin-top: 50px; text-align:right;">
				 <input type="submit" value="Simpan" style="width: 140px;;">
				 </div>
			</div>
			</form>
		</div>
	</article>
  </section>