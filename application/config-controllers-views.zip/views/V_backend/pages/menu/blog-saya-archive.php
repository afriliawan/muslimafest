
  <!------------------------------------------------------------------------------- Kolom Kanan START --------------------------------------------------------------------------->
  <section class="grid">
    <article>
		<div class="title-article">Blog Saya</div>
		<div class="row-full">
			<a href="<?= base_url('C_menu/formCreateBlog'); ?>"><input type="submit" value="Tulis" style="width:200px;"></a>
		</div>
		<div style="margin-top:20px;"></div>
		<div class="row-full"><!--row full start-->
			<div class="kol-left top" style="height:50px;">
				<span style="margin-right:20px;">Show</span>
    				<div class="custom-select" style="width:60px;">
  						<select>
    					<option value="0">10</option>
    					<option value="1">20</option>
    					<option value="2">30</option>
    					<option value="3">40</option>
    					<option value="4">50</option>
  						</select>
					</div>
				<span style="margin-left:10px;">entries</span>
			</div>
			
			<div class="kol-right top" style="height:50px;">
				<div class="search-small">
    				<form>
      					<input type="search" placeholder="Search artikel ...">
      					<button type="submit" aria-label="submit form">
        					<i class="fa fa-search" aria-hidden="true" style="font-size:18px;"></i>
      					</button>
    				</form>
				</div>
			</div>
		</div><!--row full end-->
		
		<div class="row-full"><!-- row full start -->
			<!-- Tabel Start -->
			<div class="table-users">
   				<table cellspacing="0">
								
      				<tr>
	  	 				<th style="font-weight:bold;">No.</th>
         				<th style="font-weight:bold;">Thumbnail</th>
         				<th style="font-weight:bold;">Judul Berita</th>
         				<th style="font-weight:bold; text-align:left;">Author</th>
         				<th style="font-weight:bold;">Status</th>
         				<th style="font-weight:bold; width:150px;">Action</th>
      				</tr>
					  <?php
						$no = 1;
						foreach($hasil as $r){ ?>
      				<tr>
	  					<td><?= $no++ ?></td>
         				<td style="width: 120px;"><div class="thumb-img-holder" style="background-image:url(<?= $r->jetpack_featured_media_url; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></td>
         				<td class="judul-berita"><center><a href="<?= $r->link;?>"><?= $r->title->rendered; ?></center></td>
						<td><?= $r->author_detail->name; ?></td>
						<td>
							<?php if ( $r->status == "publish") {?>
                                <i class="fa fa-check" aria-hidden="true" style="color:#03B1BA;"> Publish</i>
                            <?php }else if ($r->status == "draft") { ?>
                                <i class="fa fa-exclamation-circle" style="color:#DC143C"> Pending</i>
                            <?php } ?>
						</td>
         				<td><a href="<?=base_url('C_menu/formEditBlog/') . $r->id; ?>"><input type="edit" class="btn-small" value="Edit"></a> <a href="<?=base_url('C_menu/deleteBlog/') . $r->id; ?>"><input type="edit" class="btn-small" value="Hapus"></td></a>
      				</tr>
					  <?php } ?>
   				</table>
			</div>
			<!-- Tabel END -->
		</div><!--row full end-->
		
		<div class="row-full mt20"><!--row full start-->
			<div class="kol-left btm" style="height:50px;">
				Showing <strong><span style="color:#03B1BA;">&nbsp;1&nbsp;</span> to <span style="color:#03B1BA;">&nbsp;10&nbsp;</span></strong> of 6 entries
			</div>
			<div class="kol-right btm --414" style="height:50px;">
				<a href="#"><span><i class="fa fa-angle-double-left" aria-hidden="true"></i> prev</span></a>&nbsp;<span class="info-hal">1</span>&nbsp;<a href="#"><span>next <i class="fa fa-angle-double-right" aria-hidden="true"></i></span></a>
			</div>
		</div><!--row full end-->
		
	</article>
  </section>
   <!------------------------------------------------------------------------------- Kolom Kanan END --------------------------------------------------------------------------->
  