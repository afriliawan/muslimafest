
  <!------------------------------------------------------------------------------- Kolom Kanan START --------------------------------------------------------------------------->
  <section class="grid">
    <article>
		<div class="title-article">Dashboard</div>
	
		<div class="box-article pwd">
			<div class="auth-field">
				<div class="row-full">
					<div style="margin-top:80px;"></div>
					<img src="<?=base_url('assets/backend/'); ?>img/pv.jpg" width="100%">
				</div>
				
				
				
				
			</div>
		</div>
	</article>
  </section>
   <!------------------------------------------------------------------------------- Kolom Kanan END --------------------------------------------------------------------------->
  