	<!--row-full 3 START-->
    <div class="row-full">
			<div class="footer-container">
				<div class="frow">
		 			<ul class="footer-teks">
						<a href="https://www.hops.id/tentang-kami/"><li>Tentang Kami</li></a>
						<a href="https://www.hops.id/disclaimer/"><li>Disclaimer</li></a>
						<a href="https://www.hops.id/pedoman-media-siber/"><li>Pedoman Media Siber</li></a>
						<a href="https://www.hops.id/kontak-kami/"><li>Kontak Kami</li></a>
						<a href="https://www.hops.id/karier/"><li>Info Karier</li></a>
						<a href="https://www.hops.id/indeks/"><li>Indeks</li></a>
					</ul>
				</div>
		
				<div class="frow">
					<div class="fcolumn-left">
   						<div class="c-center">
  							<a href="https://hops.id/" target="_blank" title="hops media" alt="hops media"><img src="<?= base_url('assets/frontend/');?>img/hopsmedia-logo-reverse.png" width=95></a>
						</div>
  					</div>
					<div class="fcolumn-middle">
    					<div class="c-center" style="display:block;">
  							<a href="https://hops.id/" target="_blank" title="hops.id" alt="hops.id"><div class="multibrand-holder">
								<img src="<?= base_url('assets/frontend/');?>img/hops-logo.png" width=75>
							</div></a>
							<a href="https://depoktoday.hops.id/" target="_blank" title="depok today" alt="depok today"><div class="multibrand-holder">
								<img src="<?= base_url('assets/frontend/');?>img/logo-depoktoday-reverse.png" width=125>
							</div></a>
							<a href="https://kulinear.hops.id/" target="_blank" title="kulinear" alt="kulinear"><div class="multibrand-holder">
								<img src="<?= base_url('assets/frontend/');?>img/logo-kulinear.png" width=135>
							</div></a>
							<a href="https://muslima.hops.id/" target="_blank" title="muslima" alt="muslima"><div class="multibrand-holder">
								<img src="<?= base_url('assets/frontend/');?>img/logo-muslima.png" width=125>
							</div></a>
							<a href="https://koreabanget.hops.id/" target="_blank" title="korea banget" alt="korea banget"><div class="multibrand-holder">
								<img src="<?= base_url('assets/frontend/');?>img/logo-koreabanget.png" width=135>
							</div></a>
							<a href="https://bisnika.hops.id/" target="_blank" title="bisnika" alt="bisnika"><div class="multibrand-holder">
								<img src="<?= base_url('assets/frontend/');?>img/logo-bisnika.png" width=115>
							</div></a>
							<a href="https://ceklissatu.com/" target="_blank" title="ceklis satu" alt="ceklis satu"><div class="multibrand-holder">
								<img src="<?= base_url('assets/frontend/');?>img/logo-ceklis-satu.png" width=155>
							</div></a>
						</div>
  					</div>
  			
					<!-- <div class="fcolumn-right">
    					<div class="c-center">
  							<p>subsidiary of <br><a href="https://surge.co.id/" target="_blank" title="surge" alt="surge"><img src="<?= base_url('assets/frontend/');?>img/logo-surge.png" width=85></a></p>
						</div>
  					</div> -->
				</div><!-- frow end -->
		
				<div class="frow">
		 			<div class="copyright">HopsID ©Copyright 2021 | All Right Reserved</div>
				</div>
			</div><!--footer-container END-->
			
		</div>
		<!--row-full 3 END-->
	
	
	
</div><!-- page-wrapper END -->




	<!-- socmed -sticky btm -->
	<div class="socmed-sticky-btm" id="socmed-sticky-bottom" style="display:none;">
	
	<?php foreach($hasil as $d){ ?>
		<?php } ?>
		<?php
			$slugnya = $hasilCategories[0]['slug'];
			$urlUGC = "https://ugc.hops.id/";
			$urlFB = "https://www.facebook.com/sharer.php?u=".$urlUGC.$slugnya;
		?>
		<a href="<?= $urlFB; ?>"><div class="socmed-item-sticky-btm facebook">
			<i class="fa fa-facebook" style="font-size:24px; color:#eee;"></i>
		</div></a>
		<?php
			$slugnya = $hasilCategories[0]['slug'];
			$urlUGC = "https://ugc.hops.id/";
			$title = $d->title->rendered;
			$urlTwitter = "https://twitter.com/intent/tweet?text=".$title."&url=".$urlUGC.$slugnya;
		?>
		<a href="<?= $urlTwitter; ?>"><div class="socmed-item-sticky-btm twitter">
			<i class="fa fa-twitter" style="font-size:24px; color:#eee;"></i>
		</div></a>
		<?php
			$slugnya = $hasilCategories[0]['slug'];
			$urlUGC = "https://ugc.hops.id/";
			$title = $d->title->rendered;
			$urlWhatsapp = "https://api.whatsapp.com/send?text=".$title." ".$urlUGC.$slugnya;
		?>
		
		<a href="<?= $urlWhatsapp; ?>"><div class="socmed-item-sticky-btm whatsap">
			
			<i class="fa fa-whatsapp" style="font-size:24px; color:#eee;"></i>
		</div></a>
	</div>
	<!-- socmed -sticky btm -->
	
	
	
	
	<script>

	var socmedshare = document.getElementById("socmed-sticky-bottom");
	window.onscroll = function() {scrollFunction()};

	function scrollFunction() {
  		if (document.body.scrollTop > 700 || document.documentElement.scrollTop > 700) {
    		socmedshare.style.display = "block",
			socmedshare.animate({'opacity':'1'},6000);
  		} else {
    		socmedshare.style.display = "none",
			socmedshare.animate({'opacity':'0'},6000);
  		}
	}

	</script>
	
</body>
</html>
