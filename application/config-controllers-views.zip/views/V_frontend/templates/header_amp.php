<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="description" content="Portal berita yang memfasilitasi ide kreatif tulisan kaum milenial"/>
<meta name="keywords" content="Trending, Unik, Hot, Hobi, Viral, Hops" />
<meta name="news_keywords" content="Trending, Unik, Hot, Hobi, Viral, Hops" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- <meta name="alexaVerifyID" content="iUEjKUBkewgkmEAaGPeYTWn-9Fs"/>
<meta name="google-site-verification" content="xgzlpTB4aNO3Ni2ORbt0wUhTYGUXYWJhNQcfVW9Ojd0" />
<meta name="msvalidate.01" content="1B16805CD55947D66898660751F492B8" />  -->
<meta name="googlebot-news" content="index,follow" />
<meta name="googlebot" content="index,follow" />
<meta name="robots" content="index,follow,max-image-preview:large">
<meta name="language" content="id" />
<meta name="geo.country" content="id" />
<meta http-equiv="content-language" content="In-Id" />
<meta name="geo.placename" content="Indonesia" />
<meta name="theme-color" content="#ff0000">
<!-- <meta property="fb:app_id" content="802054763141639"/>
<meta property="fb:pages" content="636794109715023" /> -->
<meta property="og:title" content="UGC HOPSID" >
<meta property="og:description" content="Portal berita yang memfasilitasi ide kreatif tulisan kaum milenial" >
<meta property="og:type" content="article" />
<meta property="og:url" content="https://ugc.hops.id/" >
<meta property="og:image" content="https://i2.wp.com/www.hops.id/wp-content/uploads/2020/02/hops-logo.png" >
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="970">
<meta property="og:image:height" content="544">
<meta property="og:site_name" content="ugc.hops.id" >
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:site" content="ugc.hops.id" />
<meta name="twitter:title" content="ugc.hops.id - Viral and Trending">
<meta name="twitter:description" content="Portal berita yang memfasilitasi ide kreatif tulisan kaum milenial">
<meta name="twitter:image" content="https://i2.wp.com/www.hops.id/wp-content/uploads/2020/02/hops-logo.png">
<meta name="twitter:image:src" content="https://i2.wp.com/www.hops.id/wp-content/uploads/2020/02/hops-logo.png">
<link rel="image_src" href="https://i2.wp.com/www.hops.id/wp-content/uploads/2020/02/hops-logo.png" />
<link rel="canonical" href="https://ugc.hops.id/" />

<meta http-equiv="refresh" content="900">
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "WebSite",
  "url": "https://ugc.hops.id/",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://ugc.hops.id/search?q={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
</script>

<link href="<?= base_url('assets/frontend/');?>css/style.css" rel="stylesheet" type="text/css" media="all">
<link href="<?= base_url('assets/frontend/');?>css/mobile.css" rel="stylesheet" type="text/css" media="all">

<link rel="stylesheet" href="<?= base_url('assets/frontend/');?>font-awesome-4.7.0/css/font-awesome.css">
<link rel="stylesheet" href="<?= base_url('assets/frontend/');?>font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tokenfield/0.12.0/css/bootstrap-tokenfield.min.css">

<title><?= $title; ?></title>
</head>
<body style="color:#aaaaaa;">

<div class="page-wrapper"><!-- page-wrapper START -->
	
	<header>
		<div class="header-center">
			<a href="<?= base_url(''); ?>"><img src="<?= base_url('assets/frontend/');?>img/hops-logo.png" width=112></a>
		</div>
	</header>
	