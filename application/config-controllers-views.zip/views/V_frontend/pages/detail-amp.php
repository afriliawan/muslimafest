
	<!-- content-wrapper START -->
	<div class="content-wrapper" style="overflow:auto; clear:both;">
		<!---------------------------------------------------------- ------------------------------- col-left START ------------------------------------------------------------------------------------->
		<?php foreach($hasil as $d){ ?>
		<div class="col-center">
		<a href="<?= base_url(''); ?><?= strtolower($d->cat_detail[0]->name); ?>"><div class="title-detail"><?= $d->cat_detail[0]->name; ?></div></a>
			<h1 class="headline-title-teks detail"><?= $d->title->rendered; ?></h1>
            
				<div class="author">
					<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
						</div>
					</div>
					<div class="author-right">
						<div class="author-name detail"><?= $d->author_detail->name; ?></div>
                        <?php
							$UTC = strtotime($d->date_gmt);
						?>
						<div class="date detail">| <?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
				</div>
				
				<div style="margin-top:40px;"></div>
				
				<!-- <a href="https://news.google.com/publications/CAAqBwgKMLv0lAswsMeqAw?hl=id&gl=ID&ceid=ID%3Aid" target="_blank"><div class="btn-gnews"><img src="<?= base_url('assets/frontend/'); ?>img/icon-gnews.png" width=35 style="margin-top: -7px;">&nbsp;&nbsp;ikuti kami di Google News</div></a> -->
				
				<div style="margin-top:20px;"></div>
			
				<section class="valign bottom headline detail" style="background-image:url(<?= $d->jetpack_featured_media_url; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
					<div class="headline-title-box detail">
						<div class="photo-credit">Foto: Instagram</div>
					</div>
				</section>
			
			
			
			<div style="margin-top:20px;"></div>
				
				
				<!-- Start Content Artikel -->
				<div class="content-artikel">
				<!--Replace Width dan Height, perlu disetting height="100%"; -->
				<?= preg_replace('#(<img.+?)width=100%(["\']?)\d*\2(.*?/?>)#i', '$1$3',preg_replace('#(<img.+?)height=(["\']?)\d*\2(.*?/?>)#i', '$1$3', $d->content->rendered));
                ?>
				
				<!-- Baca Juga START -->
				<div class="title-section">Baca Juga</div>
				
				
				<div class="row-list bacajuga">
					<!---- List ---->
					<div class="row-list rightcol bacajuga">
						<div class="kol-separuh-rightcol left">
						<?php
							$idBerita = $hasilCategories[0]['id'];
							$slugnya = $hasilCategories[0]['slug'];
						?>
						<a href="<?= base_url('/') . $slugnya; ?>">
							<div class="img-holder" style="background-image:url(<?= $hasilCategories[0]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
						</div>
				
						<div class="kol-separuh-rightcol right">
							<!--<div class="author">
								<div class="author-name small"><span>Unik</span>&nbsp; | &nbsp;Debby Harry</div>
								<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
							</div>-->
							<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $hasilCategories[0]['title']['rendered'];?></p></a>
						</div>
					</div>
					<!---- List ---->
			
					<!---- List ---->
					<div class="row-list rightcol bacajuga">
						<div class="kol-separuh-rightcol left">
						<?php
							$idBerita = $hasilCategories[1]['id'];
							$slugnya = $hasilCategories[1]['slug'];

						?>
						<a href="<?= base_url('/') . $slugnya; ?>">
							<div class="img-holder" style="background-image:url(<?= $hasilCategories[1]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
						</div>
				
						<div class="kol-separuh-rightcol right">
							<!--<div class="author">
								<div class="author-name small"><span>Unik</span>&nbsp; | &nbsp;Debby Harry</div>
								<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
							</div>-->
							<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $hasilCategories[1]['title']['rendered'];?></p></a>
						</div>
					</div>
					<!---- List ---->
					
					<!---- List ---->
					<div class="row-list rightcol bacajuga">
						<div class="kol-separuh-rightcol left">
						<?php
							$idBerita = $hasilCategories[2]['id'];
							$slugnya = $hasilCategories[2]['slug'];
						?>
						<a href="<?= base_url('/') . $slugnya; ?>">
							<div class="img-holder" style="background-image:url(<?= $hasilCategories[2]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
						</div>
				
						<div class="kol-separuh-rightcol right">
							<!--<div class="author">
								<div class="author-name small"><span>Unik</span>&nbsp; | &nbsp;Debby Harry</div>
								<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
							</div>-->
							<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $hasilCategories[2]['title']['rendered'];?></p></a>
						</div>
					</div>
					<!---- List ---->
			
					<!---- List ---->
					<div class="row-list rightcol bacajuga">
						<div class="kol-separuh-rightcol left">
						<?php
							$idBerita = $hasilCategories[3]['id'];
						?>
						<a href="<?= base_url('/') . $slugnya; ?>">
							<div class="img-holder" style="background-image:url(<?= $hasilCategories[3]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
						</div>
				
						<div class="kol-separuh-rightcol right">
							<!--<div class="author">
								<div class="author-name small"><span>Unik</span>&nbsp; | &nbsp;Debby Harry</div>
								<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
							</div>-->
							<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $hasilCategories[3]['title']['rendered'];?></p></a>
						</div>
					</div>
					<!---- List ---->
					
					
				</div>
				<!-- Baca Juga END -->
				
				<div style="margin-top:90px;"></div>
				</div>
				<!-- End Content Artikel -->
				
				<div style="margin-top:30px;"></div>

				<div class="list-topik">
					<div class="label-topik"><img src="<?= base_url('assets/frontend/'); ?>img/label-topik.png" width=70></div>
					<?php
								$tags = $d->tag_detail;
								$a = "";
								$i = 0;
								
								foreach ($tags as $allTags) {
									if($i==0){
										$a = '<li class="topik">' . $allTags->name . '</li>';
									} else {
										$a = $a . ',' . '<li class="topik">' . $allTags->name . '</li>';
									}
									$i++;
								}
					?>
					<ul>
						<?= $a; ?>
					</ul>
				</div>
				
				<div style="margin-top:30px;"></div>
				
				<div class="share-box">
					<div class="label-share"><img src="<?= base_url('assets/frontend/'); ?>img/icon-share.png" width=24>&nbsp;&nbsp;share</div>
					<div class="share-holder">
						<ul>
							<li class="socmed-item-square facebook">
								<i class="fa fa-facebook" style="font-size:16px; color:#eee;"></i>
							</li>
							<li class="socmed-item-square twitter">
								<i class="fa fa-twitter" style="font-size:16px; color:#eee;"></i>
							</li>
							<li class="socmed-item-square linkedin">
								<i class="fa fa-linkedin" style="font-size:16px; color:#eee;"></i>
							</li>
							<li class="socmed-item-square get-pocket">
								<i class="fa fa-get-pocket" style="font-size:16px; color:#eee;"></i>
							</li>
							<li class="socmed-item-square">
								<i class="fa fa-envelope" style="font-size:16px; color:#eee;"></i>
							</li>
							<li class="socmed-item-square">
								<i class="fa fa-print" style="font-size:16px; color:#eee;"></i>
							</li>
						</ul>
					</div>
				</div>
				
				<div style="margin-top:30px;"></div>
			
			
			
  	<?php } ?>
		<!---------------------------------------------------------- ------------------------------- col-left END -------------------------------------------------------------------------------------->

	</div>
	<!-- content-wrapper END -->