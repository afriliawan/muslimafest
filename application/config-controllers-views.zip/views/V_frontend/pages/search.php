
	<!-- content-wrapper START -->
	<div class="content-wrapper" style="overflow:auto; clear:both;">
		
		<!---------------------------------------------------------- ------------------------------- col-left START ------------------------------------------------------------------------------------->
		<div class="col-left">
			<div class="title-kanal">Search</div>
			
			
			<div style="margin-top:20px;"></div>
	
	<?php foreach($hasil as $d){ ?>
			<!---- List biasa Kanal---->
    		<div class="listbox">
				<div class="listbox-left">
				<?php
					$idBerita = $d->id;
				?>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><div class="img-holder" style="background-image:url(<?= $d->jetpack_featured_media_url; ?>img/img-artikel-3.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
							<div class="author-name"><?= $d->author_detail->name; ?></div>
							<?php
								$UTC = strtotime($d->date_gmt);
							?>
							<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><p class="headline-title-teks medium"><?= $d->title->rendered; ?></a>
					<div class="desc small">
						<p><?= $d->excerpt->rendered; ?></p>
					</div>
				</div>
			</div>
			<!---- List biasa Kanal---->
			<?php } ?>
			
			<!--BANNER AD-->
			<div class="banner-ad">
				<img src="<?= base_url('assets/frontend/'); ?>img/ad-middle-banner-640x90.jpg" width=100%>
			</div>
			
			<div style="margin-bottom:30px;"></div>
			
  		</div>
		<!---------------------------------------------------------- ------------------------------- col-left END -------------------------------------------------------------------------------------->

  		
		<!---------------------------------------------------------- ------------------------------- col-right START ----------------------------------------------------------------------------------->
		<div class="col-right">
    		<div class="title-section">Pengguna Baru</div>
			<div style="margin-top:20px;"></div>
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[0]->name; ?></div>
						<!-- <div class="jml-artikel">21 Artikel</div> -->
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[1]->name; ?></div>
						<!-- <div class="jml-artikel">19 Artikel</div> -->
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[2]->name; ?></div>
						<!-- <div class="jml-artikel">21 Artikel</div> -->
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[3]->name; ?></div>
						<!-- <div class="jml-artikel">19 Artikel</div> -->
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[4]->name; ?></div>
						<!-- <div class="jml-artikel">21 Artikel</div> -->
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<div style="margin-top:30px;"></div>
			
			<!--BANNER AD-->
				<div class="title-section">Advertisement</div>
				
				<div style="margin-top:20px;"></div>
				<div class="banner-ad">
					<img src="<?= base_url('assets/frontend/'); ?>img/ad-rectangle-banner-300x250.jpg" width=300>
				</div>
				<div style="margin-top:30px;"></div>
			
			
			
			<div class="title-section" style="clear:both;">Terbaru</div>
			<div style="margin-top:20px;"></div>
			
			<!---- List ---->
			<?php
                    foreach($hasilTerbaru as $hTe){ ?>
			<div class="row-list rightcol">
				<div class="kol-separuh-rightcol left">
				<?php
                    $idBerita = $hTe->id;
                ?>
				<a href="<?= base_url('detail/') . $idBerita; ?>">
					<div class="img-holder" style="background-image:url(<?= $hTe->jetpack_featured_media_url; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div></a>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<?php
							$UTC = strtotime($hTe->date_gmt);
							foreach($hTe->cat_detail as $cd){ ?>
						<a href="<?= base_url(''); ?><?= strtolower($cd->name); ?>"><div class="author-name small"><span><?= $cd->name; ?></span></a>&nbsp; | &nbsp;<?= $hTe->author_detail->name; ?></div>
						<?php } ?>
						<div class="date small"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><p class="headline-title-teks small"><?= $hTe->title->rendered; ?></p>
				</div>
			</div>
			<!---- List ---->
			
			<!-- <div style="margin-top:15px;"></div> -->
			
			<?php } ?>
			<div style="margin-top:30px;"></div>
			
			<!--BANNER AD-->

				<div class="title-section">Advertisement</div>
				
				<div style="margin-top:20px;"></div>
				<div class="banner-ad">
					<img src="<?= base_url('assets/frontend/'); ?>img/ad-rectangle-banner-300x250.jpg" width=300>
				</div>
				<div style="margin-top:30px;"></div>
			
			
			
			
  		</div>
		<!---------------------------------------------------------- ------------------------------- col-right END ------------------------------------------------------------------------------------->
	</div>
	<!-- content-wrapper END -->
