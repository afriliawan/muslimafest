<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">


<link href="<?= base_url('assets/frontend/'); ?>css/style.css" rel="stylesheet" type="text/css" media="all">


<link rel="stylesheet" href="<?= base_url('assets/frontend/'); ?>font-awesome-4.7.0/css/font-awesome.css">
<link rel="stylesheet" href="<?= base_url('assets/frontend/'); ?>font-awesome-4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!--<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css'>-->

<link href='https://fonts.googleapis.com/css?family=Lora|Ubuntu:300,400' rel='stylesheet' type='text/css'><link rel="stylesheet" href="<?= base_url('assets/frontend/'); ?>style.css">


<title>Kanal</title>
</head>

<body>

<div class="page-wrapper">
	<header>
		<div class="header-left">
			<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/hops-logo.png" width=112></a>
		</div>
	
		<div class="header-right">
			<div class="header-hops-media"><a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/hopsmedia-logo.png" width=51></a></div>
			<div class="socmed">
			<ul class="socmed-group">
				<a href="#"><li class="socmed-item">
					<i class="fa fa-facebook" style="font-size:14px; color:#eee;"></i>
				</li></a>
				<a href="#"><li class="socmed-item">
					<i class="fa fa-twitter" style="font-size:14px; color:#eee;"></i>
				</li></a>
				<a href="#"><li class="socmed-item">
					<i class="fa fa-instagram" style="font-size:14px; color:#eee;"></i>
				</li></a>
				<a href="#"><li class="socmed-item">
					<i class="fa fa-youtube" style="font-size:14px; color:#eee;"></i>
				</li></a>
				<a href="#"><li class="socmed-item">
					<i class="fa fa-linkedin" style="font-size:14px; color:#eee;"></i>
				</li></a>
			</ul>
			</div>
		</div>
	</header>
	
	<a href="#">
	<div class="btn-tulis">
		<img src="<?= base_url('assets/frontend/'); ?>img/btn-tulis.png" width=142>
	</div>
	</a>
	
	<div class="navigation">
		<div class="nav-left">
		
		<!--Search START --->
		
		<div class="search-box">
    <button class="btn-search"><i class="fa fa-search"></i></button>
    <input type="text" class="input-search" placeholder="Type to Search...">
  </div>
		
		
		
		<!-- Search END --->
		
		</div>
		
		<div class="nav-center">
		<ul>
		 	<a href="<?=base_url('C_frontend'); ?>"><li>HOME</li></a>
			<a href="<?=base_url('C_frontend/kanal'); ?>"><li>TRENDING</li></a>
			<a href="#"><li>UNIK</li></a>
			<a href="#"><li>HOT</li></a>
			<a href="#"><li>HOBI</li></a>
		</ul>
		</div>
		
		<div class="nav-right">
			<a href="#">
			<div class="btn-daftar">
				<div class="btn-daftar-label">
					<img src="<?= base_url('assets/frontend/'); ?>img/icon-daftar.png" width=25>&nbsp;&nbsp;Daftar
				</div>
			</div>
			</a>
		</div>
	</div>
	
	<!--content-wrapper Start-->
	<div class="content-wrapper">
		<div class="title-kanal">TRENDING</div>
		<!--row-full2 START-->
		<div class="row-full2">
		
			<!--================================================================================================== kol-left START ============================================================================================-->
			<div class="kol-left">
			
				<section class="valign bottom headline kanal" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-8.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
			<div class="headline-title-box">
				
				
						<div class="author">
							<div class="author-left">
								<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
								</div>
							</div>
							<div class="author-right">
                            <?php
                    foreach($hasil as $r){ ?>
								<div class="author-name reverse"><?= $r->author_detail->name; ?></div>
								<div class="date reverse"><?= $r->date_gmt; ?> &nbsp; | &nbsp; 09:52</div>
							</div>
                            <?php } ?>
						</div>
					
				<a href="#"><p class="headline-title-teks kanal"><?= $r->title->rendered; ?></p>
				
				</a>
			</div>
		</section>
				<div style="margin-top:20px;"></div>
				
				<ul style="margin-left:-40px;">
				<!--START Listing Terbaru-->
				<li>
                    <?php foreach($listKanal as $lK){ ?>
				<div class="row-list">
					<div class="kol-separuh left">
						<a href="#"><div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-3.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
					</div>
				
					<div class="kol-separuh right kanal">
						<div class="author">
							<div class="author-left">
								<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
								</div>
							</div>
							<div class="author-right">
								<div class="author-name"><?= $lK->author_detail->name; ?></div>
							</div>
						</div>
						<div style="margin-bottom:30px;"></div>
						<div class="date"><?= $lK->date_gmt; ?> &nbsp; | &nbsp; 09:52</div>
						<a href="#"><p class="headline-title-teks medium"><?= $lK->title->rendered; ?></p>
						</a>
					</div>
				</div>
                <?php } ?>
				</li>
				<!--END Listing Terbaru-->
				
				
				<!--BANNER AD-->
				<img src="<?= base_url('assets/frontend/'); ?>img/ad-middle-banner-640x90.jpg" width=640>
				<div style="margin-bottom:30px;"></div>
				
				
				<!--START Listing Terbaru-->
				<li>
				<div class="row-list">
					<div class="kol-separuh left">
						<a href="#"><div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-5.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
					</div>
				
					<div class="kol-separuh right kanal">
						<div class="author">
							<div class="author-left">
								<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
								</div>
							</div>
							<div class="author-right">
								<div class="author-name">Solis Alfi</div>
							</div>
						</div>
						<div style="margin-bottom:30px;"></div>
						<div class="date">22 Juni 2021 &nbsp; | &nbsp; 09:52</div>
						<a href="#"><p class="headline-title-teks medium">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
						</a>
					</div>
				</div>
				</li>
				<!--END Listing Terbaru-->
				
				<!--START Listing Terbaru-->
				<li>
				<div class="row-list">
					<div class="kol-separuh left">
						<a href="#"><div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-8.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
					</div>
				
					<div class="kol-separuh right kanal">
						<div class="author">
							<div class="author-left">
								<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
								</div>
							</div>
							<div class="author-right">
								<div class="author-name">Margot Reth</div>
							</div>
						</div>
						<div style="margin-bottom:30px;"></div>
						<div class="date">22 Juni 2021 &nbsp; | &nbsp; 09:52</div>
						<a href="#"><p class="headline-title-teks medium">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
						</a>
					</div>
				</div>
				</li>
				<!--END Listing Terbaru-->
				
				<!--START Listing Terbaru-->
				<li>
				<div class="row-list">
					<div class="kol-separuh left">
						<a href="#"><div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-7.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
					</div>
				
					<div class="kol-separuh right kanal">
						<div class="author">
							<div class="author-left">
								<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
								</div>
							</div>
							<div class="author-right">
								<div class="author-name">Ratna W. Sari</div>
							</div>
						</div>
						<div style="margin-bottom:30px;"></div>
						<div class="date">22 Juni 2021 &nbsp; | &nbsp; 09:52</div>
						<a href="#"><p class="headline-title-teks medium">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
						</a>
					</div>
				</div>
				</li>
				<!--END Listing Terbaru-->
				
				
				
				<!--START Listing Terbaru-->
				<li>
				<div class="row-list">
					<div class="kol-separuh left">
						<a href="#"><div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-2.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
					</div>
				
					<div class="kol-separuh right kanal">
						<div class="author">
							<div class="author-left">
								<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
								</div>
							</div>
							<div class="author-right">
								<div class="author-name">Margot Reth</div>
							</div>
						</div>
						<div style="margin-bottom:30px;"></div>
						<div class="date">22 Juni 2021 &nbsp; | &nbsp; 09:52</div>
						<a href="#"><p class="headline-title-teks medium">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
						</a>
					</div>
				</div>
				</li>
				<!--END Listing Terbaru-->
				
				
				<!--START Listing Terbaru-->
				<li>
				<div class="row-list">
					<div class="kol-separuh left">
						<a href="#"><div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-4.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
					</div>
				
					<div class="kol-separuh right kanal">
						<div class="author">
							<div class="author-left">
								<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
								</div>
							</div>
							<div class="author-right">
								<div class="author-name">Margot Reth</div>
							</div>
						</div>
						<div style="margin-bottom:30px;"></div>
						<div class="date">22 Juni 2021 &nbsp; | &nbsp; 09:52</div>
						<a href="#"><p class="headline-title-teks medium">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
						</a>
					</div>
				</div>
				</li>
				<!--END Listing Terbaru-->
				
				
				</ul>
				
				
	
				<div style="margin-bottom:40px;"></div>
				
				<!-- <div class="row-list">
				<a href="#"><div class="btn-load-more">Tampilkan Lebih Banyak</div></a>
				</div>
				 -->
				
				</div>
				<!--END Listing Terbaru-->
				
			</div>
			<!--kol-left END-->
			
			
			
			
			
			
			
			<!-- ==========================================================================================  kol-right START  =========================================================================================-->
			<div class="kol-right" style="margin-top: -336px;">
				<div class="title-section">Pengguna Baru</div>
				
				<div style="margin-top:20px;"></div>
				
				
				<div class=div class="row-full">
				<ul style="margin-left:-40px;">
				
				<!--START Listing Top Writer-->
				<li>
				<div class="row-list rightcol">
					<a href="#"><div class="kol-separuh-rightcol left">
						<div class="author-pic large" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
					</div>
					<div class="kol-separuh-rightcol right author">
						<div class="author">
							<div class="author-name">Gita Yarsi</div>
							<div class="jml-artikel">19 Artikel</div>
						</div>
					</div></a>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Top Writer-->
				
				<!--START Listing Top Writer-->
				<li>
				<div class="row-list rightcol">
					<a href="#"><div class="kol-separuh-rightcol left">
						<div class="author-pic large" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
					</div>
					<div class="kol-separuh-rightcol right author">
						<div class="author">
							<div class="author-name">Vanda Maria Bonfanti</div>
							<div class="jml-artikel">19 Artikel</div>
						</div>
					</div></a>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Top Writer-->
				
				<!--START Listing Top Writer-->
				<li>
				<div class="row-list rightcol">
					<a href="#"><div class="kol-separuh-rightcol left">
						<div class="author-pic large" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
					</div>
					<div class="kol-separuh-rightcol right author">
						<div class="author">
							<div class="author-name">Margot Reth</div>
							<div class="jml-artikel">19 Artikel</div>
						</div>
					</div></a>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Top Writer-->
				
				<!--START Listing Top Writer-->
				<li>
				<div class="row-list rightcol">
					<a href="#"><div class="kol-separuh-rightcol left">
						<div class="author-pic large" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
					</div>
					<div class="kol-separuh-rightcol right author">
						<div class="author">
							<div class="author-name">Diah Siti Rahayu</div>
							<div class="jml-artikel">19 Artikel</div>
						</div>
					</div></a>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Top Writer-->
				
				<!--START Listing Top Writer-->
				<li>
				<div class="row-list rightcol">
					<a href="#"><div class="kol-separuh-rightcol left">
						<div class="author-pic large" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
					</div>
					<div class="kol-separuh-rightcol right author">
						<div class="author">
							<div class="author-name">Sarah Rinjani S.</div>
							<div class="jml-artikel">19 Artikel</div>
						</div>
					</div></a>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Top Writer-->
				

				</ul>
				
				
				<!--BANNER AD-->
				<div class="title-section">Advertisement</div>
				
				<div style="margin-top:20px;"></div>
				<img src="<?= base_url('assets/frontend/'); ?>img/ad-rectangle-banner-300x250.jpg" width=300>
				<div style="margin-top:40px;"></div>
				
				
			<!--------------------------------------------------------------------->	
				<div class="title-section">Terbaru</div>
				
				<div style="margin-top:20px;"></div>
				
				<ul style="margin-left:-40px;">
				
				<!--START Listing Terpopuler-->
                
                <?php
                    foreach($hasilTerbaru as $hT){ ?>
				<li>
				<div class="row-list rightcol">
					<div class="kol-separuh-rightcol left">
						<div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-7.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
					</div>
				
					<div class="kol-separuh-rightcol right">
						<div class="author">
                        <?php
                            foreach($hT->cat_detail as $cd){ ?>
							<div class="author-name small"><span><?= $cd->name; ?></span>&nbsp; | &nbsp;<?= $hT->author_detail->name; ?></div>
                            <?php } ?>
							<div class="date small"><?= $hT->date_gmt; ?> &nbsp;| &nbsp; 12:48</div>
						</div>
						<p class="headline-title-teks small"><?= $hT->title->rendered; ?></p>
					</div>
                    <?php } ?>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Terpopuler-->
				
				</ul>
				
				<!--BANNER AD-->
				<div class="title-section">Advertisement</div>
				
				<div style="margin-top:20px;"></div>
				<img src="<?= base_url('assets/frontend/'); ?>img/ad-rectangle-banner-300x250.jpg" width=300>
				<div style="margin-top:10px;"></div>
				
				</div>
				
				<!-- Ini Buat Ganjal Footer agar terdorong ke Bawah -->
				<div style="margin-top:530px;"></div>
				
				
			</div>
			<!--kol-right END-->
			
			
			
		
		</div>
		<!--row-full2 END-->
		
		
		
		
		<!--row-full 3 START-->
		<div class="row-full" style="display:flex;">
			<div class="footer">
				<div class="row-full" style="padding:20px;">
					<ul style="margin-left:-40px;">
						<a href="#"><li>Tentang Kami</li></a>
						<a href="#"><li>Disclaimer</li></a>
						<a href="#"><li>Pedoman Media Siber</li></a>
						<a href="#"><li>Kontak</li></a>
						<a href="#"><li>Karier</li></a>
						<a href="#"><li>Indeks</li></a>
					</ul>
				</div>
				<div class="row-full">
					<div class="footer-kol-left">
						<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/hopsmedia-logo-reverse.png" width=95></a>
					</div>
					
					<div class="footer-kol-center">
						<ul class="row-full" style="margin-left:-40px;">
							<li class="multibrand-logo">
								<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/hops-logo.png" width=75></a>
							</li>
							<li class="multibrand-logo">
								<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/logo-depoktoday-reverse.png" width=125></a>
							</li>
							<li class="multibrand-logo">
								<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/logo-kulinear.png" width=135></a>
							</li>
							<li class="multibrand-logo">
								<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/logo-muslima.png" width=125></a>
							</li>
							<li class="multibrand-logo">
								<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/logo-koreabanget.png" width=135></a>
							</li>
							<li class="multibrand-logo">
								<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/logo-bisnika.png" width=115></a>
							</li>
							<li class="multibrand-logo">
								<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/logo-ceklis-satu.png" width=155></a>
							</li>
						</ul>
					</div>
					
					<div class="footer-kol-right">
						<br>Subsidiary of <br><br>
						<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/logo-surge.png" width=85></a>
					</div>
				</div>
				
				<div style="margin-top:20px;"></div>
				<div class="row-full" style="padding:20px;">
					<div class="copyright">HopsID ©Copyright 2021 | All Right Reserved</div>
				</div>
			</div>
		</div>
		<!--row-full 3 END-->
		
	
	</div>
	<!--content-wrapper End-->
	
</div>


</body>
</html>
