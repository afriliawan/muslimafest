<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">


<link href="<?= base_url('assets/frontend/'); ?>css/style.css" rel="stylesheet" type="text/css" media="all">


<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css'>
<title>Home</title>
</head>

<body>

<div class="page-wrapper">
	<header>
		<div class="header-left">
			<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/hops-logo.png" width=112></a>
		</div>
	
		<div class="header-right">
			<div class="header-hops-media"><a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/hopsmedia-logo.png" width=51></a></div>
			<div class="socmed">
			<ul class="socmed-group">
				<a href="#"><li class="socmed-icon"><img src="<?= base_url('assets/frontend/'); ?>img/icon-fb.png" width=25></li></a>
				<a href="#"><li class="socmed-icon"><img src="<?= base_url('assets/frontend/'); ?>img/icon-twitter.png" width=25></li></a>
				<a href="#"><li class="socmed-icon"><img src="<?= base_url('assets/frontend/'); ?>img/icon-insta.png" width=25></li></a>
				<a href="#"><li class="socmed-icon"><img src="<?= base_url('assets/frontend/'); ?>img/icon-yt.png" width=25></li></a>
				<a href="#"><li class="socmed-icon"><img src="<?= base_url('assets/frontend/'); ?>img/icon-tiktok.png" width=25></li></a>
			</ul>
			</div>
		</div>
	</header>
	
	<a href="#">
	<div class="btn-tulis">
		<img src="<?= base_url('assets/frontend/'); ?>img/btn-tulis.png" width=142>
	</div>
	</a>
	
	<div class="navigation">
		<div class="nav-left">
		
		<!--Search START --->
		
		<div class="search-box">
    <button class="btn-search"><i class="fas fa-search"></i></button>
    <input type="text" class="input-search" placeholder="Type to Search...">
  </div>
		
		
		
		<!-- Search END --->
		
		</div>
		
		<div class="nav-center">
		<ul>
			<a href="<?=base_url('C_frontend'); ?>"><li>HOME</li></a>
			<a href="<?=base_url('C_frontend/kanal'); ?>"><li>TRENDING</li></a>
			<a href="#"><li>UNIK</li></a>
			<a href="#"><li>HOT</li></a>
			<a href="#"><li>HOBI</li></a>
		</ul>
		</div>
		
		<div class="nav-right">
			<a href="#">
			<div class="btn-daftar">
				<div class="btn-daftar-label">
					<img src="<?= base_url('assets/frontend/'); ?>img/icon-daftar.png" width=25>&nbsp;&nbsp;Daftar
				</div>
			</div>
			</a>
		</div>
	</div>


	<!--content-wrapper Start-->
	<div class="content-wrapper" style="width:100%!important;">
		<section class="valign bottom headline" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
			<div class="headline-title-box">
			
                    <a href="#"><div class="upperdeck">
			<?php
                    foreach($headline[0]->cat_detail as $r){ ?>	
                        
                            <?= $r->name; ?></div></a>
							<?php } ?>
                    <div class="author">
                        <div class="author-left">
                            <div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
                            </div>
                        </div>
                        <div class="author-right">

						<?php
						foreach($headline[0]->author_detail as $author){ ?>	
						<?php var_dump($author);die();?>

                            <div class="author-name reverse"><?= $author->name; ?></div>
							<?php } ?>
						
                            <div class="date reverse"> &nbsp; | &nbsp; 09:52</div>
                        </div>
                    </div>

				<a href=""><p class="headline-title-teks"></p>
				
				<div class="desc">
					<p></p>
				</div></a>
				<!-- kie gene sapa eh tag 'e ? -->
                
			</div>
		</section>
		
		<div style="margin-top:20px;"></div>
		
		<!--row-full 1 START-->
		<div class="row-full">
			
		<?php
                    foreach($hasil2 as $r2){ ?>
			<div class="kol-seperempat" style="width: 23.68%!important;">
				
			<?php
                            foreach($r2->cat_detail as $cd2){ ?>
				<a href="#"><div class="upperdeck small"><?= $cd2->name; ?></div></a>
				
				<?php } ?>
				<a href="#"><div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-2.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				
				<div style="margin-top:10px;"></div>
				
				<div class="author">
					<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
						</div>
					</div>
					<div class="author-right">
						<div class="author-name"><?= $r2->author_detail->name; ?></div>
						<div class="date"><?= $r2->date_gmt; ?></div>
					</div>
				</div>
				
				<div style="margin-bottom:10px;"></div>
				
				<a href="#"><p class="headline-title-teks small"><?= $r2->title->rendered; ?></p>
				<div class="desc small">
					<p><?= $r2->excerpt->rendered; ?></p>
				</div></a>
			</div><!--kol-seperempat End-->
			
			<?php } ?>
		</div>
		<!--row-full 1 END-->
		
		
		<div style="margin-top:30px;"></div>
		
		
		<!--row-full2 START-->
		<div class="row-full2">
		
			<!--================================================================================================== kol-left START ============================================================================================-->
			<div class="kol-left">
				<div class="title-section">Terbaru</div>
				
				<div style="margin-top:20px;"></div>
				
				<ul style="margin-left:-40px;">
				<!--START Listing Terbaru-->
				<li>
				<?php
                    foreach($hasilTerbaru as $hT){ ?>
				<div class="row-list">
					<div class="kol-separuh left">
						<a href="#"><div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-6.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
					</div>
				
					<div class="kol-separuh right">
						<div class="author">
							<div class="author-left">
								<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
								</div>
							</div>
							<div class="author-right">
							<?php
                            foreach($hT->cat_detail as $cd){ ?>
								<div class="author-name"><span><?= $cd->name; ?></span>&nbsp;|&nbsp;<?= $hT->author_detail->name; ?></div>
								<?php } ?>
								<div class="date"><?= $hT->date_gmt; ?></div>
							</div>
						</div>
						<div style="margin-bottom:30px;"></div>
				
						<a href="#"><p class="headline-title-teks medium"><?= $hT->title->rendered; ?></p>
						<div class="desc small">
							<!-- <p><?= $hT->excerpt->rendered; ?></p> -->
							<p><?= $hT->slug; ?></p>
						</div></a>
					</div>
				</div>
				<?php } ?>
				</li>
				<!--END Listing Terbaru-->
				
				<!--BANNER AD-->
				<img src="<?= base_url('assets/frontend/'); ?>img/ad-middle-banner-640x90.jpg" width=640>
				<div style="margin-bottom:30px;"></div>
				
				
				<!--START Listing Terbaru-->
				<li>
				<div class="row-list">
					<div class="kol-separuh left">
						<a href="#"><div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-7.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
					</div>
				
					<div class="kol-separuh right">
						<div class="author">
							<div class="author-left">
								<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
								</div>
							</div>
							<div class="author-right">
								<div class="author-name"><span>Trending</span>&nbsp;|&nbsp;Debby Haris</div>
								<div class="date">22 Juni 2021 &nbsp; | &nbsp; 09:52</div>
							</div>
						</div>
						<div style="margin-bottom:30px;"></div>
				
						<a href="#"><p class="headline-title-teks medium">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
						<div class="desc small">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum urna in elit palais ver ultricies ...</p>
						</div></a>
					</div>
				</div>
				</li>
				<!--END Listing Terbaru-->
				
				<!--START Listing Terbaru-->
				<li>
				<div class="row-list">
					<div class="kol-separuh left">
						<a href="#"><div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-6.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
					</div>
				
					<div class="kol-separuh right">
						<div class="author">
							<div class="author-left">
								<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
								</div>
							</div>
							<div class="author-right">
								<div class="author-name"><span>Hot</span>&nbsp;|&nbsp;Vanda Maria Bonfanti</div>
								<div class="date">22 Juni 2021 &nbsp; | &nbsp; 09:52</div>
							</div>
						</div>
						<div style="margin-bottom:30px;"></div>
				
						<a href="#"><p class="headline-title-teks medium">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
						<div class="desc small">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum urna in elit palais ver ultricies ...</p>
						</div></a>
					</div>
				</div>
				</li>
				<!--END Listing Terbaru-->
				
				<!--START Listing Terbaru-->
				<li>
				<div class="row-list">
					<div class="kol-separuh left">
						<a href="#"><div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-5.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
					</div>
				
					<div class="kol-separuh right">
						<div class="author">
							<div class="author-left">
								<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
								</div>
							</div>
							<div class="author-right">
								<div class="author-name"><span>Hobi</span>&nbsp;|&nbsp; Duhita Anggina Salim</div>
								<div class="date">22 Juni 2021 &nbsp; | &nbsp; 09:52</div>
							</div>
						</div>
						<div style="margin-bottom:30px;"></div>
				
						<a href="#"><p class="headline-title-teks medium">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
						<div class="desc small">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum urna in elit palais ver ultricies ...</p>
						</div></a>
					</div>
				</div>
				</li>
				<!--END Listing Terbaru-->
				
				
				
				<!--START Listing Terbaru-->
				<li>
				<div class="row-list">
					<div class="kol-separuh left">
						<a href="#"><div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-2.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
					</div>
				
					<div class="kol-separuh right">
						<div class="author">
							<div class="author-left">
								<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
								</div>
							</div>
							<div class="author-right">
								<div class="author-name"><span>Unik</span>&nbsp;|&nbsp; Alfira Damayanti</div>
								<div class="date">22 Juni 2021 &nbsp; | &nbsp; 09:52</div>
							</div>
						</div>
						<div style="margin-bottom:30px;"></div>
				
						<a href="#"><p class="headline-title-teks medium">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
						<div class="desc small">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum urna in elit palais ver ultricies ...</p>
						</div></a>
					</div>
				</div>
				</li>
				<!--END Listing Terbaru-->
				
				
				</ul>
				
				
	
				<div style="margin-bottom:40px;"></div>
				
				<div class="row-list">
				<a href="#"><div class="btn-load-more">Tampilkan Lebih Banyak</div></a>
				</div>
				
				
				</div>
				<!--END Listing Terbaru-->
				
			</div>
			<!--kol-left END-->
			
			
			
			
			
			
			
			<!-- ==========================================================================================  kol-right START  =========================================================================================-->
			<div class="kol-right">
				<div class="title-section">Terpopuler</div>
				
				<div style="margin-top:20px;"></div>
				
				
				<div class=div class="row-full">
				<ul style="margin-left:-40px;">
				
				<!--START Listing Terpopuler-->
				<li>
				<div class="row-list rightcol">
					<div class="kol-separuh-rightcol left">
						<div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-7.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
					</div>
				
					<div class="kol-separuh-rightcol right">
						<div class="author">
							<div class="author-name small"><span>Hobi</span>&nbsp; | &nbsp;Margot Reth</div>
							<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
						</div>
						<p class="headline-title-teks small">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
					</div>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Terpopuler-->
				
				<!--START Listing Terpopuler-->
				<li>
				<div class="row-list rightcol">
					<div class="kol-separuh-rightcol left">
						<div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-4.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
					</div>
				
					<div class="kol-separuh-rightcol right">
						<div class="author">
							<div class="author-name small"><span>Hobi</span>&nbsp; | &nbsp;Sarah Rinjani S.</div>
							<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
						</div>
						<p class="headline-title-teks small">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
					</div>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Terpopuler-->
				
				<!--START Listing Terpopuler-->
				<li>
				<div class="row-list rightcol">
					<div class="kol-separuh-rightcol left">
						<div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-3.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
					</div>
				
					<div class="kol-separuh-rightcol right">
						<div class="author">
							<div class="author-name small"><span>Hobi</span>&nbsp; | &nbsp;Vanda Maria Bonfanti</div>
							<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
						</div>
						<p class="headline-title-teks small">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
					</div>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Terpopuler-->
				
				<!--START Listing Terpopuler-->
				<li>
				<div class="row-list rightcol">
					<div class="kol-separuh-rightcol left">
						<div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-2.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
					</div>
				
					<div class="kol-separuh-rightcol right">
						<div class="author">
							<div class="author-name small"><span>Hobi</span>&nbsp; | &nbsp;Debby Hari</div>
							<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
						</div>
						<p class="headline-title-teks small">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
					</div>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Terpopuler-->
				
				<!--START Listing Terpopuler-->
				<li>
				<div class="row-list rightcol">
					<div class="kol-separuh-rightcol left">
						<div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
					</div>
				
					<div class="kol-separuh-rightcol right">
						<div class="author">
							<div class="author-name small"><span>Unik</span>&nbsp; | &nbsp;Margot Reth</div>
							<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
						</div>
						<p class="headline-title-teks small">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
					</div>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Terpopuler-->
				
				<!--START Listing Terpopuler-->
				<li>
				<div class="row-list rightcol">
					<div class="kol-separuh-rightcol left">
						<div class="img-holder" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/img-artikel-6.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
					</div>
				
					<div class="kol-separuh-rightcol right">
						<div class="author">
							<div class="author-name small"><span>Unik</span>&nbsp; | &nbsp;Gita Yarsi</div>
							<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
						</div>
						<p class="headline-title-teks small">Indonesia disebut punya Kapal Induk rahasia, elite katanya...</p>
					</div>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Terpopuler-->
				
				</ul>
				
				
				<!--BANNER AD-->
				<div class="title-section">Advertisement</div>
				
				<div style="margin-top:20px;"></div>
				<img src="<?= base_url('assets/frontend/'); ?>img/ad-rectangle-banner-300x250.jpg" width=300>
				<div style="margin-top:40px;"></div>
				
				
				
				<div class="title-section">Top Writer</div>
				
				<div style="margin-top:20px;"></div>
				
				<ul style="margin-left:-40px;">
				
				<!--START Listing Top Writer-->
				<li>
				<div class="row-list rightcol">
					<a href="#"><div class="kol-separuh-rightcol left">
						<div class="author-pic large" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
					</div>
					<div class="kol-separuh-rightcol right author">
						<div class="author">
							<div class="author-name">Gita Yarsi</div>
							<div class="jml-artikel">19 Artikel</div>
						</div>
					</div></a>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Top Writer-->
				
				<!--START Listing Top Writer-->
				<li>
				<div class="row-list rightcol">
					<a href="#"><div class="kol-separuh-rightcol left">
						<div class="author-pic large" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
					</div>
					<div class="kol-separuh-rightcol right author">
						<div class="author">
							<div class="author-name">Vanda Maria Bonfanti</div>
							<div class="jml-artikel">19 Artikel</div>
						</div>
					</div></a>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Top Writer-->
				
				<!--START Listing Top Writer-->
				<li>
				<div class="row-list rightcol">
					<a href="#"><div class="kol-separuh-rightcol left">
						<div class="author-pic large" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
					</div>
					<div class="kol-separuh-rightcol right author">
						<div class="author">
							<div class="author-name">Margot Reth</div>
							<div class="jml-artikel">19 Artikel</div>
						</div>
					</div></a>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Top Writer-->
				
				<!--START Listing Top Writer-->
				<li>
				<div class="row-list rightcol">
					<a href="#"><div class="kol-separuh-rightcol left">
						<div class="author-pic large" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
					</div>
					<div class="kol-separuh-rightcol right author">
						<div class="author">
							<div class="author-name">Diah Siti Rahayu</div>
							<div class="jml-artikel">19 Artikel</div>
						</div>
					</div></a>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Top Writer-->
				
				<!--START Listing Top Writer-->
				<li>
				<div class="row-list rightcol">
					<a href="#"><div class="kol-separuh-rightcol left">
						<div class="author-pic large" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
					</div>
					<div class="kol-separuh-rightcol right author">
						<div class="author">
							<div class="author-name">Sarah Rinjani S.</div>
							<div class="jml-artikel">19 Artikel</div>
						</div>
					</div></a>
				</div>
				<div style="margin-bottom:10px;"></div>
				</li>
				<!--END Listing Top Writer-->
				

				</ul>
				
				<!--BANNER AD-->
				<div class="title-section">Advertisement</div>
				
				<div style="margin-top:20px;"></div>
				<img src="<?= base_url('assets/frontend/'); ?>img/ad-rectangle-banner-300x250.jpg" width=300>
				<div style="margin-top:10px;"></div>
				
				
				</div>
				
			</div>
			<!--kol-right END-->
			
			
			
		
		</div>
		<!--row-full2 END-->
		
		
		
		
		<!--row-full 3 START-->
		<div class="row-full" style="display:flex;">
			<div class="footer">
				<div class="row-full" style="padding:20px;">
					<ul style="margin-left:-40px;">
						<a href="#"><li>Tentang Kami</li></a>
						<a href="#"><li>Disclaimer</li></a>
						<a href="#"><li>Pedoman Media Siber</li></a>
						<a href="#"><li>Kontak</li></a>
						<a href="#"><li>Karier</li></a>
						<a href="#"><li>Indeks</li></a>
					</ul>
				</div>
				<div class="row-full">
					<div class="footer-kol-left">
						<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/hopsmedia-logo-reverse.png" width=95></a>
					</div>
					
					<div class="footer-kol-center">
						<ul class="row-full" style="margin-left:-40px;">
							<li class="multibrand-logo">
								<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/hops-logo.png" width=75></a>
							</li>
							<li class="multibrand-logo">
								<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/logo-depoktoday-reverse.png" width=125></a>
							</li>
							<li class="multibrand-logo">
								<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/logo-kulinear.png" width=135></a>
							</li>
							<li class="multibrand-logo">
								<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/logo-muslima.png" width=125></a>
							</li>
							<li class="multibrand-logo">
								<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/logo-koreabanget.png" width=135></a>
							</li>
							<li class="multibrand-logo">
								<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/logo-bisnika.png" width=115></a>
							</li>
							<li class="multibrand-logo">
								<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/logo-ceklis-satu.png" width=135></a>
							</li>
						</ul>
					</div>
					
					<div class="footer-kol-right">
						<br>Subsidiary of <br><br>
						<img src="<?= base_url('assets/frontend/'); ?>img/logo-surge.png" width=85>
					</div>
				</div>
				
				<div style="margin-top:20px;"></div>
				<div class="row-full" style="padding:20px;">
					<div class="copyright">HopsID ©Copyright 2021 | All Right Reserved</div>
				</div>
			</div>
		</div>
		<!--row-full 3 END-->
		
	
	</div>
	<!--content-wrapper End-->
	
</div>


</body>
</html>
