	<!-- content-wrapper START -->
	<div class="content-wrapper" style="overflow:auto; clear:both;">
		
    <section class="valign bottom headline" style="background-image:url(<?= $headline[0]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: top; background-size: cover; background-repeat: no-repeat;"></a>
			<div class="headline-title-box">
				<a href="<?= base_url(''); ?><?= strtolower($headline[0]['cat_detail'][0]['name']); ?>"><div class="upperdeck"><?= $headline[0]['cat_detail'][0]['name']; ?></div></a>
				
						<div class="author">
							<div class="author-left">
								<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
								</div>
							</div>
							<div class="author-right">
                            <?php
							$UTC = strtotime($headline[0]['date_gmt']);
							?>
								<div class="author-name reverse"><?=$headline[0]['author_detail']['name']; ?></div>
								<div class="date reverse"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
							</div>
						</div>
                    <?php
                        $idBerita = $headline[0]['id'];
						$slugnya = $headline[0]['slug'];
					?>
				<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks"><?= $headline[0]['title']['rendered']; ?></p>
				
				<div class="desc">
                    <p><?= $headline[0]['excerpt']['rendered']; ?></p>
				</div></a>
			</div>
		</section>
  		
		<div style="margin-top:20px;"></div>
		
		<!--row-full 1 START-->
		<div class="row-full">
			<div class="kol-seperempat">
			<a href="<?= base_url(''); ?><?= strtolower($headline[1]['cat_detail'][0]['name']); ?>"><div class="upperdeck small"><?= $headline[1]['cat_detail'][0]['name']; ?></div></a>
                <?php
                    $idBerita = $headline[1]['id'];
                    $slugnya = $headline[1]['slug'];
                ?>
				<a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[1]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				
				<div style="margin-top:10px;"></div>
				
				<div class="author">
					<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
						</div>
					</div>
					<div class="author-right">
                        <?php
							$UTC = strtotime($headline[1]['date_gmt']);
						?>
						<div class="author-name"><?=$headline[1]['author_detail']['name']; ?></div>
						<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
				</div>
				
				<div style="margin-bottom:10px;"></div>
				
				<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $headline[1]['title']['rendered']; ?></p>
				<div class="desc small">
					<?= $headline[1]['excerpt']['rendered']; ?>
				</div></a>
			</div><!--kol-seperempat End-->
			
			<div class="kol-seperempat">
			<a href="<?= base_url(''); ?><?= strtolower($headline[2]['cat_detail'][0]['name']); ?>"><div class="upperdeck small"><?= $headline[2]['cat_detail'][0]['name']; ?></div></a>
                <?php
                    $idBerita = $headline[2]['id'];
                    $slugnya = $headline[2]['slug'];
                ?>
				<a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[2]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				
				<div style="margin-top:10px;"></div>
				
				<div class="author">
					<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
						</div>
					</div>
					<div class="author-right">
                    <?php
                        $UTC = strtotime($headline[2]['date_gmt']);
                    ?>
						<div class="author-name"><?=$headline[2]['author_detail']['name']; ?></div>
						<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
				</div>
				
				<div style="margin-bottom:10px;"></div>
				
				<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $headline[2]['title']['rendered']; ?></p>
				<div class="desc small">
					<?= $headline[2]['excerpt']['rendered']; ?>
				</div></a>
			</div><!--kol-seperempat End-->
			
			<div class="kol-seperempat">
			<a href="<?= base_url(''); ?><?= strtolower($headline[3]['cat_detail'][0]['name']); ?>"><div class="upperdeck small"><?= $headline[3]['cat_detail'][0]['name']; ?></div></a>
                <?php
                    $idBerita = $headline[3]['id'];
                    $slugnya = $headline[3]['slug'];
                ?>
				<a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[3]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				
				<div style="margin-top:10px;"></div>
				
				<div class="author">
					<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
						</div>
					</div>
					<div class="author-right">
						<div class="author-name"><?=$headline[3]['author_detail']['name']; ?></div>
                        <?php
                            $UTC = strtotime($headline[3]['date_gmt']);
                        ?>
						<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
				</div>
				
				<div style="margin-bottom:10px;"></div>
				
				<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $headline[3]['title']['rendered']; ?></p>
				<div class="desc small">
					<?= $headline[3]['excerpt']['rendered']; ?>
				</div></a>
			</div><!--kol-seperempat End-->
			
			<div class="kol-seperempat">
			<a href="<?= base_url(''); ?><?= strtolower($headline[4]['cat_detail'][0]['name']); ?>"><div class="upperdeck small"><?= $headline[4]['cat_detail'][0]['name']; ?></div></a>
                <?php
                    $idBerita = $headline[4]['id'];
                    $slugnya = $headline[4]['slug'];
                ?>
				<a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[4]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				
				<div style="margin-top:10px;"></div>
				
				<div class="author">
					<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
						</div>
					</div>
					<div class="author-right">
						<div class="author-name"><?=$headline[4]['author_detail']['name']; ?></div>
                        <?php
                            $UTC = strtotime($headline[4]['date_gmt']);
                        ?>
						<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
				</div>
				
				<div style="margin-bottom:10px;"></div>
				
				<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $headline[4]['title']['rendered']; ?></p>
				<div class="desc small">
					<?= $headline[4]['excerpt']['rendered']; ?>
				</div></a>
			</div><!--kol-seperempat End-->
		</div>
		<!--row-full 1 END-->
		
		<div style="margin-top:30px;"></div>
		
		
		<!---------------------------------------------------------- ------------------------------- col-left START ------------------------------------------------------------------------------------->
		<div class="col-left">
			<div class="title-section">Terbaru</div>
			<div style="margin-top:20px;"></div>
			
			<!---- List Main---->
    		<div class="listbox-main">
                <?php
                    $idBerita = $headline[5]['id'];
                    $slugnya = $headline[5]['slug'];
                ?>
				<div class="listbox-left">
                    <a href="<?= base_url('/') . $slugnya; ?>">
					<div class="img-holder" style="background-image:url(<?= $headline[5]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
							<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
						<a href="<?= base_url(''); ?><?= strtolower($headline[5]['cat_detail'][0]['name']); ?>"><div class="author-name"><span><?= $headline[5]['cat_detail'][0]['name']; ?></span></a>&nbsp;|&nbsp;<?= $headline[5]['author_detail']['name']; ?></div>
                            <?php
                                $UTC = strtotime($headline[5]['date_gmt']);
                            ?>
							<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks medium"><?= $headline[5]['title']['rendered']; ?></p>
					<div class="desc small">
						<p><?= $headline[5]['excerpt']['rendered']; ?></p>
					</div></a>
				</div>
			</div>
			<!---- List Main---->
			
			<!---- List biasa---->
    		<div class="listbox">
                <?php
                    $idBerita = $headline[6]['id'];
                    $slugnya = $headline[6]['slug'];
                ?>
				<div class="listbox-left">
                <a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[6]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
							<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
						<a href="<?= base_url(''); ?><?= strtolower($headline[5]['cat_detail'][0]['name']); ?>"><div class="author-name"><span><?= $headline[6]['cat_detail'][0]['name']; ?></span></a>&nbsp;|&nbsp;<?= $headline[6]['author_detail']['name']; ?></div>
                            <?php
                                $UTC = strtotime($headline[6]['date_gmt']);
                            ?>
							<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
				
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks medium"><?= $headline[6]['title']['rendered']; ?></p>
					<div class="desc small">
						<p><?= $headline[6]['excerpt']['rendered']; ?></p>
					</div></a>
				</div>
			</div>
			<!---- List biasa---->
			
			<!---- List biasa---->
    		<div class="listbox">
				<div class="listbox-left">
                <?php
                    $idBerita = $headline[7]['id'];
                    $slugnya = $headline[7]['slug'];
                ?>
                    <a href="<?= base_url('/') . $slugnya; ?>">
					<div class="img-holder" style="background-image:url(<?= $headline[7]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
							<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
						<a href="<?= base_url(''); ?><?= strtolower($headline[7]['cat_detail'][0]['name']); ?>"><div class="author-name"><span><?= $headline[7]['cat_detail'][0]['name']; ?></span></a>&nbsp;|&nbsp;<?= $headline[7]['author_detail']['name']; ?></div>
                            <?php
                                $UTC = strtotime($headline[7]['date_gmt']);
                            ?>
							<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
				
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks medium"><?= $headline[7]['title']['rendered']; ?></p>
					<div class="desc small">
						<p><?= $headline[7]['excerpt']['rendered']; ?>.</p>
					</div></a>
				</div>
			</div>
			<!---- List biasa---->
			
			<!---- List biasa---->
    		<div class="listbox">
				<div class="listbox-left">
                <?php
                    $idBerita = $headline[8]['id'];
                	$slugnya = $headline[8]['slug'];
                ?>
					<a href="<?= base_url('/') . $slugnya; ?>">
                    <div class="img-holder" style="background-image:url(<?= $headline[8]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
							<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
						<a href="<?= base_url(''); ?><?= strtolower($headline[8]['cat_detail'][0]['name']); ?>"><div class="author-name"><span><?= $headline[8]['cat_detail'][0]['name']; ?></span></a>&nbsp;|&nbsp;<?= $headline[8]['author_detail']['name']; ?></div>
                            <?php
                                $UTC = strtotime($headline[8]['date_gmt']);
                            ?>
							<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
				
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks medium"><?= $headline[8]['title']['rendered']; ?></p>
					<div class="desc small">
						<p><?= $headline[8]['excerpt']['rendered']; ?></p>
					</div></a>
				</div>
			</div>
			<!---- List biasa---->
			
			<!---- List biasa---->
    		<div class="listbox">
				<div class="listbox-left">
                <?php
                    $idBerita = $headline[9]['id'];
                    $slugnya = $headline[9]['slug'];
                ?>
                <a href="<?= base_url('/') . $slugnya; ?>">
					<div class="img-holder" style="background-image:url(<?= $headline[9]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
							<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
						<a href="<?= base_url(''); ?><?= strtolower($headline[9]['cat_detail'][0]['name']); ?>"><div class="author-name"><span><?= $headline[9]['cat_detail'][0]['name']; ?></span></a>&nbsp;|&nbsp;<?= $headline[9]['author_detail']['name']; ?></div>
                            <?php
                                $UTC = strtotime($headline[9]['date_gmt']);
                            ?>
							<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
				
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks medium"><?= $headline[9]['title']['rendered']; ?></p>
					<div class="desc small">
						<p><?= $headline[9]['excerpt']['rendered']; ?></p>
					</div></a>
				</div>
			</div>
			<!---- List biasa---->
			
			<!--BANNER AD-->
			<div class="banner-ad">
				<img src="<?= base_url('assets/frontend/');?>img/ad-middle-banner-640x90.jpg" width=100%>
			</div>
			
			<div style="margin-bottom:30px;"></div>
			
			<!---- List biasa---->
    		<div class="listbox">
                <?php
                    $slugnya = $headline[10]['slug'];
                ?>
				<div class="listbox-left">
                <a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[10]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
							<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
						<a href="<?= base_url(''); ?><?= strtolower($headline[10]['cat_detail'][0]['name']); ?>"><div class="author-name"><span><?= $headline[10]['cat_detail'][0]['name']; ?></span></a>&nbsp;|&nbsp;<?= $headline[10]['author_detail']['name']; ?></div>
                            <?php
                                $UTC = strtotime($headline[10]['date_gmt']);
                            ?>
							<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
				
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks medium"><?= $headline[10]['title']['rendered']; ?></p>
					<div class="desc small">
						<p><?= $headline[10]['excerpt']['rendered']; ?></p>
					</div></a>
				</div>
			</div>
			<!---- List biasa---->
			
			<!---- List biasa---->
    		<div class="listbox">
				<div class="listbox-left">
                <?php
                    $slugnya = $headline[11]['slug'];
                ?>
                    <a href="<?= base_url('/') . $slugnya; ?>">
					<div class="img-holder" style="background-image:url(<?= $headline[11]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
							<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
						<a href="<?= base_url(''); ?><?= strtolower($headline[11]['cat_detail'][0]['name']); ?>"><div class="author-name"><span><?= $headline[11]['cat_detail'][0]['name']; ?></span></a>&nbsp;|&nbsp;<?= $headline[11]['author_detail']['name']; ?></div>
                            <?php
                                $UTC = strtotime($headline[11]['date_gmt']);
                            ?>
							<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
				
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks medium"><?= $headline[11]['title']['rendered']; ?></p>
					<div class="desc small">
						<p><?= $headline[11]['excerpt']['rendered']; ?>.</p>
					</div></a>
				</div>
			</div>
			<!---- List biasa---->
			
			<!---- List biasa---->
    		<div class="listbox">
				<div class="listbox-left">
                <?php
                    $slugnya = $headline[12]['slug'];
                ?>
					<a href="<?= base_url('/') . $slugnya; ?>">
                    <div class="img-holder" style="background-image:url(<?= $headline[12]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
							<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
						<a href="<?= base_url(''); ?><?= strtolower($headline[12]['cat_detail'][0]['name']); ?>"><div class="author-name"><span><?= $headline[12]['cat_detail'][0]['name']; ?></span></a>&nbsp;|&nbsp;<?= $headline[12]['author_detail']['name']; ?></div>
                            <?php
                                $UTC = strtotime($headline[12]['date_gmt']);
                            ?>
							<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
				
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks medium"><?= $headline[12]['title']['rendered']; ?></p>
					<div class="desc small">
						<p><?= $headline[12]['excerpt']['rendered']; ?></p>
					</div></a>
				</div>
			</div>
			<!---- List biasa---->
			
			<!---- List biasa---->
    		<div class="listbox">
				<div class="listbox-left">
                <?php
                    $slugnya = $headline[13]['slug'];
                ?>
                <a href="<?= base_url('/') . $slugnya; ?>">
					<div class="img-holder" style="background-image:url(<?= $headline[13]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
							<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
						<a href="<?= base_url(''); ?><?= strtolower($headline[13]['cat_detail'][0]['name']); ?>"><div class="author-name"><span><?= $headline[13]['cat_detail'][0]['name']; ?></span></a>&nbsp;|&nbsp;<?= $headline[13]['author_detail']['name']; ?></div>
                            <?php
                                $UTC = strtotime($headline[13]['date_gmt']);
                            ?>
							<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
				
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks medium"><?= $headline[13]['title']['rendered']; ?></p>
					<div class="desc small">
						<p><?= $headline[13]['excerpt']['rendered']; ?></p>
					</div></a>
				</div>
			</div>
			<!---- List biasa---->
            
			<!---- List biasa---->
    		<div class="listbox">
				<div class="listbox-left">
                <?php
                    $slugnya = $headline[14]['slug'];
                ?>
                <a href="<?= base_url('/') . $slugnya; ?>">
					<div class="img-holder" style="background-image:url(<?= $headline[14]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
							<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
						<a href="<?= base_url(''); ?><?= strtolower($headline[14]['cat_detail'][0]['name']); ?>"><div class="author-name"><span><?= $headline[14]['cat_detail'][0]['name']; ?></span></a>&nbsp;|&nbsp;<?= $headline[14]['author_detail']['name']; ?></div>
                            <?php
                                $UTC = strtotime($headline[14]['date_gmt']);
                            ?>
							<div class="date"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
				
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks medium"><?= $headline[14]['title']['rendered']; ?></p>
					<div class="desc small">
						<p><?= $headline[14]['excerpt']['rendered']; ?></p>
					</div></a>
				</div>
			</div>
			<!---- List biasa---->
			<!-- <div style="clear:both;">
				<a href="<?= base_url('assets/frontend/'); ?>#"><div class="btn-load-more">Tampilkan Lebih Banyak</div></a>
				</div> -->
			
			
  		</div>
		<!---------------------------------------------------------- ------------------------------- col-left END -------------------------------------------------------------------------------------->

  		
		<!---------------------------------------------------------- ------------------------------- col-right START ----------------------------------------------------------------------------------->
		<div class="col-right">
    		<div class="title-section">Terpopuler</div>
			<div style="margin-top:20px;"></div>
			
			<!---- List ---->
			<div class="row-list rightcol">
                <?php
                    $slugnya = $headline[15]['slug'];
                ?>
				<div class="kol-separuh-rightcol left">
                <a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[15]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
					<a href="<?= base_url(''); ?><?= strtolower($headline[15]['cat_detail'][0]['name']); ?>"><div class="author-name small"><span><?= $headline[15]['cat_detail'][0]['name']; ?></span></a>&nbsp; | &nbsp;<?= $headline[15]['author_detail']['name']; ?></div>
                        <?php
                            $UTC = strtotime($headline[15]['date_gmt']);
                        ?>
						<div class="date small"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $headline[15]['title']['rendered']; ?></p></a>
				</div>
			</div>
			<!---- List ---->
			<!---- List ---->
			<div class="row-list rightcol">
                <?php
                    $idBerita = $headline[16]['id'];
                    $slugnya = $headline[16]['slug'];
                ?>
				<div class="kol-separuh-rightcol left">
                <a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[16]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
					<a href="<?= base_url(''); ?><?= strtolower($headline[16]['cat_detail'][0]['name']); ?>"><div class="author-name small"><span><?= $headline[16]['cat_detail'][0]['name']; ?></span></a>&nbsp; | &nbsp;<?= $headline[16]['author_detail']['name']; ?></div>
                        <?php
                            $UTC = strtotime($headline[16]['date_gmt']);
                        ?>
						<div class="date small"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $headline[16]['title']['rendered']; ?></p></a>
				</div>
			</div>
			<!---- List ---->
			<!---- List ---->
			<div class="row-list rightcol">
                <?php
                    $idBerita = $headline[17]['id'];
                    $slugnya = $headline[17]['slug'];
                ?>
				<div class="kol-separuh-rightcol left">
                <a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[17]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
					<a href="<?= base_url(''); ?><?= strtolower($headline[17]['cat_detail'][0]['name']); ?>"><div class="author-name small"><span><?= $headline[17]['cat_detail'][0]['name']; ?></span></a>&nbsp; | &nbsp;<?= $headline[17]['author_detail']['name']; ?></div>
                        <?php
                            $UTC = strtotime($headline[17]['date_gmt']);
                        ?>
						<div class="date small"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $headline[17]['title']['rendered']; ?></p></a>
				</div>
			</div>
			<!---- List ---->
			<!---- List ---->
			<div class="row-list rightcol">
                <?php
                    $idBerita = $headline[18]['id'];
                    $slugnya = $headline[18]['slug'];
                ?>
				<div class="kol-separuh-rightcol left">
                <a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[18]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
					<a href="<?= base_url(''); ?><?= strtolower($headline[18]['cat_detail'][0]['name']); ?>"><div class="author-name small"><span><?= $headline[18]['cat_detail'][0]['name']; ?></span></a>&nbsp; | &nbsp;<?= $headline[18]['author_detail']['name']; ?></div>
                        <?php
                            $UTC = strtotime($headline[18]['date_gmt']);
                        ?>
						<div class="date small"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $headline[18]['title']['rendered']; ?></p></a>
				</div>
			</div>
			<!---- List ---->
			<!---- List ---->
			<div class="row-list rightcol">
                <?php
                    $idBerita = $headline[19]['id'];
                    $slugnya = $headline[19]['slug'];
                ?>
				<div class="kol-separuh-rightcol left">
                <a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[19]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
					<a href="<?= base_url(''); ?><?= strtolower($headline[19]['cat_detail'][0]['name']); ?>"><div class="author-name small"><span><?= $headline[19]['cat_detail'][0]['name']; ?></span></a>&nbsp; | &nbsp;<?= $headline[19]['author_detail']['name']; ?></div>
                        <?php
                            $UTC = strtotime($headline[19]['date_gmt']);
                        ?>
						<div class="date small"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $headline[19]['title']['rendered']; ?></p></a>
				</div>
			</div>
			<!---- List ---->
			<!---- List ---->
			<div class="row-list rightcol">
                <?php
                    $slugnya = $headline[20]['slug'];
                ?>
				<div class="kol-separuh-rightcol left">
                <a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[20]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
					<a href="<?= base_url(''); ?><?= strtolower($headline[20]['cat_detail'][0]['name']); ?>"><div class="author-name small"><span><?= $headline[20]['cat_detail'][0]['name']; ?></span></a>&nbsp; | &nbsp;<?= $headline[20]['author_detail']['name']; ?></div>
                        <?php
                            $UTC = strtotime($headline[20]['date_gmt']);
                        ?>
						<div class="date small"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $headline[20]['title']['rendered']; ?></p></a>
				</div>
			</div>
			<!---- List ---->
			<!---- List ---->
			<div class="row-list rightcol">
                <?php
                    $slugnya = $headline[21]['slug'];
                ?>
				<div class="kol-separuh-rightcol left">
                <a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[21]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
					<a href="<?= base_url(''); ?><?= strtolower($headline[21]['cat_detail'][0]['name']); ?>"><div class="author-name small"><span><?= $headline[21]['cat_detail'][0]['name']; ?></span></a>&nbsp; | &nbsp;<?= $headline[21]['author_detail']['name']; ?></div>
                        <?php
                            $UTC = strtotime($headline[21]['date_gmt']);
                        ?>
						<div class="date small"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $headline[21]['title']['rendered']; ?></p></a>
				</div>
			</div>
			<!---- List ---->
			<!---- List ---->
			<div class="row-list rightcol">
                <?php
                    $slugnya = $headline[22]['slug'];
                ?>
				<div class="kol-separuh-rightcol left">
                <a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[22]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
					<a href="<?= base_url(''); ?><?= strtolower($headline[22]['cat_detail'][0]['name']); ?>"><div class="author-name small"><span><?= $headline[22]['cat_detail'][0]['name']; ?></span></a>&nbsp; | &nbsp;<?= $headline[22]['author_detail']['name']; ?></div>
                        <?php
                            $UTC = strtotime($headline[22]['date_gmt']);
                        ?>
						<div class="date small"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $headline[22]['title']['rendered']; ?></p></a>
				</div>
			</div>
			<!---- List ---->
			<!---- List ---->
			<div class="row-list rightcol">
                <?php
                    $slugnya = $headline[23]['slug'];
                ?>
				<div class="kol-separuh-rightcol left">
                <a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[23]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
					<a href="<?= base_url(''); ?><?= strtolower($headline[23]['cat_detail'][0]['name']); ?>"><div class="author-name small"><span><?= $headline[23]['cat_detail'][0]['name']; ?></span></a>&nbsp; | &nbsp;<?= $headline[23]['author_detail']['name']; ?></div>
                        <?php
                            $UTC = strtotime($headline[23]['date_gmt']);
                        ?>
						<div class="date small"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $headline[23]['title']['rendered']; ?></p></a>
				</div>
			</div>
			<!---- List ---->
			<!---- List ---->
			<div class="row-list rightcol">
                <?php
                    $slugnya = $headline[24]['slug'];
                ?>
				<div class="kol-separuh-rightcol left">
                <a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $headline[24]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
					<a href="<?= base_url(''); ?><?= strtolower($headline[5]['cat_detail'][0]['name']); ?>"><div class="author-name small"><span><?= $headline[24]['cat_detail'][0]['name']; ?></span></a>&nbsp; | &nbsp;<?= $headline[24]['author_detail']['name']; ?></div>
                        <?php
                            $UTC = strtotime($headline[24]['date_gmt']);
                        ?>
						<div class="date small"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $headline[24]['title']['rendered']; ?></p></a>
				</div>
			</div>
			<!---- List ---->
			
			
			<div style="margin-top:30px;"></div>
			
			<!--BANNER AD-->
				<div class="title-section">Advertisement</div>
				
				<div style="margin-top:20px;"></div>
				<div class="banner-ad">
					<img src="<?= base_url('assets/frontend/');?>img/ad-rectangle-banner-300x250.jpg" width=300>
				</div>
				<div style="margin-top:30px;"></div>
			
			
			
			<div class="title-section" style="clear:both;">Pengguna Baru</div>
			<div style="margin-top:20px;"></div>
			
			
			
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[0]->name; ?></div>
						<!-- <div class="jml-artikel">21 Artikel</div> -->
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[1]->name; ?></div>
						<!-- <div class="jml-artikel">19 Artikel</div> -->
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[2]->name; ?></div>
						<!-- <div class="jml-artikel">21 Artikel</div> -->
					</div>
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[3]->name; ?></div>
						<!-- <div class="jml-artikel">19 Artikel</div> -->
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[4]->name; ?></div>
						<!-- <div class="jml-artikel">21 Artikel</div> -->
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<div style="margin-top:30px;"></div>
			
			<!--BANNER AD-->
				<div class="title-section">Advertisement</div>
				
				<div style="margin-top:20px;"></div>
				<div class="banner-ad">
					<img src="<?= base_url('assets/frontend/');?>img/ad-rectangle-banner-300x250.jpg" width=300>
				</div>
				<div style="margin-top:30px;"></div>
			
  		</div>
		<!---------------------------------------------------------- ------------------------------- col-right END ------------------------------------------------------------------------------------->
	</div>
	<!-- content-wrapper END -->
