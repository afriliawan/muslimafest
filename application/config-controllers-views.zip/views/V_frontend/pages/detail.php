
	<!-- content-wrapper START -->
	<div class="content-wrapper" style="overflow:auto; clear:both;">
		<!---------------------------------------------------------- ------------------------------- col-left START ------------------------------------------------------------------------------------->
		<?php foreach($hasil as $d){ ?>
		<div class="col-left">
		<a href="<?= base_url(''); ?><?= strtolower($d->cat_detail[0]->name); ?>"><div class="title-detail"><?= $d->cat_detail[0]->name; ?></div></a>
			<h1 class="headline-title-teks detail"><?= $d->title->rendered; ?></h1>
            
				<div class="author">
					<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
						</div>
					</div>
					<div class="author-right">
						<div class="author-name detail"><?= $d->author_detail->name; ?></div>
                        <?php
							$UTC = strtotime($d->date_gmt);
						?>
						<div class="date detail">| <?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
				</div>
				
				<div style="margin-top:40px;"></div>
				
				<!-- <a href="https://news.google.com/publications/CAAqBwgKMLv0lAswsMeqAw?hl=id&gl=ID&ceid=ID%3Aid" target="_blank"><div class="btn-gnews"><img src="<?= base_url('assets/frontend/'); ?>img/icon-gnews.png" width=35 style="margin-top: -7px;">&nbsp;&nbsp;ikuti kami di Google News</div></a> -->
				
				<div style="margin-top:20px;"></div>
			
				<section class="valign bottom headline detail" style="background-image:url(<?= $d->jetpack_featured_media_url; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
					<div class="headline-title-box detail">
						<!-- <div class="photo-credit">Foto: Instagram</div> -->
					</div>
				</section>
			
			
			
			<div style="margin-top:20px;"></div>
				
				
				<!-- Start Content Artikel -->
				<div class="content-artikel">
				<!--Replace Width dan Height, perlu disetting height="100%"; -->
				<?= preg_replace('#(<img.+?)width=100%(["\']?)\d*\2(.*?/?>)#i', '$1$3',preg_replace('#(<img.+?)height=(["\']?)\d*\2(.*?/?>)#i', '$1$3', $d->content->rendered));
                ?>
				
				<!-- Baca Juga START -->
				<div class="title-section">Baca Juga</div>
				
				
				<div class="row-list bacajuga">
					<!---- List ---->
					<div class="row-list rightcol bacajuga">
						<div class="kol-separuh-rightcol left">
						<?php
							$idBerita = $hasilCategories[0]['id'];
							$slugnya = $hasilCategories[0]['slug'];
						?>
						<a href="<?= base_url('/') . $slugnya; ?>">
							<div class="img-holder" style="background-image:url(<?= $hasilCategories[0]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
						</div>
				
						<div class="kol-separuh-rightcol right">
							<!--<div class="author">
								<div class="author-name small"><span>Unik</span>&nbsp; | &nbsp;Debby Harry</div>
								<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
							</div>-->
							<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $hasilCategories[0]['title']['rendered'];?></p></a>
						</div>
					</div>
					<!---- List ---->
			
					<!---- List ---->
					<div class="row-list rightcol bacajuga">
						<div class="kol-separuh-rightcol left">
						<?php
							$idBerita = $hasilCategories[1]['id'];
							$slugnya = $hasilCategories[1]['slug'];

						?>
						<a href="<?= base_url('/') . $slugnya; ?>">
							<div class="img-holder" style="background-image:url(<?= $hasilCategories[1]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
						</div>
				
						<div class="kol-separuh-rightcol right">
							<!--<div class="author">
								<div class="author-name small"><span>Unik</span>&nbsp; | &nbsp;Debby Harry</div>
								<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
							</div>-->
							<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $hasilCategories[1]['title']['rendered'];?></p></a>
						</div>
					</div>
					<!---- List ---->
					
					<!---- List ---->
					<div class="row-list rightcol bacajuga">
						<div class="kol-separuh-rightcol left">
						<?php
							$idBerita = $hasilCategories[2]['id'];
							$slugnya = $hasilCategories[2]['slug'];
						?>
						<a href="<?= base_url('/') . $slugnya; ?>">
							<div class="img-holder" style="background-image:url(<?= $hasilCategories[2]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
						</div>
				
						<div class="kol-separuh-rightcol right">
							<!--<div class="author">
								<div class="author-name small"><span>Unik</span>&nbsp; | &nbsp;Debby Harry</div>
								<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
							</div>-->
							<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $hasilCategories[2]['title']['rendered'];?></p></a>
						</div>
					</div>
					<!---- List ---->
			
					<!---- List ---->
					<div class="row-list rightcol bacajuga">
						<div class="kol-separuh-rightcol left">
						<?php
							$idBerita = $hasilCategories[3]['id'];
						?>
						<a href="<?= base_url('/') . $slugnya; ?>">
							<div class="img-holder" style="background-image:url(<?= $hasilCategories[3]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
						</div>
				
						<div class="kol-separuh-rightcol right">
							<!--<div class="author">
								<div class="author-name small"><span>Unik</span>&nbsp; | &nbsp;Debby Harry</div>
								<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
							</div>-->
							<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $hasilCategories[3]['title']['rendered'];?></p></a>
						</div>
					</div>
					<!---- List ---->
					
					
				</div>
				<!-- Baca Juga END -->
				
				<div style="margin-top:90px;"></div>
				</div>
				<!-- End Content Artikel -->
				
				<div style="margin-top:30px;"></div>

				<div class="list-topik">
					<div class="label-topik"><img src="<?= base_url('assets/frontend/'); ?>img/label-topik.png" width=70></div>
					<?php
								$tags = $d->tag_detail;
								$a = "";
								$i = 0;
								
								foreach ($tags as $allTags) {
									if($i==0){
										$a = '<li class="topik">' . $allTags->name . '</li>';
									} else {
										$a = $a . ',' . '<li class="topik">' . $allTags->name . '</li>';
									}
									$i++;
								}
					?>
					<ul>
						<?= $a; ?>
					</ul>
				</div>
				
				<div style="margin-top:30px;"></div>
				
				<div class="share-box">
					<div class="label-share"><img src="<?= base_url('assets/frontend/'); ?>img/icon-share.png" width=24>&nbsp;&nbsp;share</div>
					<div class="share-holder">
						<ul>
							<li class="socmed-item-square facebook">
							<?php
								$slugnya = $hasilCategories[0]['slug'];
								$urlUGC = "https://ugc.hops.id/";
								$urlFB = "https://www.facebook.com/sharer.php?u=".$urlUGC.$slugnya;
							?>
								<a href="<?= $urlFB; ?>"><i class="fa fa-facebook" style="font-size:16px; color:#eee;"></i></a>
							</li>
							<li class="socmed-item-square twitter">
							<?php
								$slugnya = $hasilCategories[0]['slug'];
								$urlUGC = "https://ugc.hops.id/";
								$title = $d->title->rendered;
								$urlTwitter = "https://twitter.com/intent/tweet?text=".$title."&url=".$urlUGC.$slugnya;
							?>
								<a href="<?=$urlTwitter; ?>"><i class="fa fa-twitter" style="font-size:16px; color:#eee;"></i></a>
							</li>
							<li class="socmed-item-square linkedin">
							<?php
								$slugnya = $hasilCategories[0]['slug'];
								$urlUGC = "https://ugc.hops.id/";
								$title = $d->title->rendered;
								$urlLinkedin = "https://www.linkedin.com/shareArticle?mini=true&url=".$urlUGC.$slugnya."/&title=".$title;
							?>
								<a href="<?= $urlLinkedin; ?>"><i class="fa fa-linkedin" style="font-size:16px; color:#eee;"></i>
							</li>
							<li class="socmed-item-square get-pocket">
								<i class="fa fa-get-pocket" style="font-size:16px; color:#eee;"></i>
							</li>
							<li class="socmed-item-square">
								<i class="fa fa-envelope" style="font-size:16px; color:#eee;"></i>
							</li>
							<li class="socmed-item-square">
								<i class="fa fa-print" style="font-size:16px; color:#eee;"></i>
							</li>
						</ul>
					</div>
				</div>
				
				<div style="margin-top:30px;"></div>
			
			
			
			<!--BANNER AD-->
			<div class="banner-ad">
				<img src="<?= base_url('assets/frontend/'); ?>img/ad-middle-banner-640x90.jpg" width=100%>
			</div>
			
			<div style="margin-bottom:30px;"></div>
			
	
			<div class="title-section">Artikel Terkait</div>
				
				<div style="margin-bottom:20px;"></div>
				<!--START Listing Artikel Terkait-->
				
				<div class="row-list">
                    <?php
                        foreach($hasilTags as $hTa){ 
							$idBerita = $hTa['id'];?>
						
					<div class="kol-sepertiga artikel-terkait left">
					<a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder artikel-terkait" style="background-image:url(<?= $hTa['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
						<?php $slugnya = $d->slug; ?>
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small artikel-terkait"><?= $hTa['title']['rendered']; ?></p></a>
                        
					</div>
                    <?php } ?>
				</div>

			

			<!-- <div style="margin-top:50px;"></div> -->
				
				<!-- Form Komentar -->
				
				<!-- <div class="title-section" style="clear: both;">Apa Komentarmu?</div>
				<br>
				<form>
				<label for="nme">Nama <span style="color:red;">*</span> :</label>
				<input type="text" id="fname" name="username" placeholder="Masukkan nama..">
				<br><br>
				<label for="email">Email <span style="color:red;">*</span> :</label>
  				<input type="text" id="femail" name="email" placeholder="Masukkan alamat email..">
				<br><br>
  				<label for="msg">Isi Komentarmu :</label>
  				<textarea id="subject" name="subject" placeholder="Tuliskan komentarmu.." style="height:200px"></textarea>
  				
				<div class="row-full" style="text-align:right;"><span style="color:red;">*</span> wajib diisi</div>
  				<input type="submit" value="Kirim Komentar" />
				</form>
				
				
				
				<div style="margin-bottom:40px;"></div> -->
			
			
			
				
			
			
			
  		</div>
  	<?php } ?>
		<!---------------------------------------------------------- ------------------------------- col-left END -------------------------------------------------------------------------------------->

  		
		<!---------------------------------------------------------- ------------------------------- col-right START ----------------------------------------------------------------------------------->
		<div class="col-right">
    		<div class="title-section">Pengguna Baru</div>
			<div style="margin-top:20px;"></div>
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[0]->name; ?></div>
						<!-- <div class="jml-artikel">21 Artikel</div> -->
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[1]->name; ?></div>
						<!-- <div class="jml-artikel">19 Artikel</div> -->
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[2]->name; ?></div>
						<!-- <div class="jml-artikel">21 Artikel</div> -->
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[3]->name; ?></div>
						<!-- <div class="jml-artikel">19 Artikel</div> -->
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name"><?= $listUser[4]->name; ?></div>
						<!-- <div class="jml-artikel">21 Artikel</div> -->
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<div style="margin-top:30px;"></div>
			
			<!--BANNER AD-->
				<div class="title-section">Advertisement</div>
				
				<div style="margin-top:20px;"></div>
				<div class="banner-ad">
					<img src="<?= base_url('assets/frontend/'); ?>img/ad-rectangle-banner-300x250.jpg" width=300>
				</div>
				<div style="margin-top:30px;"></div>
			
			
			
			<div class="title-section" style="clear:both;">Terbaru</div>
			<div style="margin-top:20px;"></div>
			
			
			<!---- List ---->
            <?php
                    foreach($hasilTerbaru as $hTe){ 
						$idBerita = $hTe->id;
						$slugnya = $hTe->slug;
						?>
			<div class="row-list rightcol">
				<div class="kol-separuh-rightcol left">
				<a href="<?= base_url('/') . $slugnya; ?>"><div class="img-holder" style="background-image:url(<?= $hTe->jetpack_featured_media_url; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
                        <?php
							$UTC = strtotime($hTe->date_gmt);
							foreach($hTe->cat_detail as $cd){ ?>
								<a href="<?= base_url(''); ?><?= strtolower($cd->name); ?>"><div class="author-name small"><span><?= $cd->name; ?></span></a>&nbsp; | &nbsp;<?= $hTe->author_detail->name; ?></div>
							<?php } ?>
						<div class="date small"><?= date("Y/m/d | H:i", $UTC + 7*60*60); ?></div>
					</div>
				
					<a href="<?= base_url('/') . $slugnya; ?>"><p class="headline-title-teks small"><?= $hTe->title->rendered; ?></p></a>
				</div>
			</div>
			<!---- List ---->
			
            <?php } ?>
			
			
			<!--BANNER AD-->
				<div class="title-section">Advertisement</div>
				
				<div style="margin-top:20px;"></div>
				<div class="banner-ad">
					<img src="<?= base_url('assets/frontend/'); ?>img/ad-rectangle-banner-300x250.jpg" width=300>
				</div>
				<div style="margin-top:30px;"></div>
			
			
			
			
  		</div>
		<!---------------------------------------------------------- ------------------------------- col-right END ------------------------------------------------------------------------------------->
	</div>
	<!-- content-wrapper END -->	