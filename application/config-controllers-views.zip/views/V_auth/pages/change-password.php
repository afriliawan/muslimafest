<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">


<link href="<?= base_url('assets/frontend/'); ?>assets/css/auth.css" rel="stylesheet" type="text/css" media="all">

<title>Reset password</title>
</head>
<body>

<div class="page-wrapper"><!-- page-wrapper START -->
	<!-- content-wrapper START -->
	<div class="content-wrapper-absolute-center reset-pwd">
		<div class="auth-col-left">
			<a href="<?= base_url(''); ?>"><img src="assets/img/hops-logo.png" width=112></a>
		</div>
		<div class="auth-col-right">
			<div class="auth-box-title">
				Reset password akun (email)
			</div>
			<div class="auth-field">
				<div class="row-full">
					<input type="text" id="password" name="password1" placeholder="Masukkan password baru..">
				</div>
				<div class="row-full" style="margin-top: 20px;">
					<input type="text" id="password" name="password2" placeholder="Masukkan ulang password baru..">
				</div>
				
				<div class="row-full" style="margin-top: 20px;">
				 <input type="submit" value="Ubah Password">
				 </div>
			</div>
			
			<div class="auth-box-btm" style="margin-top: 40px;">
				<div class="kol-separuh left"><a href="<?= base_url('C_auth/forgotPassword'); ?>"><span>Lupa password</span></a></div>
				<div class="kol-separuh right"><a href="<?= base_url('C_auth/login'); ?>"><span>Sudah punya akun? Login!</span></a></a>
				
			</div>
			
		</div>
	
	</div>
	<!-- content-wrapper END -->

	
	
	
	
</div><!-- page-wrapper END -->







	
</body>
</html>
