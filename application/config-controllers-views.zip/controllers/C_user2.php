<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_user extends CI_Controller 
{

    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }
    
    public function index()
    {
        $data['title'] = 'My Profile'; 
        // $data['user'] = $this->db->get_where('ms_users', ['email' => $this->session->userdata('email')])->row_array();
        $data['user'] = $this->session->all_userdata();
        // var_dump($data);
        // echo '<pre>'; print_r($this->session->all_userdata());exit;
        // die;
        $this->load->view('V_backend/templates/header', $data);
        $this->load->view('V_backend/templates/sidebar');
        $this->load->view('V_backend/templates/topbar');
        $this->load->view('V_backend/pages/user/index', $data);
        $this->load->view('V_backend/templates/footer');    
    }
    
    public function editProfile()
    {
        $data['title'] = 'Edit Profile';
        // echo '<pre>'; print_r($this->session->all_userdata());exit;
        $data['user'] = $this->session->userdata();
        $this->form_validation->set_rules('name', 'Full name', 'required');
        // $this->form_validation->set_rules('nohp', 'number phone ', 'min_length[12]', 'max_length[13]');
        // $this->form_validation->set_rules('alamat', 'Address name', 'regex_match[/[a-zA-Z]$/]');

        if($this->form_validation->run() == false){
            $this->load->view('V_backend/templates/header', $data);
            $this->load->view('V_backend/templates/sidebar');
            $this->load->view('V_backend/templates/topbar');
            $this->load->view('V_backend/pages/user/edit-profile', $data);
            $this->load->view('V_backend/templates/footer'); 
        } else {
            $curl = curl_init();
            $id = $this->session->userdata('id');
            $url = $this->input->post('url');
            var_dump($url);
            die;
            $name = $this->input->post('name');
    
            curl_setopt_array($curl, array(
    
            CURLOPT_URL => "https://beta.hops.id/wp-json/ext/v2/users/".$id."?url=".$url."&name=".$name."",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "PUT",
            CURLOPT_HTTPHEADER => array(
                "id: ".$this->input->post('id')."",
                "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
            ),
            ));
    
            $response = curl_exec($curl);
    
            var_dump($response);
            die;
            curl_close($curl);
            $this->session->set_userdata('name', $name);
            $this->session->set_userdata('url', $url);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Data has been changed! <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            // print_r($data);
            redirect('C_user');
        }
    }

    // public function changePassword()
    // {
    //     $data['title'] = 'Change Password';
    //     $this->load->view('V_backend/templates/header', $data);
    //     $this->load->view('V_backend/templates/sidebar');
    //     $this->load->view('V_backend/templates/topbar');
    //     $this->load->view('V_backend/pages/user/change-password', $data);
    //     $this->load->view('V_backend/templates/footer');    
    // }

    public function changePassword()
    {
        $data['title'] = 'Change Password';
        // $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user'] = $this->session->userdata();
        //Function dibawah ini adalah apa saja yang dibutuhkan untuk mengganti password
        // $this->form_validation->set_rules('currentPassword', 'Current Password', 'required|trim');
        $this->form_validation->set_rules('newPassword1', 'New Password', 'required|trim|min_length[3]|matches[newPassword2]');
        $this->form_validation->set_rules('newPassword2', 'Confirm New Password', 'required|trim|min_length[3]|matches[newPassword1]');
        //min_length[3] adalah jumlah digit password minimal 3 digit.

        if ($this->form_validation->run() == false) {
            $this->load->view('V_backend/templates/header', $data);
            $this->load->view('V_backend/templates/sidebar');
            $this->load->view('V_backend/templates/topbar');
            $this->load->view('V_backend/pages/user/change-password', $data);
            $this->load->view('V_backend/templates/footer');  
        } else {
            //jika password salah
            $curl = curl_init();
            $sessionUsername = $this->session->userdata('username');
            $sessionID = $this->session->userdata('id');
            $sessionEmail = $this->session->userdata('email');
            $currentPassword = $this->input->post('currentPassword');
            $newPassword = $this->input->post('newPassword1');
            curl_setopt_array($curl, array(
                // https://beta.hops.id/wp-json/wp/v2/users/changepassword?username=testacc1&email=testacc1@gmail.com&password=123123&new_password=123123123
                // https://beta.hops.id/wp-json/wp/v2/users/changepassword?username=".$username."&email=".$sessionEmail."&password=".$currentPassword."&new_password=$newPassword
            // CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/users/changepassword?username=".$sessionUsername."&email=".$sessionEmail."&password=".$currentPassword."&new_password=".$newPassword."",
            // Sebelumnya
            CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/users/changepassword?username=".$sessionUsername."&password=".$currentPassword."&email=".$sessionEmail."",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_HTTPHEADER => array(
                "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
            ),
            ));
            $response = curl_exec($curl);
            // var_dump($response);
            // die;
            //Untuk mengetahui data array apa saja yang tersedia
            $existUser = json_decode($response);
            var_dump ($response);
            die;
             //Mengecek data user berdasarkan ID
            if($existUser->data->ID) 
            {
                $id = $this->input->post('id');
                $newPassword = $this->input->post('newPassword1');
                $username = $this->session->userdata('username');

                curl_setopt_array($curl, array(
                // CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/users/52?password=123123123&email=lupapw@gmail.com&username=lupapw",
                CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/users/changepassword/".$id."?password=".$newPassword."&username=".$username."",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_HTTPHEADER => array(
                    "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
                    ),
                ));

                $response = curl_exec($curl);
                curl_close($curl);
            // $currentPassword = $this->input->post('currentPassword');
            // $newPassword = $this->input->post('newPassword1');
            // if (!password_verify($currentPassword, $data['user']['password'])) {
            //     $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Wrong current password!</div>');
            //     redirect('C_user/changepassword');
            // } else {
                //jika password baru sama dengan password lama, maka akan terjadi error password.
                // if ($currentPassword == $newPassword) {
                //     $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">New password cannot be
                //     the same as current password! </div>');
                //     redirect('C_user/changepassword');
                // } else {
                    //password sudah benar
                    // $password_hash = password_hash($newPassword, PASSWORD_DEFAULT);

                    // $this->db->set('password', $password_hash);
                    // $this->db->where('email', $this->session->userdata('email'));
                    // $this->db->update('C_user');

                    $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">Password changed! </div>');
                        // redirect('C_user/changepassword');
                    // }
            }else{
                
                echo $existUser;
                die;
                $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Wrong current password!</div>');
            }
            redirect('C_user/changepassword');
        } 
    }
    // public function changePassword()
    // {
    //     $data['title'] = 'Change Password';
    //     $data['user'] = $this->session->userdata();
    //     //Function dibawah ini adalah apa saja yang dibutuhkan untuk mengganti password
    //     $this->form_validation->set_rules('currentPassword', 'Current Password', 'required|trim');
    //     $this->form_validation->set_rules('newPassword1', 'New Password', 'required|trim|min_length[3]|matches[newPassword2]');
    //     $this->form_validation->set_rules('newPassword2', 'Confirm New Password', 'required|trim|min_length[3]|matches[newPassword1]');
    //     //min_length[3] adalah jumlah digit password minimal 3 digit.

    //     if ($this->form_validation->run() == false) {
    //         $data['title'] = 'Change Password';
    //         $this->load->view('V_backend/templates/header', $data);
    //         $this->load->view('V_backend/templates/sidebar');
    //         $this->load->view('V_backend/templates/topbar');
    //         $this->load->view('V_backend/pages/user/change-password', $data);
    //         $this->load->view('V_backend/templates/footer');  
    //     } else {
    //         //jika password salah
    //         $id = $this->input->post('id');
    //         $username = $this->input->post('username');
    //         $currentPassword = $this->input->post('currentPassword');
    //         $newPassword = $this->input->post('newPassword1');
    //         $curl = curl_init();
    //         curl_setopt_array($curl, array(
    //             CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/users/?".$id."?password=".$password."",
    //             CURLOPT_RETURNTRANSFER => true,
    //             CURLOPT_ENCODING => "",
    //             CURLOPT_MAXREDIRS => 10,
    //             CURLOPT_TIMEOUT => 0,
    //             CURLOPT_FOLLOWLOCATION => true,
    //             CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    //             CURLOPT_CUSTOMREQUEST => "PUT",
    //             CURLOPT_HTTPHEADER => array(
    //             "username: " . $username,
    //             "password: " . $newPassword,
    //             "Cookie: wordpress_logged_in_45d7f6c9d55265d57c136b000dfb6996=akhil%7C1605515826%7CVJtSv8uoLQw4FmOStvNN7pZptROxv1m3UdqBXGljNZx%7C51cb5edece4195ccf662f7ac7e8651bcd7d98ed97c8ce7706a126ab37fc200b2"
    //             ),
    //         ));
    //         // var_dump($response);
    //         // die;
    //             $existUser = json_decode($response);
    //             // var_dump($response);
    //             // die;
    //             curl_close($curl);
    //                 //jika password baru sama dengan password lama, maka akan terjadi error password.
    //                 if ($currentPassword == $newPassword) {
    //                     $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">New password cannot be
    //                     the same as current password! </div>');
    //                     redirect('user/changepassword');
    //                 } else {
    //                     //password sudah benar
    //                     $password_hash = password_hash($newPassword, PASSWORD_DEFAULT);
    
                        
    //                     $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">Password changed! </div>');
    //                     redirect('C_user/changepassword');
    //                 }
                
    //     }
        
    }