<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">


<link href="<?= base_url('assets/frontend/'); ?>css/auth.css" rel="stylesheet" type="text/css" media="all">

<title>Lupa password</title>
</head>
<body>

<div class="page-wrapper"><!-- page-wrapper START -->
	<!-- content-wrapper START -->
	<div class="content-wrapper-absolute-center lupa-pwd">
		<div class="auth-col-left">
			<a href="#"><img src="<?= base_url('assets/frontend/'); ?>img/hops-logo.png" width=112></a>
		</div>
		<div class="auth-col-right">
			<div class="auth-box-title">
				<div style="margin-top:20px;"></div>
				Lupa password?
			</div>
            <?= $this->session->flashdata('message'); ?>

            <form class="user" method="post" action="<?= base_url('C_auth/forgotPassword'); ?>">
			<div class="auth-field">
				<div class="row-full" style="margin-top: 20px;">
					<input type="text" id="email" name="email" placeholder="Masukkan email Anda..">
				</div>
				
				<div class="row-full" style="margin-top: 20px;">
				 <input type="submit" value="Reset Password">
				 </div>
			</div>
            </form>
			<div class="auth-box-btm" style="margin-top: 40px;">
				<div class="kol-separuh"><a href="<?= base_url('C_auth'); ?>"><span>Kembali ke halaman Login</span></a></div>
				
			</div>
			
		</div>
	
	</div>
	<!-- content-wrapper END -->

	
	
	
	
</div><!-- page-wrapper END -->







	
</body>
</html>
