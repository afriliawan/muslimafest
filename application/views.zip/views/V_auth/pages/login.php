<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">


<link href="<?= base_url('assets/frontend/'); ?>css/auth.css" rel="stylesheet" type="text/css" media="all">

<title>Login</title>
</head>
<body>
<div class="page-wrapper"><!-- page-wrapper START -->
	
	<!-- content-wrapper START -->
	<div class="content-wrapper-absolute-center login">
		<div class="auth-col-left">
			<a href="<?= base_url('C_frontend'); ?>"><img src="<?= base_url('assets/frontend/'); ?>img/hops-logo.png" width=112></a>
		</div>
		<div class="auth-col-right">
			<div class="auth-box-title">
				Login
			</div>
			
			<div class="row">
				<div class="col-lg-8">
					<?= $this->session->flashdata('message'); ?>
				</div>
        	</div>

			<form  method="post" action="<?= base_url('login'); ?>">
			<div class="auth-field">
				<div class="row-full">
					<input type="text" id="username" name="username" placeholder="Masukkan username..">
				</div>
				<div class="row-full" style="margin-top: 20px;">
					<input type="password" id="password" name="password" placeholder="Masukkan password..">
				</div>
				
				<div class="row-full" style="margin-top: 20px;">
				 <input type="submit" value="Login">
				 </div>
			</div>
			</form>
			<div class="auth-box-btm" style="margin-top: 40px;">
				<div class="kol-sepertiga left"><a href="<?= base_url('lupa-password'); ?>"><span>Lupa password</span></a></div>
				<!-- <div class="kol-sepertiga ctr"><a href="#"><span>Download aplikasi</span></a></div> -->
				<div class="kol-sepertiga right"><a href="<?= base_url('daftar'); ?>"><span>Belum punya akun? <BR> Daftar sekarang!</span></a></a>
				
			</div>
			
		</div>
	
	</div>
	<!-- content-wrapper END -->

	
	
	
	
</div><!-- page-wrapper END -->







	
</body>
</html>
