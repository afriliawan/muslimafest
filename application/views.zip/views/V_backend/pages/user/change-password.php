  <!------------------------------------------------------------------------------- Kolom Kanan START --------------------------------------------------------------------------->
  <section class="grid">
    <article>
		<div class="title-article">Ubah Password</div>
	
		<div class="box-article pwd">
			<div class="auth-field">
				<!--harus ditaruh sebelum form action-->
				<?= $this->session->flashdata('message'); ?>

				<form action="<?= base_url('C_user/changePassword'); ?>" method="post">	
				<div class="row-full">
					<label>Password saat ini:</label>
					<input type="text" id="password" name="password" placeholder="Masukkan password saat ini..">
					<?= form_error('password','<small class="text-danger pl-3">','</small>');?>
				</div>
				<div class="row-full" style="margin-top: 20px;">
					<label>Password baru:</label>
					<input type="text" id="new_password" name="new_password" placeholder="Masukkan password baru..">
					<?= form_error('new_password','<small class="text-danger pl-3">','</small>');?>
				</div>
				<div class="row-full" style="margin-top: 20px;">
					<label>Ulangi password baru:</label>
					<input type="text" id="newPassword2" name="newPassword2" placeholder="Masukkan ulang password baru..">
					<?= form_error('newPassword2','<small class="text-danger pl-3">','</small>');?>
				</div>
				
				<div class="row-full" style="margin-top: 20px; text-align:right;">
				 <input type="submit" value="Simpan">
				 </div>
			</div>
		</div>
	</article>
  </section>
   <!------------------------------------------------------------------------------- Kolom Kanan END --------------------------------------------------------------------------->
  