
  <!------------------------------------------------------------------------------- Kolom Kanan START --------------------------------------------------------------------------->
  <section class="grid">
    <article class="article-rdm">
		<div class="title-article">Redeem</div>
		
		
		<div class="row-full" style="margin-top: -60px;"><!--row full start-->
			<!-- Tab Start -->
			
			<ul class="tabs" role="tablist">
    			<li>
        			<input type="radio" name="tabs" id="tab1" checked />
        			<label for="tab1" 
               			
						role="tab" 
               			aria-selected="true" 
               			aria-controls="panel1" 
               			tabindex="0">Pengajuan
					</label>
        			<div id="tab-content1" 
             			class="tab-content" 
             			role="tabpanel" 
             			aria-labelledby="description" 
             			aria-hidden="false">
          				
						<div class="box-article pwd" style="background: none;">
							<div class="auth-field">
								<div class="row-full">
									<labels>Masukkan jumlah redeem :</labels>
									<input type="text" id="redeem" class="input-rdm ft" name="redeem" placeholder="Masukkan jumlah redeem..">
								</div>
								<div class="row-full" style="margin-top: 20px;">
									<labels>Email code :</labels>
									<input type="text" id="emailcode" class="input-rdm ft" name="emailcode" placeholder="Masukkan email code..">
									<input type="submit" class="krm-inset ft" value="Kirim">
								</div>
								
				
								<div class="row-full" style="margin-top: 20px; text-align:right;">
				 					<input type="submit" value="Submit" style="width: 150px;">
				 				</div>
								
								<div class="row-full">
									<p class="note"><strong style="font-weight:bold;">* Note: </strong>Dana akan dicairkan melalui nomor rekening yang sudah Anda setting</p>
								</div>
							</div>
						</div>
						
        			</div><!-- tab content1 end -->
   			 	</li>
  
    			<li>
        			<input type="radio" name="tabs" id="tab2" />
        			<label for="tab2"
               			role="tab" 
               			aria-selected="false" 
               			aria-controls="panel2" 
               			tabindex="0">Riwayat
					</label>
        			<div id="tab-content2" 
             			class="tab-content"
             			role="tabpanel" 
             			aria-labelledby="specification" 
             			aria-hidden="true">
          				
						
						<div class="row-full"><!-- row full start -->
			<!-- Tabel Start -->
			<div class="table-users rdm">
   				<table cellspacing="0">
								
      				<tr>
	  	 				<th style="font-weight:bold;">No.</th>
         				<th style="font-weight:bold;">Tanggal Pengajuan</th>
         				<th style="font-weight:bold;">Nominal</th>
         				<th style="font-weight:bold;">Status</th>
         				<th style="font-weight:bold; width:150px;">Action</th>
      				</tr>

      				<tr>
	  					<td>1</td>
         				<td style="width:260px;">14 Feb 2021</td>
         				<td>Rp. 280.000,-</td>
         				<td><i class="fa fa-check" aria-hidden="true" style="color:#03B1BA;"></i> &nbsp;OK</td>
         				<td><input type="edit" class="btn-small" value="Edit"> <input type="edit" class="btn-small" value="Hapus"></td>
      				</tr>

      				<tr>
	  					<td>2</td>
         				<td>5 Mar 2021</td>
         				<td>Rp. 350.000,-</td>
         				<td><i class="fa fa-check" aria-hidden="true" style="color:#03B1BA;"></i> &nbsp;OK</td>
         				<td><input type="edit" class="btn-small" value="Edit"> <input type="edit" class="btn-small" value="Hapus"></td>
      				</tr>
					
					<tr>
	  					<td>3</td>
         				<td>19 Mar 2021</td>
         				<td>Rp. 440.000,-</td>
         				<td><i class="fa fa-check" aria-hidden="true" style="color:#03B1BA;"></i> &nbsp;OK</td>
         				<td><input type="edit" class="btn-small" value="Edit"> <input type="edit" class="btn-small" value="Hapus"></td>
      				</tr>

      				<tr>
	  					<td>4</td>
         				<td>11 Apr 2021</td>
         				<td>Rp. 120.000,-</td>
         				<td style="width: 100px;"><span class="pending blink_me"><i class="fa fa-exclamation-circle" aria-hidden="true"></i>&nbsp;Pending</span></td>
         				<td><input type="edit" class="btn-small" value="Edit"> <input type="edit" class="btn-small" value="Hapus"></td>
      				</tr>
					
					<tr>
	  					<td>5</td>
         				<td style="width:260px;">12 Jun 2021</td>
         				<td>Rp. 160.000,-</td>
         				<td><i class="fa fa-check" aria-hidden="true" style="color:#03B1BA;"></i> &nbsp;OK</td>
         				<td><input type="edit" class="btn-small" value="Edit"> <input type="edit" class="btn-small" value="Hapus"></td>
      				</tr>
					
   				</table>
			</div>
			<!-- Tabel END -->
		</div><!--row full end-->
		
		
		<div class="row-full"><!--row full start-->
			<div class="kol-left btm" style="height:50px;">
				Showing <strong><span style="color:#03B1BA;">&nbsp;1&nbsp;</span> to <span style="color:#03B1BA;">&nbsp;5&nbsp;</span></strong> of 5 entries
			</div>
			<div class="kol-right btm" style="height:50px;">
				<a href="#"><span><i class="fa fa-angle-double-left" aria-hidden="true"></i> prev</span></a>&nbsp;<span class="info-hal">1</span>&nbsp;<a href="#"><span>next <i class="fa fa-angle-double-right" aria-hidden="true"></i></span></a>
			</div>
		</div><!--row full end-->
						
						
        			</div><!-- tab content2 end -->
    			</li>
			</ul>
			