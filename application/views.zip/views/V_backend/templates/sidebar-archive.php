        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
            <div class="sidebar-brand-icon rotate-n-15"></div>
            <img src="https://i2.wp.com/www.hops.id/wp-content/uploads/2020/02/hops-logo.png" class="img-thumbnail">
        </a>

        <!-- Divider -->
        <hr class="sidebar-divider ">

        <!-- LOOPING MENU -->
        <div class="sidebar-heading">
            USER
        </div>

        <!--SIAPKAN SUBMENU-->
        <li class="nav-item active">
        <li class="nav-item">
            <a class="nav-link pb-0" href="<?=base_url('C_user'); ?>">
                <i class="fas fa-wa fa-user"></i>
                <span>My Profile</span>
            </a>
            <a class="nav-link pb-0" href="<?=base_url('C_user/editProfile/'); ?>">
                <i class="fas fa-wa fa-user-edit"></i>
                <span>Edit Profile</span>
            </a>
            <a class="nav-link pb-0" href="<?=base_url('C_user/changePassword'); ?>">
                <i class="fas fa-wa fa-key"></i>
                <span>Change Password</span>
            </a>
        </li>

        <hr class="sidebar-divider mt-3">

        <!-- LOOPING MENU -->
        <div class="sidebar-heading">
            MENU
        </div>

        <!--SIAPKAN SUBMENU-->
        <li class="nav-item active">
        <li class="nav-item">
            <a class="nav-link pb-0" href="<?=base_url('C_menu/dashboard'); ?>">
                <i class="fas fa-wa fa-chart-bar"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <!-- <li class="nav-item">
            <a class="nav-link pb-0" href="<?=base_url('C_menu'); ?>">
                <i class="fas fa-wa fa-user"></i>
                <span>Data User</span>
            </a>
        </li> -->
        <li class="nav-item">
            <a class="nav-link pb-0" href="<?=base_url('C_menu/postPage'); ?>">
                <i class="fas fa-wa fa-sticky-note"></i>
                <span>My Blog</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link pb-0" href="<?=base_url('C_menu/thumbnailPage'); ?>">
                <i class="fas fa-wa fa-upload"></i>
                <span>Upload Thumbnail</span>
            </a>
        </li>

        <hr class="sidebar-divider mt-3">
        
        <!-- Nav Item - Charts -->
        <li class="nav-item">
            <a class="nav-link" href="<?= base_url('C_auth/logout'); ?>">
            <i class="fas fa-fw fa-sign-out-alt"></i>
            <span>Logout</span></a>
        </li>

        <!-- Divider -->
        <hr class="sidebar-divider d-none d-md-block">

        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>

        </ul>
        <!-- End of Sidebar -->