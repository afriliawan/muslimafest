<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="apple-mobile-web-app-capable" content="yes">
	
	<title><?= $title; ?></title>
  	<link rel="stylesheet" href="<?= base_url('assets/backend/'); ?>css/admin-style.css">
	  
	<link href="<?= base_url('assets/'); ?>css/jquery-ui.css" rel="stylesheet">
  
  	<link rel="stylesheet" href="<?= base_url('assets/backend/'); ?>font-awesome-4.7.0/css/font-awesome.css">
	<link rel="stylesheet" href="<?= base_url('assets/backend/'); ?>font-awesome-4.7.0/css/font-awesome.min.css">

	<!-- <link href="<?= base_url('assets/'); ?>css/sb-admin-2.min.css" rel="stylesheet"> -->
		
  <!-- summernote -->
  <link rel="stylesheet" href="<?=base_url('assets/adminLTE/'); ?>plugins/summernote/summernote-bs4.css">
		
		<link rel="stylesheet" type="text/css" href="<?= base_url('assets/backend/'); ?>css/CustomFileInputs/normalize.css" />
		<link rel="stylesheet" type="text/css" href="<?= base_url('assets/backend/'); ?>css/CustomFileInputs/custom.css" />
		<link rel="stylesheet" type="text/css" href="<?= base_url('assets/backend/'); ?>css/CustomFileInputs/component.css" />
		<!--[if IE]>
  		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

		<!-- remove this if you use Modernizr -->
		<script>(function(e,t,n){var r=e.querySelectorAll("html")[0];r.className=r.className.replace(/(^|\s)no-js(\s|$)/,"$1js$2")})(document,window,0);</script>
	</head>

<body>
<!-- partial:index.partial.html -->

<header class="page-header">
  <nav>