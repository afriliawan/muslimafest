
<section class="page-content">
  <section class="search-and-user">
    <form>
      <input type="search" placeholder="Search Pages...">
      <button type="submit" aria-label="submit form">
        <i class="fa fa-search" aria-hidden="true" style="font-size:18px;"></i>
      </button>
    </form>
    <div class="admin-profile">
      <span class="greeting">Halo <?= $user['name']; ?></span>
      <div class="notifications">
        <span class="badge">1</span>
        <a href="#popup-estimate"><div class="user-pic top" style="background-image:url(<?= base_url('assets/img/profile/default.jpg'); ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
		</div></a>
      </div>
    </div>
	
	<!--popup-estimate start-->
	<div id="popup-estimate" class="overlay2">
		
			<div class="row-full" style="text-align:right; margin-top: -10px;">
				<a class="close" href="#">&times;</a>
			</div>
      <?php
        $data = $user['url'];
        $result1 = preg_replace("/[^a-zA-Z]/", "", $data);
        $noreknya = preg_replace("/http/"," ", $result1);
      ?>
			<!-- Estimasi Pendapatan:<br><strong><?= $noreknya; ?></strong> -->
			Estimasi Pendapatan:<br><strong>Rp.154.292</strong>
		
	</div>
	<!--popup-estimate start-->
  </section>