
  <footer class="page-footer">
    <span>HopsID ©Copyright 2021 | All Right Reserved</span>
  </footer>
</section>
<!-- partial -->
 <!-- Bootstrap core JavaScript-->
 <script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
  <script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script  src="<?=base_url('assets/backend/'); ?>js/script.js"></script>
  
<!-- jQuery untuk show gambar yang ada di create blog-->
<script src="<?=base_url('assets/backend/'); ?>js/jquery.min.js"></script>
<!-- Summernote -->
<script src="<?=base_url('assets/adminLTE/'); ?>plugins/summernote/summernote-bs4.min.js"></script>
<!-- Tampilkan semua thumbnail di halaman create blog -->
<script src="<?=base_url('assets/backend/'); ?>js/image-picker.js"></script>
<script src="<?=base_url('assets/backend/'); ?>js/image-picker.min.js"></script>
<!-- Bootstrap 4 -->
<!-- <script src="<?=base_url('assets/adminLTE/'); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script> -->
<script>
    $('.image-picker').imagepicker();
</script>


<!--Token Field-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tokenfield/0.12.0/bootstrap-tokenfield.js"></script>  


<script>
  $(document).ready(function(){
      
    $('#search_data').tokenfield({
        autocomplete :{
            source: function(request, response)
            {
                jQuery.get('https://beta.hops.id/wp-json/wp/v2/tags', {
                    search : request.term,
                    per_page : 5,

                }, function(data){
                    // jsonData = JSON.parse(data);
                  console.log(data);
                    i=0;
                    tag = [];
                    while(i<data.length-1){
                        tag[i]=data[i].name
                      i++;
                    }
                    console.log(tag);
                    response(tag);
                });
            },
            delay: 100
        }
    });

    $('#search').click(function(){
        $('#country_name').text($('#search_data').val());
    });

  });
</script>
</body>
</html>


<script  src="assets/js/script.js"></script>
  
  
  <script>
var x, i, j, l, ll, selElmnt, a, b, c;
/*look for any elements with the class "custom-select":*/
x = document.getElementsByClassName("custom-select");
l = x.length;
for (i = 0; i < l; i++) {
  selElmnt = x[i].getElementsByTagName("select")[0];
  ll = selElmnt.length;
  /*for each element, create a new DIV that will act as the selected item:*/
  a = document.createElement("DIV");
  a.setAttribute("class", "select-selected");
  a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
  x[i].appendChild(a);
  /*for each element, create a new DIV that will contain the option list:*/
  b = document.createElement("DIV");
  b.setAttribute("class", "select-items select-hide");
  for (j = 1; j < ll; j++) {
    /*for each option in the original select element,
    create a new DIV that will act as an option item:*/
    c = document.createElement("DIV");
    c.innerHTML = selElmnt.options[j].innerHTML;
    c.addEventListener("click", function(e) {
        /*when an item is clicked, update the original select box,
        and the selected item:*/
        var y, i, k, s, h, sl, yl;
        s = this.parentNode.parentNode.getElementsByTagName("select")[0];
        sl = s.length;
        h = this.parentNode.previousSibling;
        for (i = 0; i < sl; i++) {
          if (s.options[i].innerHTML == this.innerHTML) {
            s.selectedIndex = i;
            h.innerHTML = this.innerHTML;
            y = this.parentNode.getElementsByClassName("same-as-selected");
            yl = y.length;
            for (k = 0; k < yl; k++) {
              y[k].removeAttribute("class");
            }
            this.setAttribute("class", "same-as-selected");
            break;
          }
        }
        h.click();
    });
    b.appendChild(c);
  }
  x[i].appendChild(b);
  a.addEventListener("click", function(e) {
      /*when the select box is clicked, close any other select boxes,
      and open/close the current select box:*/
      e.stopPropagation();
      closeAllSelect(this);
      this.nextSibling.classList.toggle("select-hide");
      this.classList.toggle("select-arrow-active");
    });
}
function closeAllSelect(elmnt) {
  /*a function that will close all select boxes in the document,
  except the current select box:*/
  var x, y, i, xl, yl, arrNo = [];
  x = document.getElementsByClassName("select-items");
  y = document.getElementsByClassName("select-selected");
  xl = x.length;
  yl = y.length;
  for (i = 0; i < yl; i++) {
    if (elmnt == y[i]) {
      arrNo.push(i)
    } else {
      y[i].classList.remove("select-arrow-active");
    }
  }
  for (i = 0; i < xl; i++) {
    if (arrNo.indexOf(i)) {
      x[i].classList.add("select-hide");
    }
  }
}
/*if the user clicks anywhere outside the select box,
then close all select boxes:*/
document.addEventListener("click", closeAllSelect);
</script>



<script  src="<?= base_url('assets/backend/'); ?>assets/js/script.js"></script>

<script src="<?= base_url('assets/backend/'); ?>assets/js/custom-file-input.js"></script>



<script>
function readURL(input) {

if (input.files && input.files[0]) {
var reader = new FileReader();

reader.onload = function(e) {
  $('#blah').attr('src', e.target.result);
}

reader.readAsDataURL(input.files[0]);
}
}

$("#file-7").change(function() {
readURL(this);
});
</script>

</body>
</html>

