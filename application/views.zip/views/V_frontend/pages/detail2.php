<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">


<link href="<?= base_url('assets/frontend/'); ?>css/style.css" rel="stylesheet" type="text/css" media="all">
<link href="<?= base_url('assets/frontend/'); ?>css/mobile.css" rel="stylesheet" type="text/css" media="all">

<link rel="stylesheet" href="<?= base_url('assets/frontend/'); ?>font-awesome-4.7.0/css/font-awesome.css">
<link rel="stylesheet" href="<?= base_url('assets/frontend/'); ?>font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<title><?= $hasil->title->rendered; ?></title>
</head>
<body style="color:#aaaaaa;">

<div class="page-wrapper"><!-- page-wrapper START -->
	
	<header>
		<div class="header-left">
			<a href="<?= base_url('assets/frontend/'); ?>#"><img src="<?= base_url('assets/frontend/'); ?>img/hops-logo.png" width=112></a>
		</div>
		<div class="header-hops-mobile"><a href="<?= base_url('assets/frontend/'); ?>#"><img src="<?= base_url('assets/frontend/'); ?>img/hops-logo.png" width=106></a></div>
	
		<div class="header-right">
			<div class="header-hops-media">
			<ul>
  				<li>
    				<img src="<?= base_url('assets/frontend/'); ?>img/hopsmedia-logo.png" width=40>
    				<ul>
      					<li>Hops</li>
      					<li>Depok Today</li>
      					<li>Kulinear</li>
	  					<li>Muslima</li>
	  					<li>Korea Banget</li>
	  					<li>Bisnika</li>
	  					<li>Ceklis Satu</li>
    				</ul>
  				</li>
			</ul>
			</div>
			
			<div class="socmed">
				<ul class="socmed-group">
					<a href="<?= base_url('assets/frontend/'); ?>#"><li class="socmed-item">
						<i class="fa fa-facebook" style="font-size:14px; color:#eee;"></i>
					</li></a>
					<a href="<?= base_url('assets/frontend/'); ?>#"><li class="socmed-item">
						<i class="fa fa-twitter" style="font-size:14px; color:#eee;"></i>
					</li></a>
					<a href="<?= base_url('assets/frontend/'); ?>#"><li class="socmed-item">
						<i class="fa fa-instagram" style="font-size:14px; color:#eee;"></i>
					</li></a>
					<a href="<?= base_url('assets/frontend/'); ?>#"><li class="socmed-item">
						<i class="fa fa-youtube" style="font-size:14px; color:#eee;"></i>
					</li></a>
					<a href="<?= base_url('assets/frontend/'); ?>#"><li class="socmed-item">
						<i class="fa fa-linkedin" style="font-size:14px; color:#eee;"></i>
					</li></a>
				</ul>
			</div>
		</div>
	</header>
	
	<a href="<?= base_url('assets/frontend/'); ?>#">
	<div class="btn-tulis detail">
		<img src="<?= base_url('assets/frontend/'); ?>img/btn-tulis.png" width=142>
	</div>
	</a>

	<header class="headerz">
		
		
		<div class="nav-center">
			<input class="menu-btn" type="checkbox" id="menu-btn" />
  			<label class="menu-icon" for="menu-btn"><span class="navicon"></span></label>
			
			
			<div class="menu left">
			<!--Search START --->
				<div class="search-box">
    				<button class="btn-search"><i class="fa fa-search"></i></button>
    				<input type="text" class="input-search" placeholder="Type to Search...">
  				</div>
			<!-- Search END --->
			</div>
			
  			<ul class="menu">
    			<li><a href="<?= base_url('assets/frontend/'); ?>#">HOME</a></li>
    			<li><a href="<?= base_url('assets/frontend/'); ?>#"><img src="<?= base_url('assets/frontend/'); ?>img/mug.gif" width=25 class="icon-mug"><img src="<?= base_url('assets/frontend/'); ?>img/mug-grey.gif" width=22 class="icon-mug-grey">&nbsp;TRENDING</a></li>
    			<li><a href="<?= base_url('assets/frontend/'); ?>#">UNIK</a></li>
    			<li><a href="<?= base_url('assets/frontend/'); ?>#">HOT</a></li>
				<li><a href="<?= base_url('assets/frontend/'); ?>#">HOBI</a></li>
  			</ul>
			
			
			
			<div class="menu right">
				<a href="<?= base_url('assets/frontend/'); ?>#">
				<div class="btn-daftar">
					<div class="btn-daftar-label">
						<img src="<?= base_url('assets/frontend/'); ?>img/icon-daftar.png" width=25>&nbsp;&nbsp;Daftar
					</div>
				</div>
				</a>
			</div>
			
			
			
			
		</div>
		
		
	
	</header>
	
	<!-- content-wrapper START -->
	<div class="content-wrapper" style="overflow:auto; clear:both;">
		<!---------------------------------------------------------- ------------------------------- col-left START ------------------------------------------------------------------------------------->
		<div class="col-left">
			<div class="title-detail"><?= $hasil->cat_detail[0]->name; ?></div>
			<h1 class="headline-title-teks detail"><?= $hasil->title->rendered; ?></h1>
            
				<div class="author">
					<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-03.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
						</div>
					</div>
					<div class="author-right">
						<div class="author-name detail"><?= $hasil->author_detail->name; ?></div>
                        <?php
							$UTC = strtotime($hasil->date_gmt);
						?>
						<div class="date detail">| <?= date("Y-m-d | H:i", $UTC + 7*60*60); ?></div>
					</div>
				</div>
				
				<div style="margin-top:40px;"></div>
				
				<a href="https://news.google.com/publications/CAAqBwgKMLv0lAswsMeqAw?hl=id&gl=ID&ceid=ID%3Aid" target="_blank"><div class="btn-gnews"><img src="<?= base_url('assets/frontend/'); ?>img/icon-gnews.png" width=35 style="margin-top: -7px;">&nbsp;&nbsp;ikuti kami di Google News</div></a>
				
				<div style="margin-top:20px;"></div>
			
				<section class="valign bottom headline detail" style="background-image:url(<?= $hasil->jetpack_featured_media_url; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
					<div class="headline-title-box detail">
						<div class="photo-credit">Foto: Instagram</div>
					</div>
				</section>
			
			
			
			<div style="margin-top:20px;"></div>
				
				
				<!-- Start Content Artikel -->
				<div class="content-artikel">
				<!--Replace Width dan Height, perlu disetting height="100%"; -->
				<?= preg_replace('#(<img.+?)width=(["\']?)\d*\2(.*?/?>)#i', '$1$3',preg_replace('#(<img.+?)height=(["\']?)\d*\2(.*?/?>)#i', '$1$3', $hasil->content->rendered)); ?>
				<div style="margin-top:30px;"></div>
				
				<!-- Baca Juga START -->
				<div class="title-section">Baca Juga</div>
				
				
				<div class="row-list bacajuga">
					<!---- List ---->
					<div class="row-list rightcol bacajuga">
						<div class="kol-separuh-rightcol left">
							<div class="img-holder" style="background-image:url(<?= $hasilCategories[0]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
						</div>
				
						<div class="kol-separuh-rightcol right">
							<!--<div class="author">
								<div class="author-name small"><span>Unik</span>&nbsp; | &nbsp;Debby Harry</div>
								<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
							</div>-->
							<p class="headline-title-teks small"><?= $hasilCategories[0]['title']['rendered'];?></p>
						</div>
					</div>
					<!---- List ---->
			
					<!---- List ---->
					<div class="row-list rightcol bacajuga">
						<div class="kol-separuh-rightcol left">
							<div class="img-holder" style="background-image:url(<?= $hasilCategories[1]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
						</div>
				
						<div class="kol-separuh-rightcol right">
							<!--<div class="author">
								<div class="author-name small"><span>Unik</span>&nbsp; | &nbsp;Debby Harry</div>
								<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
							</div>-->
							<p class="headline-title-teks small"><?= $hasilCategories[1]['title']['rendered'];?></p>
						</div>
					</div>
					<!---- List ---->
					
					<!---- List ---->
					<div class="row-list rightcol bacajuga">
						<div class="kol-separuh-rightcol left">
							<div class="img-holder" style="background-image:url(<?= $hasilCategories[2]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
						</div>
				
						<div class="kol-separuh-rightcol right">
							<!--<div class="author">
								<div class="author-name small"><span>Unik</span>&nbsp; | &nbsp;Debby Harry</div>
								<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
							</div>-->
							<p class="headline-title-teks small"><?= $hasilCategories[2]['title']['rendered'];?></p>
						</div>
					</div>
					<!---- List ---->
			
					<!---- List ---->
					<div class="row-list rightcol bacajuga">
						<div class="kol-separuh-rightcol left">
							<div class="img-holder" style="background-image:url(<?= $hasilCategories[3]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
						</div>
				
						<div class="kol-separuh-rightcol right">
							<!--<div class="author">
								<div class="author-name small"><span>Unik</span>&nbsp; | &nbsp;Debby Harry</div>
								<div class="date small">22 Juni 2021 &nbsp;| &nbsp; 12:48</div>
							</div>-->
							<p class="headline-title-teks small"><?= $hasilCategories[3]['title']['rendered'];?></p>
						</div>
					</div>
					<!---- List ---->
					
					
				</div>
				<!-- Baca Juga END -->
				
				<div style="margin-top:90px;"></div>
				</div>
				<!-- End Content Artikel -->
				
				<div style="margin-top:30px;"></div>

				<div class="list-topik">
					<div class="label-topik"><img src="<?= base_url('assets/frontend/'); ?>img/label-topik.png" width=70></div>
					<?php
								$tags = $hasil->tag_detail;
								$a = "";
								$i = 0;
								
								foreach ($tags as $allTags) {
									if($i==0){
										$a = '<li class="topik">' . $allTags->name . '</li>';
									} else {
										$a = $a . '&nbsp;' . '<li class="topik">' . $allTags->name . '</li>';
									}
									$i++;
								}
					?>
					<ul>
						<?= $a; ?>
					</ul>
				</div>
				
				<div style="margin-top:30px;"></div>
				
				<div class="share-box">
					<div class="label-share"><img src="<?= base_url('assets/frontend/'); ?>img/icon-share.png" width=24>&nbsp;&nbsp;share</div>
					<div class="share-holder">
						<ul>
							<li class="socmed-item-square facebook">
								<i class="fa fa-facebook" style="font-size:16px; color:#eee;"></i>
							</li>
							<li class="socmed-item-square twitter">
								<i class="fa fa-twitter" style="font-size:16px; color:#eee;"></i>
							</li>
							<li class="socmed-item-square linkedin">
								<i class="fa fa-linkedin" style="font-size:16px; color:#eee;"></i>
							</li>
							<li class="socmed-item-square get-pocket">
								<i class="fa fa-get-pocket" style="font-size:16px; color:#eee;"></i>
							</li>
							<li class="socmed-item-square">
								<i class="fa fa-envelope" style="font-size:16px; color:#eee;"></i>
							</li>
							<li class="socmed-item-square">
								<i class="fa fa-print" style="font-size:16px; color:#eee;"></i>
							</li>
						</ul>
					</div>
				</div>
				
				<div style="margin-top:30px;"></div>
			
			
			
			<!--BANNER AD-->
			<div class="banner-ad">
				<img src="<?= base_url('assets/frontend/'); ?>img/ad-middle-banner-640x90.jpg" width=100%>
			</div>
			
			<div style="margin-bottom:30px;"></div>
			
	
			<div class="title-section">Artikel Terkait</div>
				
				<div style="margin-bottom:20px;"></div>
				<!--START Listing Artikel Terkait-->
				
				<div class="row-list">
                    <?php
                        foreach($hasilTags as $hTa){ ?>
					<div class="kol-sepertiga artikel-terkait left">
						<div class="img-holder artikel-terkait" style="background-image:url(<?= $hTa['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
						<p class="headline-title-teks small artikel-terkait"><?= $hTa['title']['rendered']; ?></p>
                        
					</div>
                    <?php } ?>
				</div>

			

			<div style="margin-top:50px;"></div>
				
				<!-- Form Komentar -->
				
				<div class="title-section" style="clear: both;">Apa Komentarmu?</div>
				<br>
				<form>
				<label for="nme">Nama <span style="color:red;">*</span> :</label>
				<input type="text" id="fname" name="username" placeholder="Masukkan nama..">
				<br><br>
				<label for="email">Email <span style="color:red;">*</span> :</label>
  				<input type="text" id="femail" name="email" placeholder="Masukkan alamat email..">
				<br><br>
  				<label for="msg">Isi Komentarmu :</label>
  				<textarea id="subject" name="subject" placeholder="Tuliskan komentarmu.." style="height:200px"></textarea>
  				
				<div class="row-full" style="text-align:right;"><span style="color:red;">*</span> wajib diisi</div>
  				<input type="submit" value="Kirim Komentar" />
				</form>
				
				
				
				<div style="margin-bottom:40px;"></div>
			
			
			
				
			
			
			
  		</div>
		<!---------------------------------------------------------- ------------------------------- col-left END -------------------------------------------------------------------------------------->

  		
		<!---------------------------------------------------------- ------------------------------- col-right START ----------------------------------------------------------------------------------->
		<div class="col-right">
    		<div class="title-section">Top Writer</div>
			<div style="margin-top:20px;"></div>
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-02.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name">Gita Yarsi</div>
						<div class="jml-artikel">21 Artikel</div>
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name">Vanda Maria Bonfanti</div>
						<div class="jml-artikel">19 Artikel</div>
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-03.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name">Margot Reth</div>
						<div class="jml-artikel">21 Artikel</div>
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-04.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name">Debby Harry</div>
						<div class="jml-artikel">19 Artikel</div>
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name">Sondang Silaen</div>
						<div class="jml-artikel">21 Artikel</div>
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<div style="margin-top:30px;"></div>
			
			<!--BANNER AD-->
				<div class="title-section">Advertisement</div>
				
				<div style="margin-top:20px;"></div>
				<div class="banner-ad">
					<img src="<?= base_url('assets/frontend/'); ?>img/ad-rectangle-banner-300x250.jpg" width=300>
				</div>
				<div style="margin-top:30px;"></div>
			
			
			
			<div class="title-section" style="clear:both;">Terbaru</div>
			<div style="margin-top:20px;"></div>
			
			
			<!---- List ---->
            <?php
                    foreach($hasilTerbaru as $hTe){ ?>
			<div class="row-list rightcol">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder" style="background-image:url(<?= $hTe->jetpack_featured_media_url; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
                        <?php
							$UTC = strtotime($hTe->date_gmt);
                        foreach($hTe->cat_detail as $cd){ ?>
						    <div class="author-name small"><span><?= $cd->name; ?></span>&nbsp; | &nbsp;<?= $hTe->author_detail->name; ?></div>
                        <?php } ?>
						<div class="date small"><?= date("Y-m-d | H:i", $UTC + 7*60*60); ?></div>
					</div>
					<p class="headline-title-teks small"><?= $hTe->title->rendered; ?></p>
				</div>
			</div>
			<!---- List ---->
			
            <?php } ?>
			
			
			<!--BANNER AD-->
				<div class="title-section">Advertisement</div>
				
				<div style="margin-top:20px;"></div>
				<div class="banner-ad">
					<img src="<?= base_url('assets/frontend/'); ?>img/ad-rectangle-banner-300x250.jpg" width=300>
				</div>
				<div style="margin-top:30px;"></div>
			
			
			
			
  		</div>
		<!---------------------------------------------------------- ------------------------------- col-right END ------------------------------------------------------------------------------------->
	</div>
	<!-- content-wrapper END -->

	<!--row-full 3 START-->
		<div class="row-full">
			<div class="footer-container">
				<div class="frow">
		 			<ul class="footer-teks">
						<a href="<?= base_url('assets/frontend/'); ?>#"><li>Tentang Kami</li></a>
						<a href="<?= base_url('assets/frontend/'); ?>#"><li>Disclaimer</li></a>
						<a href="<?= base_url('assets/frontend/'); ?>#"><li>Pedoman Media Siber</li></a>
						<a href="<?= base_url('assets/frontend/'); ?>#"><li>Kontak</li></a>
						<a href="<?= base_url('assets/frontend/'); ?>#"><li>Karier</li></a>
						<a href="<?= base_url('assets/frontend/'); ?>#"><li>Indeks</li></a>
					</ul>
				</div>
		
				<div class="frow">
					<div class="fcolumn-left">
   						<div class="c-center">
  							<a href="<?= base_url('assets/frontend/'); ?>#" title="hops media" alt="hops media"><img src="<?= base_url('assets/frontend/'); ?>img/hopsmedia-logo-reverse.png" width=95></a>
						</div>
  					</div>
  			
					<div class="fcolumn-middle">
    					<div class="c-center" style="display:block;">
  							<a href="<?= base_url('assets/frontend/'); ?>#" title="hops.id" alt="hops.id"><div class="multibrand-holder">
								<img src="<?= base_url('assets/frontend/'); ?>img/hops-logo.png" width=75>
							</div></a>
							<a href="<?= base_url('assets/frontend/'); ?>#" title="depok today" alt="depok today"><div class="multibrand-holder">
								<img src="<?= base_url('assets/frontend/'); ?>img/logo-depoktoday-reverse.png" width=125>
							</div></a>
							<a href="<?= base_url('assets/frontend/'); ?>#" title="kulinear" alt="kulinear"><div class="multibrand-holder">
								<img src="<?= base_url('assets/frontend/'); ?>img/logo-kulinear.png" width=135>
							</div></a>
							<a href="<?= base_url('assets/frontend/'); ?>#" title="muslima" alt="muslima"><div class="multibrand-holder">
								<img src="<?= base_url('assets/frontend/'); ?>img/logo-muslima.png" width=125>
							</div></a>
							<a href="<?= base_url('assets/frontend/'); ?>#" title="korea banget" alt="korea banget"><div class="multibrand-holder">
								<img src="<?= base_url('assets/frontend/'); ?>img/logo-koreabanget.png" width=135>
							</div></a>
							<a href="<?= base_url('assets/frontend/'); ?>#" title="bisnika" alt="bisnika"><div class="multibrand-holder">
								<img src="<?= base_url('assets/frontend/'); ?>img/logo-bisnika.png" width=115>
							</div></a>
							<a href="<?= base_url('assets/frontend/'); ?>#" title="ceklis satu" alt="ceklis satu"><div class="multibrand-holder">
								<img src="<?= base_url('assets/frontend/'); ?>img/logo-ceklis-satu.png" width=155>
							</div></a>
						</div>
  					</div>
  			
					<div class="fcolumn-right">
    					<div class="c-center">
  							<p>subsidiary of <br><a href="<?= base_url('assets/frontend/'); ?>#" title="surge" alt="surge"><img src="<?= base_url('assets/frontend/'); ?>img/logo-surge.png" width=85></a></p>
						</div>
  					</div>
				</div><!-- frow end -->
		
				<div class="frow detail">
		 			<div class="copyright">HopsID ©Copyright 2021 | All Right Reserved</div>
				</div>
			</div><!--footer-container END-->
		</div>
		<!--row-full 3 END-->
	
	
	
</div><!-- page-wrapper END -->





	<!-- socmed -sticky btm -->
	<div class="socmed-sticky-btm" id="socmed-sticky-bottom" style="display:none;">
		<a href="<?= base_url('assets/frontend/'); ?>#"><div class="socmed-item-sticky-btm facebook">
			<i class="fa fa-facebook" style="font-size:24px; color:#eee;"></i>
		</div></a>
		
		<a href="<?= base_url('assets/frontend/'); ?>#"><div class="socmed-item-sticky-btm twitter">
			<i class="fa fa-twitter" style="font-size:24px; color:#eee;"></i>
		</div></a>
		
		<a href="<?= base_url('assets/frontend/'); ?>#"><div class="socmed-item-sticky-btm whatsap">
			<i class="fa fa-whatsapp" style="font-size:24px; color:#eee;"></i>
		</div></a>
	</div>
	<!-- socmed -sticky btm -->
	
	
	
	
	<script>

	var socmedshare = document.getElementById("socmed-sticky-bottom");
	window.onscroll = function() {scrollFunction()};

	function scrollFunction() {
  		if (document.body.scrollTop > 700 || document.documentElement.scrollTop > 700) {
    		socmedshare.style.display = "block",
			socmedshare.animate({'opacity':'1'},6000);
  		} else {
    		socmedshare.style.display = "none",
			socmedshare.animate({'opacity':'0'},6000);
  		}
	}

	</script>



	
</body>
</html>
