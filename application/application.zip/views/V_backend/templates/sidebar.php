
    
	<div class="logo-header">
		<a href="#"><img src="<?=base_url('assets/backend/'); ?>img/hops-logo.png"></a>
	</div>
	
    <button class="toggle-mob-menu" aria-expanded="false" aria-label="open menu">
      <i class="fa fa-chevron-down" aria-hidden="true"></i>
    </button>
    <ul class="admin-menu">
      <li class="menu-heading">
        <h3>USER</h3>
      </li>
      <li>
        <a href="<?=base_url('C_user'); ?>">
          <i class="fa fa-user" aria-hidden="true"></i>
          &nbsp;&nbsp;<span>Profil Saya</span>
        </a>
      </li>
      <li>
        <a href="<?=base_url('C_user/editProfile'); ?>">
          <i class="fa fa-address-card" aria-hidden="true"></i>
          &nbsp;&nbsp;<span>Ubah Profil</span>
        </a>
      </li>
      <li>
        <a href="<?=base_url('C_user/changePassword'); ?>">
          <i class="fa fa-key" aria-hidden="true"></i>
          &nbsp;&nbsp;<span>Ubah Password</span>
        </a>
      </li>
      
	  <div class="line-devide" style="margin-top:20px;"></div>
	  
      <li class="menu-heading">
        <h3>MENU</h3>
      </li>
      <li>
        <a href="<?=base_url('C_menu/dashboard'); ?>">
          <i class="fa fa-desktop" aria-hidden="true"></i>
          &nbsp;&nbsp;<span>Dashboard</span>
        </a>
      </li>
      <li>
        <a href="<?=base_url('C_menu/myBlog'); ?>">
          <i class="fa fa-list" aria-hidden="true"></i>
          &nbsp;&nbsp;<span>Blog Saya</span>
        </a>
      </li>
      <li>
        <a href="<?=base_url('C_menu/thumbnailPage'); ?>">
          <i class="fa fa-upload" aria-hidden="true"></i>
          &nbsp;&nbsp;<span>Upload Gambar</span>
        </a>
      </li>
	  <li>
        <a href="<?=base_url('C_menu/redeem'); ?>">
          <i class="fa fa-money" aria-hidden="true"></i>
          &nbsp;&nbsp;<span>Redeem</span>
        </a>
      </li>
	  <li>
        <a href="<?=base_url('C_menu/termAndConditions'); ?>">
          <i class="fa fa-newspaper-o" aria-hidden="true"></i>
          &nbsp;&nbsp;<span>Syarat & Ketentuan</span>
        </a>
      </li>
	  
	   <div class="line-devide" style="margin-top:20px;"></div>
	   
	   <li>
        <a href="<?=base_url('C_auth/logout'); ?>">
          <i class="fa fa-sign-out" aria-hidden="true"></i>
          &nbsp;&nbsp;<span>Logout</span>
        </a>
      </li>
	  
	   <div class="line-devide"></div>
	   
	   
	   
	  
      <li>
        <div class="switch">
          <input type="checkbox" id="mode" checked>
          <label for="mode">
            <span></span>
            <span>Dark</span>
          </label>
        </div>
         <button class="collapse-btn" aria-expanded="true" aria-label="collapse menu">
          <i class="fa fa-chevron-left" aria-hidden="true"></i>
          &nbsp;&nbsp;<span>Collapse</span>
        </button>
      </li>
    </ul>
  </nav>
</header>

