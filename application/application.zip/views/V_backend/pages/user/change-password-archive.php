        <!-- Begin Page Content -->
        <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>  

        <div class="row">
            <div class="col-lg-6">

            <!--harus ditaruh sebelum form action-->
            <?= $this->session->flashdata('message'); ?>

                <form action="<?= base_url('C_user/changePassword'); ?>" method="post">
                    <div class="form-group">
                        <label for="password">Current Password</label>
                        <input type="text" class="form-control" id="password" name="password">
                        <?= form_error('password','<small class="text-danger pl-3">','</small>');?>
                    </div>
                    <div class="form-group">
                        <label for="new_password">New Password</label>
                        <input type="password" class="form-control" id="new_password" name="new_password">
                        <?= form_error('new_password','<small class="text-danger pl-3">','</small>');?>
                    </div>
                    <div class="form-group">
                        <label for="newPassword2">Repeat Password</label>
                        <input type="password" class="form-control" id="newPassword2" name="newPassword2">
                        <?= form_error('newPassword2','<small class="text-danger pl-3">','</small>');?>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-hops">Change Password</button>
                    </div>
                    
            </div>
        </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->