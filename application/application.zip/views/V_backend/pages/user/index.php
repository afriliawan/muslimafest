
  <!------------------------------------------------------------------------------- Kolom Kanan START --------------------------------------------------------------------------->
  <section class="grid">
    <article>
		<div class="row">
            <div class="col-lg-8">
                <?= $this->session->flashdata('message'); ?>
            </div>
        </div>
		<div class="box-article profil">
			<div class="title-article" style="text-align:center;">Profil Saya</div>
			<div style="margin-top:20px;"></div>
			<div class="user-pic" style="background-image:url(<?= $user['avatar_urls']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
			</div>
			<div style="margin-top:20px;"></div>
			<div class="line-devide" style="opacity:20%;"></div>
			<div style="margin-top:20px;"></div>
			<div class="user-info">
				<ul>
					<li>Username : <?= $user['username']; ?></li>
					<li>Email : <?= $user['email']; ?></li>
					<li>Nama : <?= $user['name']; ?></li>
					<?php
						$data = $user['url'];
						$result1 = preg_replace("/[^a-zA-Z]/", "", $data);
						$noreknya = preg_replace("/http/"," ", $result1);
					?>
					<li>No. Rekening : <?= $noreknya; ?></li>
					<li>No. Rekening : <?= $user['rek_number']; ?></li>
					<li>No. KTP : <?= $user['identity_number']; ?></li>
				</ul>
			</div>
		</div>
	</article>
  </section>
   <!------------------------------------------------------------------------------- Kolom Kanan END --------------------------------------------------------------------------->
