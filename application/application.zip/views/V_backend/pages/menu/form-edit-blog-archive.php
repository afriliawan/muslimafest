  <!------------------------------------------------------------------------------- Kolom Kanan START --------------------------------------------------------------------------->
  <section class="grid">
    <article>
		<div class="title-article">Tulis Berita</div>
		<div class="col-lg-8">
                        <?= $this->session->flashdata('message'); ?>
                    </div>
		<div class="box-article tulis-berita">
            <form enctype="multipart/form-data" action="<?=base_url('C_menu/formEditPost/' . $hasil->id);?>" method="POST">
  			<div class="row">
    			<label>Judul Berita</label>
    			<input id="title" name="title" class="input-tb" type="text" placeholder="Judul berita"   value="<?= $hasil->title->rendered; ?>">
				<input type="hidden" class="form-control" name="author" autocomplete="off" value=<?= $user['id']; ?> readonly>    
                <?= form_error('title','<small class="text-danger pl-3">','</small>');?>
  			</div>
  			<div class="row">
    			<label>Kategori</label>
    			<div class="custom-select" style="width:200px;" name="categories">
  					<select>
					  	<?php                                
							foreach ($categories as $row) {  
							echo "<option value='".$row->id."'>".$row->name."</option>";
							}
							echo"
							</select>"
						?>
  					</select>
				</div>
  			</div>
    		<div class="row">
      			<label>Tags</label>
                  <?php
                    $tags = $hasil->tag_detail;
					var_dump( $tags );
					die;
                    $a = "";
                    $i = 0;
                    
                    foreach ($tags as $allTags) {
                        if($i==0){
                            $a = $allTags->name . "(" . $allTags->id . ")";
                        } else {
                            $a = $a . ',' . $allTags->name . "(" . $allTags->id . ")";
                        }
                        $i++;
                    }
                        ?>
						<div class="tokenfield form-control" style="display: inline-block!important;width:480px;">
				  <input id="search_data" name="tags" style="width:480px;"  class="input-tb" type="text" placeholder="Tags berita"  value="<?= $a; ?>">
				</div>
      			<!-- <input type="text" style="width:480px;" id="search_data" class="input-tb" name="tags" value="<?= set_value('tags'); ?>" /> -->
    		</div>
			
			<div class="row">
			<labels>Foto thumbnail :</labels>
			<div class="box-input">
				<form id="form1" runat="server" >
					<img id="blah" src="<?= base_url('assets/backend/'); ?>img/thumb-image.jpg" class="img-profil-default" width="140" alt="your image" name="" style="margin-left:174px;margin-top:-20px;"/>
					<input type="file" name="thumbnail" id="file-7" accept="image/*" class="inputfile inputfile-6" data-multiple-caption="{count} files selected" multiple/>
					<label for="file-7" style="width:480px;margin-top:-17px;"><span></span> <strong>Choose a file&hellip;</strong></label>
					<input type="hidden" name="imageID" id="imageID">
				</div>
			</div>
			
			<input type="submit" value="Submit" />
		
		<!-- pop up start -->
		<div class="row">
			<div id="popup1" class="overlay">
				<div class="popup">
					
					<a class="close" href="#">&times;</a>
					<div class="content"><!-- content pop up start -->
						<div class="row-full">
							<div class="search-small">
    							<form>
      								<input type="search" placeholder="Search ...">
      								<button type="submit" aria-label="submit form">
        								<i class="fa fa-search" aria-hidden="true" style="font-size:18px;"></i>
      								</button>
    							</form>
							</div>
						</div>
						
						<div style="margin-top:20px;"></div>
						
						<div class="row-full" style="margin-top:20px; margin-bottom:20px; border-top:2px solid #03B1BA; border-bottom:1px solid #03B1BA;">
							<div style="margin-top:20px;"></div>
							<!-- <a href="#"><div class="thumbnail-holder"><img src="<?=base_url('assets/backend/'); ?>img/img-artikel.jpg" width="100" style="vertical-align: top;"></div></a> -->
							<select class="image-picker show-html" id="selectImage" name="id" style="display: none;">
							<option value=""></option>
								<?php foreach ($thumbnail as $tN) : ?>
									<option data-img-src="<?= $tN->guid->rendered; ?>" class="image-picker" value="<?= $tN->id; ?>"><?= $tN->guid->rendered; ?>
								<?php endforeach; ?> 
								</select>
							<div style="margin-top:20px;"></div>
						</div>
						
						<div class="row-full" style="text-align:right;">
				 			<input type="submit" value="Batal" style="width: 110px; margin-right:10px;">
				 			<input type="submit" value="Pilih" style="width: 110px;">
				 		</div>
					</div><!-- content pop up end -->
				</div>
			</div>
		</div>
		<!-- pop up end -->
		
		</div><!-- box article end -->
	</article>
  </section>
   <!------------------------------------------------------------------------------- Kolom Kanan END --------------------------------------------------------------------------->
<script>
	function takeID() {
		//Ketika post menggunakan $this->input->post('imageID') bukan ('thumbnail')
		document.getElementById('imageID').value=document.getElementById('selectImage').value;
		// document.getElementById('takePhoto').src=document.getElementById('selectImage').text;
		document.getElementById('takePhoto').src=document.getElementById('selectImage').options[document.getElementById('selectImage').selectedIndex].text;
	}
</script>