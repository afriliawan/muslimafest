
<html lang="en" class="no-js">
	<head>
		<!-- remove this if you use Modernizr -->
		<script>(function(e,t,n){var r=e.querySelectorAll("html")[0];r.className=r.className.replace(/(^|\s)no-js(\s|$)/,"$1js$2")})(document,window,0);</script>
	</head>
	<body>
	
  
  <!------------------------------------------------------------------------------- Kolom Kanan START --------------------------------------------------------------------------->
  <section class="grid">
    <article>
		<div class="title-article">Upload Gambar</div>
    <div class="col-lg-8">
        <?= $this->session->flashdata('message'); ?>
    </div>
		<div class="box-article pwd">
			<div class="auth-field">
				
				<div class="row-full" style="margin-top: 20px;">
					<!-- <labels>Gambar :</labels> -->
					
          		<?= form_open_multipart('C_menu/addThumbnail'); ?>  
					<div class="container">
						<div class="content">
							<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

							<div class="box-input">
							<form id="form1" runat="server">
								<img id="blah" src="<?= base_url('assets/backend/'); ?>img/thumb-image.jpg" class="img-profil-default" width="140" alt="your image" />
								<input type="file" name="thumbnail" id="file-7" accept="image/*" class="inputfile inputfile-6" data-multiple-caption="{count} files selected" multiple/>
								<label for="file-7" style="width:480px;"><span></span> <strong>Choose a file&hellip;</strong></label>
								
							</div>
						</div>
					</div><!-- /container -->
					
				</div>
				
				<div class="row-full right" style="margin-top: 50px;">
				 <input type="submit" value="Batal" style="width: 120px;" class="btn-left">
				 <input type="submit" value="Simpan" style="width: 120px;;">
				 </div>
         
							</form>
			</div>
		</div>
	</article>
  </section>
   <!------------------------------------------------------------------------------- Kolom Kanan END --------------------------------------------------------------------------->
  
<!-- partial -->
	

		
	</body>
</html>
