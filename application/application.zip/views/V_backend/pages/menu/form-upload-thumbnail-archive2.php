  <!------------------------------------------------------------------------------- Kolom Kanan START --------------------------------------------------------------------------->
  <section class="grid">
    <article>
		<div class="title-article">Upload Gambar</div>
	
		<div class="box-article pwd">
			<div class="auth-field">
			<?= form_open_multipart('C_menu/addThumbnail'); ?>
				<div class="row-full" style="margin-top: 20px;">
					<labels>Foto profil :</labels>
					<img  class="img-profil-default" src="<?= base_url('assets/backend/'); ?>img/thumb-image.jpg" width="140">
					<input type="text" class="input-plh-img" placeholder="Choose file..">
						<div id="file-upload-cont">
    						<input id="original" type="file"/>
    						<div id="button-browse">Browse</div>
						</div>
					</input>
				</div>
				
				<div class="row-full" style="margin-top: 50px; text-align:right;">
				 <!-- <input type="submit" value="Batal" style="width: 120px;" class="btn-left"> -->
				 <input type="submit" value="Simpan" style="width: 120px;;">
				 </div>
			</div>
		</div>
	</article>
  </section>
   <!------------------------------------------------------------------------------- Kolom Kanan END --------------------------------------------------------------------------->
  