<!-- Begin Page Content -->
<div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>  

<div class="row">
            <div class="col-lg-8">
                <?= $this->session->flashdata('message'); ?>
            </div>
    <div class="col-lg-12">
    
    <!--<form action="">-->
    
        <?= form_open_multipart('C_menu/formCreateBlog'); ?>
        <div class="form-group row">
            <label for="name" class="col-sm-1 col-form-label">Title</label>
            <div class="class col-sm-8">
                <input type="text" class="form-control" name="title" autocomplete="off" value="<?= set_value('title'); ?>">  
                <input type="hidden" class="form-control" name="author" autocomplete="off" value=<?= $user['id']; ?> readonly>    
                <?= form_error('title','<small class="text-danger pl-3">','</small>');?>
                <!--Validasi agar name tidak boleh kosong-->  
                <!-- <input type="hidden" class="form-control" name="is_active" value='2'> -->
            </div>
        </div>
        <div class="form-group row">
        <label for="name" class="col-sm-1 col-form-label">Categories</label>
            <div class="class col-sm-8">
                <div class="dropdown">
                    <select button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" name="categories">
                        <div class="controls">
                            <?php                                
                                foreach ($categories as $row) {  
                                echo "<option value='".$row->id."'>".$row->name."</option>";
                                }
                                echo"
                                </select>"
                            ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="form-group row">
            <label for="name" class="col-sm-1 col-form-label">Tags</label>
            <div class="class col-sm-8">
            <div class="input-group">
                    <input type="text" id="search_data" placeholder="" autocomplete="off" name="tags" class="form-control input-lg" value="<?= set_value('tags'); ?>"/>
                    <!-- <div class="input-group-btn">
                        <button type="button" class="btn btn-hops btn-lg" id="search">Get Value</button>
                    </div> -->
                </div>
                <span id="country_name"></span>
                <?= form_error('tags','<small class="text-danger pl-3">','</small>');?>
                <!--Validasi agar name tidak boleh kosong-->  
                <!-- <input type="hidden" class="form-control" name="is_active" value='2'> -->
            </div>
        </div>
        <div class="form-group row">
            <label for="name" class="col-sm-1 col-form-label">Thumbnail</label>
            <div class="class col-sm-8">
                <div class="col-sm-3">
                    <img src="<?= base_url('assets/img/profile/default.jpg'); ?>" id="takePhoto" name="takePhoto" class="img-thumbnail">
                </div> 
                <BR>
                <a href="" class="btn btn-secondary" data-toggle="modal" data-target="#addThumbnail">Select Thumbnail</a>
                <BR>
            <input type="hidden" name="imageID" id="imageID">
                <?= form_error('imageID','<small class="text-danger pl-3">','</small>');?>
                <!--Validasi agar name tidak boleh kosong-->  
                <!-- <input type="hidden" class="form-control" name="is_active" value='2'> -->
            </div>
        </div>
        
        <!--JS Summernote-->
        <div class="form-group row">
            <label for="name" class="col-sm-1 col-form-label">Deskripsi</label>
            <div class="class col-sm-8">
                <section class="content">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- /.card-header -->
                            <div class="card-body pad">
                                <div class="mb-3">
                                    <textarea class="textarea" name="content" placeholder="Place some text here"
                                    style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">
                                    </textarea>
                                </div>
                            </div>
                        </div>
                        <!-- /.col-->
                    </div>
                <!-- ./row -->
                </section>                     
            </div>
        </div>
        <div class="form-group row justify-content-end">
            <div class="col-sm-8">
                <a href="<?= site_url('C_menu/postPage') ?>" class="btn btn-secondary" >Kembali</a>
                <button type="submit" class="btn btn-hops">Simpan</button>
            </div>
        </div>

    </form>
    
    </div>

</div>

</div>
<!-- /.container-fluid -->

</div>
      <!-- End of Main Content -->
<!-- Modal Add -->
<div class="modal fade" id="addThumbnail" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Thumbnail</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <form action="<?=base_url('C_menu/addDataUser'); ?>" method="post">
    <BR>
    
    &nbsp;&nbsp;&nbsp;&nbsp;<input id="myInput" type="text" placeholder="Search..">
    <button type="button" class="btn btn-hops" data-dismiss="modal" onclick="takeID()">Choose</button><hr>
    <!-- <input type="text" class="form-control" name="thumbnail" autocomplete="off" readonly> -->
    <div id="myDIV">
        <div class="modal-body col-lg-12">
            <select class="image-picker show-html" id="selectImage" name="id" style="display: none;">
            <option value=""></option>
                <?php foreach ($thumbnail as $tN) : ?>
                    <option data-img-src="<?= $tN->guid->rendered; ?>" class="img-fluid mb-2" value="<?= $tN->id; ?>"><?= $tN->guid->rendered; ?>
                <?php endforeach; ?> 
            </select>
        </div>
        <div class="modal-footer">
            <!-- <button type="submit" class="btn btn-hops">Add</button> -->
    </div>
    </div>
    </form>
    </div>
</div>
</div>

<script>
function takeID() {
    //Ketika post menggunakan $this->input->post('imageID') bukan ('thumbnail')
    document.getElementById('imageID').value=document.getElementById('selectImage').value;
    // document.getElementById('takePhoto').src=document.getElementById('selectImage').text;
    document.getElementById('takePhoto').src=document.getElementById('selectImage').options[document.getElementById('selectImage').selectedIndex].text;
}
</script>