        <!-- Begin Page Content -->
        <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>  
        
        <div class="row">
                    <div class="col-lg-8">
                        <?= $this->session->flashdata('message'); ?>
                    </div>
            <div class="col-lg-12">
            
            <!--<form action="">-->
            
                <?= form_open_multipart('C_menu/addThumbnail'); ?>
                
                <div class="form-group row">
                    <label for="name" class="col-sm-1">Picture</label>
                    <div class="col-sm-8">
                        <div class="row">
                            <div class="col-sm-3">
                                <img src="<?= base_url('assets/img/posts/default.jpg'); ?>" class="img-thumbnail">
                            </div>
                            <div class="col-sm-9">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" accept="image/*" id="thumbnail" name="thumbnail">
                                    <label class="custom-file-label" for="thumbnail">Choose file</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group row justify-content-end">
                    <div class="col-sm-8">
                        <a href="<?= site_url('C_menu/thumbnailPage') ?>" class="btn btn-secondary" >Kembali</a>
                        <button type="submit" class="btn btn-hops">Simpan</button>
                    </div>
                </div>

            </form>
            
            </div>
        
        </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


