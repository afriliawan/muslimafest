        <!-- Begin Page Content -->
        <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>  

        </div>
        <!-- /.container-fluid -->
        <!-- /.container-fluid -->
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-body">
        &nbsp;&nbsp;
        <a href="<?= site_url('C_menu/formCreatePost') ?>" class="btn btn-hops mb-3">Add New Post</a>
        <BR>
              <div class="table-responsive">
        <BR>
<?= $this->session->flashdata('message'); ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                  <tr>
                      <th><center>No.</center></th>
                      <!-- <th><center>ID</center></th> -->
                      <th><center>Title</center></th>
                      <th><center>Author</center></th>
                      <th><center>Status</center></th>
                      <th width="10%"><center>Action</center></th>
                    </tr>
                   </thead>
                   <tbody>
                   <?php
                    $no = 1;
                    foreach($hasil as $r){ ?>
                      <tr>
                        <td><?= $no++ ?></td>
                        <!-- <td><?= $r->id; ?></td> -->
                        <td><a href="<?= $r->link;?>"><?= $r->title->rendered; ?></a></td>
                        <td><center><?= $r->author_detail->name; ?></center></td>
                        <td><center><?= $r->status; ?></center></td>
                        <td>
                            <center>
                                <a href="<?=base_url('C_menu/formEditPost/') . $r->id; ?>" class="badge badge-info">Edit</a>
                                <a href="<?=base_url('C_menu/deletePost/') . $r->id; ?>" onclick="return confirm('Yakin ingin menghapus data ini?')" class="badge badge-danger">Delete</a>
                            </center>
                        </td>
                      </tr>
                      <?php } ?>
                    </tbody>
                </table>
              </div>
            </div>
          </div>
      <!-- End of Main Content -->

      </div>
      <!-- End of Main Content -->  

  
<!-- Modal Add -->
<div class="modal fade" id="newUserModal" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <form action="<?=base_url('C_menu/addDataUser'); ?>" method="post">
        <div class="modal-body">
            <div class="form-group">
                <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" autocomplete="off">
                <?= form_error('username', '<small class="text-danger pl-1">', '</small>');?>
            </div>
            <div class="form-group">
                <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email" autocomplete="off">
                <!-- <input type="hidden" class="form-control" name="password" value='$2y$10$CvUro5cI/alynZ8/OIfi/u00pvLFi/GVDXl2K0dmlQIDMZSlO6C4e'>  -->
                <?= form_error('email', '<small class="text-danger pl-1">', '</small>');?>
            </div>
            <div class="form-group">
                <input type="password" class="form-control" id="password1" name="password1" placeholder="Enter password">
                <?= form_error('password1','<small class="text-danger pl-3">','</small>');?>
            </div>
            <div class="form-group">
                <input type="password" class="form-control" id="password2" name="password2" placeholder="Repeat password">
                <?= form_error('password2','<small class="text-danger pl-3">','</small>');?>
            </div>
            <!-- <input type="checkbox" onclick="defPassword()">Default Password
            <br>
            <input type="checkbox" onclick="showPassword()">Show Password -->
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-hops">Add</button>
    </div>
    </form>
    </div>
</div>
</div>

<!-- Modal Edit -->
<div class="modal fade" id="edit-data-user" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Data User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <form action="<?=base_url('C_menu/editDataUser'); ?>" method="post">
        <div class="modal-body">
            <div class="form-group">
                <input type="hidden" class="form-control" id="id" name="id">
                <input type="text" class="form-control" id="name" name="name" placeholder="Enter username">
                <?= form_error('name', '<small class="text-danger pl-1">', '</small>');?>
            </div>
            <div class="form-group">
                <input type="text" class="form-control" id="slug" name="slug" placeholder="Enter slug" autocomplete="off">
                <?= form_error('slug', '<small class="text-danger pl-1">', '</small>');?>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-hops">Save</button>
    </div>
    </form>
    </div>
</div>
</div>
<!-- END Modal Ubah -->