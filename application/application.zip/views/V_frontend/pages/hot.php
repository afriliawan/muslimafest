	<!-- content-wrapper START -->
	<div class="content-wrapper" style="overflow:auto; clear:both;">
		
		<!---------------------------------------------------------- ------------------------------- col-left START ------------------------------------------------------------------------------------->
		<div class="col-left">
			<div class="title-kanal">HOT</div>
			
			
			<section class="valign bottom headline kanal" style="background-image:url(<?= $listHot[0]['jetpack_featured_media_url']; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
			<div class="headline-title-box">
				
				
				<div class="author">
					<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
						</div>
					</div>
					<div class="author-right">
						<div class="author-name reverse"><?= $listHot[0]['author_detail']['name']; ?></div>
						<?php
							$UTC = strtotime($listHot[0]['date_gmt']);
						?>
						<div class="date reverse"><?= date("Y-m-d | H:i", $UTC + 7*60*60); ?></div>
					</div>
				</div>
				<?php
					$idBerita = $listHot[0]['id'];
				?>
				<a href="<?= base_url('detail/') . $idBerita; ?>"><p class="headline-title-teks kanal"><?= $listHot[0]['title']['rendered']; ?></p>
				</a>
				<div class="desc">
					<p><?= $listHot[0]['excerpt']['rendered']; ?></p>
				</div>
			</div>
			</section>
			
			<div style="margin-top:20px;"></div>
			
			<!---- List biasa Kanal---->
    		<div class="listbox">
				<div class="listbox-left">
				<?php
					$idBerita = $listHot[1]['id'];
				?>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><div class="img-holder" style="background-image:url(<?= $listHot[1]['jetpack_featured_media_url']; ?>img/img-artikel-3.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-03.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
							<div class="author-name"><?= $listHot[1]['author_detail']['name']; ?></div>
							<?php
								$UTC = strtotime($listHot[1]['date_gmt']);
							?>
							<div class="date"><?= date("Y-m-d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><p class="headline-title-teks medium"><?= $listHot[1]['title']['rendered']; ?></a>
					<div class="desc small">
						<p><?= $listHot[1]['excerpt']['rendered']; ?></p>
					</div>
				</div>
			</div>
			<!---- List biasa Kanal---->
			
			
			<!---- List biasa Kanal---->
    		<div class="listbox">
				<div class="listbox-left">
				<?php
					$idBerita = $listHot[2]['id'];
				?>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><div class="img-holder" style="background-image:url(<?= $listHot[2]['jetpack_featured_media_url']; ?>img/img-artikel-3.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-03.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
							<div class="author-name"><?= $listHot[2]['author_detail']['name']; ?></div>
							<?php
								$UTC = strtotime($listHot[2]['date_gmt']);
							?>
							<div class="date"><?= date("Y-m-d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><p class="headline-title-teks medium"><?= $listHot[2]['title']['rendered']; ?></a>
					<div class="desc small">
						<p><?= $listHot[2]['excerpt']['rendered']; ?></p>
					</div>
				</div>
			</div>
			<!---- List biasa Kanal---->
			
			
			<!---- List biasa Kanal---->
    		<div class="listbox">
				<div class="listbox-left">
				<?php
					$idBerita = $listHot[3]['id'];
				?>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><div class="img-holder" style="background-image:url(<?= $listHot[3]['jetpack_featured_media_url']; ?>img/img-artikel-3.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-03.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
							<div class="author-name"><?= $listHot[3]['author_detail']['name']; ?></div>
							<?php
								$UTC = strtotime($listHot[3]['date_gmt']);
							?>
							<div class="date"><?= date("Y-m-d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><p class="headline-title-teks medium"><?= $listHot[3]['title']['rendered']; ?></a>
					<div class="desc small">
						<p><?= $listHot[3]['excerpt']['rendered']; ?></p>
					</div>
				</div>
			</div>
			<!---- List biasa Kanal---->
			
			
			<!---- List biasa Kanal---->
    		<div class="listbox">
				<div class="listbox-left">
				<?php
					$idBerita = $listHot[4]['id'];
				?>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><div class="img-holder" style="background-image:url(<?= $listHot[4]['jetpack_featured_media_url']; ?>img/img-artikel-3.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-03.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
							<div class="author-name"><?= $listHot[4]['author_detail']['name']; ?></div>
							<?php
								$UTC = strtotime($listHot[4]['date_gmt']);
							?>
							<div class="date"><?= date("Y-m-d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><p class="headline-title-teks medium"><?= $listHot[4]['title']['rendered']; ?></a>
					<div class="desc small">
						<p><?= $listHot[4]['excerpt']['rendered']; ?></p>
					</div>
				</div>
			</div>
			<!---- List biasa Kanal---->
			
			<!--BANNER AD-->
			<div class="banner-ad">
				<img src="<?= base_url('assets/frontend/'); ?>img/ad-middle-banner-640x90.jpg" width=100%>
			</div>
			
			<div style="margin-bottom:30px;"></div>
			
			<!---- List biasa Kanal---->
    		<div class="listbox">
				<div class="listbox-left">
				<?php
					$idBerita = $listHot[5]['id'];
				?>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><div class="img-holder" style="background-image:url(<?= $listHot[5]['jetpack_featured_media_url']; ?>img/img-artikel-3.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-03.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
							<div class="author-name"><?= $listHot[5]['author_detail']['name']; ?></div>
							<?php
								$UTC = strtotime($listHot[5]['date_gmt']);
							?>
							<div class="date"><?= date("Y-m-d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><p class="headline-title-teks medium"><?= $listHot[5]['title']['rendered']; ?></a>
					<div class="desc small">
						<p><?= $listHot[5]['excerpt']['rendered']; ?></p>
					</div>
				</div>
			</div>
			<!---- List biasa Kanal---->

			<!---- List biasa Kanal---->
    		<div class="listbox">
				<div class="listbox-left">
				<?php
					$idBerita = $listHot[6]['id'];
				?>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><div class="img-holder" style="background-image:url(<?= $listHot[6]['jetpack_featured_media_url']; ?>img/img-artikel-3.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-03.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
							<div class="author-name"><?= $listHot[6]['author_detail']['name']; ?></div>
							<?php
								$UTC = strtotime($listHot[6]['date_gmt']);
							?>
							<div class="date"><?= date("Y-m-d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><p class="headline-title-teks medium"><?= $listHot[6]['title']['rendered']; ?></a>
					<div class="desc small">
						<p><?= $listHot[6]['excerpt']['rendered']; ?></p>
					</div>
				</div>
			</div>
			<!---- List biasa Kanal---->

			<!---- List biasa Kanal---->
    		<div class="listbox">
				<div class="listbox-left">
				<?php
					$idBerita = $listHot[7]['id'];
				?>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><div class="img-holder" style="background-image:url(<?= $listHot[7]['jetpack_featured_media_url']; ?>img/img-artikel-3.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-03.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
							<div class="author-name"><?= $listHot[7]['author_detail']['name']; ?></div>
							<?php
								$UTC = strtotime($listHot[7]['date_gmt']);
							?>
							<div class="date"><?= date("Y-m-d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><p class="headline-title-teks medium"><?= $listHot[7]['title']['rendered']; ?></a>
					<div class="desc small">
						<p><?= $listHot[7]['excerpt']['rendered']; ?></p>
					</div>
				</div>
			</div>
			<!---- List biasa Kanal---->

			<!---- List biasa Kanal---->
    		<div class="listbox">
				<div class="listbox-left">
				<?php
					$idBerita = $listHot[8]['id'];
				?>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><div class="img-holder" style="background-image:url(<?= $listHot[8]['jetpack_featured_media_url']; ?>img/img-artikel-3.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-03.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
							<div class="author-name"><?= $listHot[8]['author_detail']['name']; ?></div>
							<?php
								$UTC = strtotime($listHot[8]['date_gmt']);
							?>
							<div class="date"><?= date("Y-m-d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><p class="headline-title-teks medium"><?= $listHot[8]['title']['rendered']; ?></a>
					<div class="desc small">
						<p><?= $listHot[8]['excerpt']['rendered']; ?></p>
					</div>
				</div>
			</div>
			<!---- List biasa Kanal---->

			<!---- List biasa Kanal---->
    		<div class="listbox">
				<div class="listbox-left">
				<?php
					$idBerita = $listHot[9]['id'];
				?>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><div class="img-holder" style="background-image:url(<?= $listHot[9]['jetpack_featured_media_url']; ?>img/img-artikel-3.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="listbox-right">
					<div class="author">
						<div class="author-left">
						<div class="author-pic small" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-03.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;">
							</div>
						</div>
						<div class="author-right">
							<div class="author-name"><?= $listHot[9]['author_detail']['name']; ?></div>
							<?php
								$UTC = strtotime($listHot[9]['date_gmt']);
							?>
							<div class="date"><?= date("Y-m-d | H:i", $UTC + 7*60*60); ?></div>
						</div>
					</div>
					<div style="margin-bottom:25px;"></div>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><p class="headline-title-teks medium"><?= $listHot[9]['title']['rendered']; ?></a>
					<div class="desc small">
						<p><?= $listHot[9]['excerpt']['rendered']; ?></p>
					</div>
				</div>
			</div>
			<!---- List biasa Kanal---->
			
			<!-- <div style="clear:both;">
				<a href="<?= base_url('assets/frontend/'); ?>#"><div class="btn-load-more">Tampilkan Lebih Banyak</div></a>
				</div> -->
			
			
  		</div>
		<!---------------------------------------------------------- ------------------------------- col-left END -------------------------------------------------------------------------------------->

  		
		<!---------------------------------------------------------- ------------------------------- col-right START ----------------------------------------------------------------------------------->
		<div class="col-right">
    		<div class="title-section">Pengguna Baru</div>
			<div style="margin-top:20px;"></div>
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-03.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name">Margot Reth</div>
						<div class="jml-artikel">21 Artikel</div>
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name">Vanda Maria Bonfanti</div>
						<div class="jml-artikel">19 Artikel</div>
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-02.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name">Gita Yarsi</div>
						<div class="jml-artikel">21 Artikel</div>
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-04.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name">Debby Harry</div>
						<div class="jml-artikel">19 Artikel</div>
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<!---- List Top Writer---->
			<div class="top-writer">
				<div class="kol-separuh-rightcol left">
					<div class="img-holder author" style="background-image:url(<?= base_url('assets/frontend/'); ?>img/author-03.jpg); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<div class="author-name">Sondang Silaen</div>
						<div class="jml-artikel">21 Artikel</div>
					</div>
					
				</div>
			</div>
			<!---- List Top Writer---->
			
			<div style="margin-top:30px;"></div>
			
			<!--BANNER AD-->
				<div class="title-section">Advertisement</div>
				
				<div style="margin-top:20px;"></div>
				<div class="banner-ad">
					<img src="<?= base_url('assets/frontend/'); ?>img/ad-rectangle-banner-300x250.jpg" width=300>
				</div>
				<div style="margin-top:30px;"></div>
			
			
			
			<div class="title-section" style="clear:both;">Terbaru</div>
			<div style="margin-top:20px;"></div>
			
			<!---- List ---->
			<?php
                    foreach($hasilTerbaru as $hTe){ ?>
			<div class="row-list rightcol">
				<div class="kol-separuh-rightcol left">
				<?php
                    $idBerita = $hTe->id;
                ?>
				<a href="<?= base_url('detail/') . $idBerita; ?>">
					<div class="img-holder" style="background-image:url(<?= $hTe->jetpack_featured_media_url; ?>); background-position-x: center; background-position-y: center; background-size: cover; background-repeat: no-repeat;"></div></a>
				</div>
				
				<div class="kol-separuh-rightcol right">
					<div class="author">
						<?php
							$UTC = strtotime($hTe->date_gmt);
							foreach($hTe->cat_detail as $cd){ ?>
						<div class="author-name small"><span><?= $cd->name; ?></span>&nbsp; | &nbsp;<?= $hTe->author_detail->name; ?></div>
						<?php } ?>
						<div class="date small"><?= date("Y-m-d | H:i", $UTC + 7*60*60); ?></div>
					</div>
					<a href="<?= base_url('detail/') . $idBerita; ?>"><p class="headline-title-teks small"><?= $hTe->title->rendered; ?></p></a>
				</div>
			</div>
			<!---- List ---->
			
			<!-- <div style="margin-top:15px;"></div> -->
			
			<?php } ?>
			<div style="margin-top:30px;"></div>
			
			<!--BANNER AD-->

				<div class="title-section">Advertisement</div>
				
				<div style="margin-top:20px;"></div>
				<div class="banner-ad">
					<img src="<?= base_url('assets/frontend/'); ?>img/ad-rectangle-banner-300x250.jpg" width=300>
				</div>
				<div style="margin-top:30px;"></div>
			
			
			
			
  		</div>
		<!---------------------------------------------------------- ------------------------------- col-right END ------------------------------------------------------------------------------------->
	</div>
	<!-- content-wrapper END -->
