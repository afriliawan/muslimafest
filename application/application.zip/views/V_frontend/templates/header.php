<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">


<link href="<?= base_url('assets/frontend/');?>css/style.css" rel="stylesheet" type="text/css" media="all">
<link href="<?= base_url('assets/frontend/');?>css/mobile.css" rel="stylesheet" type="text/css" media="all">

<link rel="stylesheet" href="<?= base_url('assets/frontend/');?>font-awesome-4.7.0/css/font-awesome.css">
<link rel="stylesheet" href="<?= base_url('assets/frontend/');?>font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tokenfield/0.12.0/css/bootstrap-tokenfield.min.css">

<title><?= $title; ?></title>
</head>
<body style="color:#aaaaaa;">

<div class="page-wrapper"><!-- page-wrapper START -->
	
	<header>
		<div class="header-left">
			<a href="<?= base_url('home'); ?>"><img src="<?= base_url('assets/frontend/');?>img/hops-logo.png" width=112></a>
		</div>
		<div class="header-hops-mobile"><a href="<?= base_url('assets/frontend/'); ?>#"><img src="<?= base_url('assets/frontend/');?>img/hops-logo.png" width=106></a></div>
	
		<div class="header-right">
			<div class="header-hops-media">
			<ul>
  				<li>
    				<img src="<?= base_url('assets/frontend/');?>img/hopsmedia-logo.png" width=40>
    				<ul>
					<li><a href="https://hops.id/" target="_blank">Hops</a></li>
					<li><a href="https://depoktoday.hops.id/" target="_blank">Depok Today</a></li>
					<li><a href="https://kulinear.hops.id/" target="_blank">Kulinear</a></li>
					<li><a href="https://muslima.hops.id/" target="_blank">Muslima</a></li>
					<li><a href="https://koreabanget.hops.id/" target="_blank">Korea Banget</a></li>
					<li><a href="https://bisnika.hops.id/" target="_blank">Bisnika</a></li>
					<li><a href="https://ceklissatu.com/" target="_blank">Ceklis Satu</a></li>
    				</ul>
  				</li>
			</ul>
			</div>
			
			<div class="socmed">
				<ul class="socmed-group">
					<a href="https://www.facebook.com/HopsIndonesia/" target="_blank"><li class="socmed-item">
						<i class="fa fa-facebook" style="font-size:14px; color:#eee;"></i>
					</li></a>
					<a href="https://twitter.com/hopsindonesia" target="_blank"><li class="socmed-item">
						<i class="fa fa-twitter" style="font-size:14px; color:#eee;"></i>
					</li></a>
					<a href="https://www.instagram.com/hopsindonesia/" target="_blank"><li class="socmed-item">
						<i class="fa fa-instagram" style="font-size:14px; color:#eee;"></i>
					</li></a>
					<a href="https://www.youtube.com/channel/UCw_DhNdOiTy2RsZ0XrSJSlg" target="_blank"><li class="socmed-item">
						<i class="fa fa-youtube" style="font-size:14px; color:#eee;"></i>
					</li></a>
					<a href="<?= base_url('assets/frontend/'); ?>#" target="_blank"><li class="socmed-item">
						<i class="fa fa-linkedin" style="font-size:14px; color:#eee;"></i>
					</li></a>
				</ul>
			</div>
		</div>
	</header>
	
	<a href="<?= base_url('C_user'); ?>">
	<div class="btn-tulis">
		<img src="<?= base_url('assets/frontend/');?>img/btn-tulis.png" width=142>
	</div>
	</a>

	<header class="headerz">
		
		
		<div class="nav-center">
			<input class="menu-btn" type="checkbox" id="menu-btn" />
  			<label class="menu-icon" for="menu-btn"><span class="navicon"></span></label>
			
			
			<div class="menu left">
			<!--Search START --->
				<div class="search-box">
    				<button class="btn-search"><i class="fa fa-search"></i></button>
    				<input type="text" class="input-search" placeholder="Type to Search...">
  				</div>
			<!-- Search END --->
			</div>
			
  			<ul class="menu">
    			<li><a href="<?= base_url('home'); ?>">HOME</a></li>
    			<li><a href="<?= base_url('trending'); ?>"><img src="<?= base_url('assets/frontend/');?>img/mug.gif" width=25 class="icon-mug"><img src="<?= base_url('assets/frontend/');?>img/mug-grey.gif" width=22 class="icon-mug-grey">&nbsp;TRENDING</a></li>
    			<li><a href="<?= base_url('unik'); ?>">UNIK</a></li>
    			<li><a href="<?= base_url('hot'); ?>">HOT</a></li>
				<li><a href="<?= base_url('hobi'); ?>" style="border-right: none!important;">HOBI</a></li>
  			</ul>
			
			
			
			<div class="menu right">
				<a href="<?= base_url('C_auth/registration'); ?>">
				<div class="btn-daftar">
					<div class="btn-daftar-label">
						<img src="<?= base_url('assets/frontend/');?>img/icon-daftar.png" width=25>&nbsp;&nbsp;Daftar
					</div>
				</div>
				</a>
			</div>
		</div>
	</header>
	