<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">


<link href="<?=base_url('assets/frontend/'); ?>css/auth.css" rel="stylesheet" type="text/css" media="all">

<title>Daftar akun baru</title>
</head>
<body>
	
<div class="page-wrapper"><!-- page-wrapper START -->
	
	<!-- content-wrapper START -->
	<div class="content-wrapper-absolute-center daftar">
		<div class="auth-col-left">
			<a href="<?= base_url('C_frontend'); ?>"><img src="<?= base_url('assets/frontend/'); ?>img/hops-logo.png" width=112></a>
		</div>
		<div class="auth-col-right">
			<div class="auth-box-title">
				Daftar akun baru!
			</div>
			<div class="row">
				<div class="col-lg-8">
					<?= $this->session->flashdata('message'); ?>
				</div>
			</div>
			<div class="auth-field">
                <form method="post" action="<?= base_url('C_auth/registration');?>">
				<div class="row-full">
					<input type="text" id="username" name="username" placeholder="Masukkan username..">
                    <?= form_error('username','<small class="text-danger pl-3">','</small>');?>
				</div>
				<div class="row-full" style="margin-top: 20px;">
					<input type="text" id="email" name="email" placeholder="Masukkan alamat email..">
				</div>
				<div class="row-full" style="margin-top: 20px;">
					<div class="auth-col-right half">
						<input type="password" id="password1" name="password1" placeholder="Masukkan password..">
                        <?= form_error('password1','<small class="text-danger pl-3">','</small>');?>
					</div>
					<div class="auth-col-right half">
						<input type="password" id="password2" name="password2" placeholder="Ulangi masukkan password..">
                        <?= form_error('password2','<small class="text-danger pl-3">','</small>');?>
					</div>
				</div>
				<div class="row-full">	
					<div class="auth-box-btm" style="margin-top: 20px;">
						<a href="<?= base_url('C_auth/forgotPassword'); ?>"><span style="float:left;">Lupa password</span></a>
						<a href="<?= base_url('C_auth'); ?>"><span style="float:right;">Sudah punya akun? login!</span></a>
					</div>
                    <input type="submit" value="Daftar Akun">
				</div>
            </form>
			</div>

			
		</div>
	
	</div>
	<!-- content-wrapper END -->

</div><!-- page-wrapper END -->
	
</body>
</html>
