
<style>
/* Custom css dari bootstrap lain */
.text-danger {
	color: #e74a3b!important;
  }
  .alert {
	position: relative;
	padding: .75rem 1.25rem;
	margin-bottom: 1rem;
	border: 1px solid transparent;
	border-radius: .35rem;
  }
  .alert-success {
	color: #0f6848;
	background-color: #d2f4e8;
	border-color: #bff0de;
  }
  
  .alert-danger {
	color: #78261f;
	background-color: #fadbd8;
	border-color: #f8ccc8;
  }
  </style>