<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_frontend extends CI_Controller 
{
    //Halaman Detail
    public function detail($id) {
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/posts/".$id,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        //Harus true
        $responsenya = json_decode($response, true);
        //Ambil Judulnya untuk <title>
        $judulnya = $responsenya['title']['rendered'];
        //Ambil ID Categories untuk dilempar ke $data['hasilCategories']
        $kategori = $responsenya['categories'][0];
        //Ambil Array tags untuk dilempar ke $data['hasilTags']
        $tagsnya = $responsenya['tag_detail'];
                    $tags = "";
                    $i = 0;
                    
                    foreach ($tagsnya as $allTags) {
                        if($i==0){
                            $tags = $allTags['id'];
                        } else {
                            $tags = $tags . ',' . $allTags['id'];
                        }
                        $i++;
                    }
        // echo $tags;
        // die;
    //Hasil Artikel Terbaru
        $curlTerbaru = curl_init();

        curl_setopt_array($curlTerbaru, array(
        CURLOPT_URL => 'beta.hops.id/wp-json/wp/v2/posts?per_page=10',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $responseTerbaru = curl_exec($curlTerbaru);

        curl_close($curlTerbaru);

        //Hasil tags
        $curlTags = curl_init();

        curl_setopt_array($curlTags, array(
        CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/posts/?per_page=3&tags=" . $tags,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        ));

        $responseTags = curl_exec($curlTags);

        curl_close($curlTags);

        //Hasil Categories
        $curlCategories = curl_init();

        curl_setopt_array($curlCategories, array(
        CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/posts/?per_page=4&categories=" . $kategori,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        ));

        $responseCategories = curl_exec($curlCategories);

        curl_close($curlCategories);

        $data['title'] = $judulnya;
        $data['hasilTerbaru'] = json_decode($responseTerbaru);
        $data['hasil'] = json_decode($response);
        $data['hasilTags'] = json_decode($responseTags, true);
        $data['hasilCategories'] = json_decode($responseCategories, true);
        
        $this->load->view('V_frontend/templates/header_detail', $data);
        $this->load->view('V_frontend/pages/detail', $data);
        $this->load->view('V_frontend/templates/footer_sticky');
        
    }

    //--------------------------------------------------------------------------------------------//
    public function index()
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://beta.hops.id/wp-json/wp/v2/posts?per_page=30',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => 'beta.hops.id/wp-json/wp/v2/posts?per_page=1',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $responseHasil = curl_exec($curl);

        curl_close($curl);
        //Hasil2
        $curl2 = curl_init();

        curl_setopt_array($curl2, array(
        CURLOPT_URL => 'beta.hops.id/wp-json/wp/v2/posts?per_page=4',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $response2 = curl_exec($curl2);

        curl_close($curl2);


        // $data['headlineDtl'] = json_decode($response);
        $data['title'] = "Home";
        $data['headline'] = json_decode($response, true);
        
        $data['hasil'] = json_decode($responseHasil);
        $data['hasil2'] = json_decode($response2);
        // foreach($data['headline'] as $val) {
        //     return var_dump($val);
        //  }
        $this->load->view('V_frontend/templates/header', $data);
        $this->load->view('V_frontend/pages/index', $data);
        $this->load->view('V_frontend/templates/footer');

        // $arrayArticles = json_decode($response);
        // var_dump($arrayArticles[0]->cat_detail);
        // die;
    }

    //Halaman Kanal - Trending
    public function trending() {
        //List Kanal Trending
        $curlTrendingList = curl_init();

        curl_setopt_array($curlTrendingList, array(
        CURLOPT_URL => 'beta.hops.id/wp-json/wp/v2/posts?per_page=30&categories=93',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $responseTrendingList = curl_exec($curlTrendingList);

        curl_close($curlTrendingList);

        //Hasil Artikel Terbaru
        $curlTerbaru = curl_init();

        curl_setopt_array($curlTerbaru, array(
        CURLOPT_URL => 'beta.hops.id/wp-json/wp/v2/posts?per_page=10',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $responseTerbaru = curl_exec($curlTerbaru);

        curl_close($curlTerbaru);
        $data['title'] = "Trending";
        $data['listTrending'] = json_decode($responseTrendingList, true);
        $data['hasilTerbaru'] = json_decode($responseTerbaru);
        $this->load->view('V_frontend/templates/header', $data);
        $this->load->view('V_frontend/pages/trending', $data);
        $this->load->view('V_frontend/templates/footer');
    }

    //Halaman Kanal - Unik
    public function unik() {
        //List Kanal Unik
        $curlUnikList = curl_init();

        curl_setopt_array($curlUnikList, array(
        CURLOPT_URL => 'beta.hops.id/wp-json/wp/v2/posts?per_page=30&categories=97',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $responseUnikList = curl_exec($curlUnikList);

        curl_close($curlUnikList);

        //Hasil Artikel Terbaru
        $curlTerbaru = curl_init();

        curl_setopt_array($curlTerbaru, array(
        CURLOPT_URL => 'beta.hops.id/wp-json/wp/v2/posts?per_page=10',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $responseTerbaru = curl_exec($curlTerbaru);

        curl_close($curlTerbaru);
        $data['title'] = "Unik";
        $data['listUnik'] = json_decode($responseUnikList, true);
        $data['hasilTerbaru'] = json_decode($responseTerbaru);
        $this->load->view('V_frontend/templates/header', $data);
        $this->load->view('V_frontend/pages/unik', $data);
        $this->load->view('V_frontend/templates/footer');
    }

    //Halaman Kanal - Unik
    public function hot() {
        //List Kanal Unik
        $curlHotList = curl_init();

        curl_setopt_array($curlHotList, array(
        CURLOPT_URL => 'beta.hops.id/wp-json/wp/v2/posts?per_page=30&categories=95',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $responseHotList = curl_exec($curlHotList);

        curl_close($curlHotList);

        //Hasil Artikel Terbaru
        $curlTerbaru = curl_init();

        curl_setopt_array($curlTerbaru, array(
        CURLOPT_URL => 'beta.hops.id/wp-json/wp/v2/posts?per_page=10',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $responseTerbaru = curl_exec($curlTerbaru);

        curl_close($curlTerbaru);
        $data['title'] = "Hot";
        $data['listHot'] = json_decode($responseHotList, true);
        $data['hasilTerbaru'] = json_decode($responseTerbaru);
        $this->load->view('V_frontend/templates/header', $data);
        $this->load->view('V_frontend/pages/hot', $data);
        $this->load->view('V_frontend/templates/footer');
    }
    
    
    //Halaman Kanal - Unik
    public function hobi() {
        //List Kanal Unik
        $curlHobiList = curl_init();

        curl_setopt_array($curlHobiList, array(
        CURLOPT_URL => 'beta.hops.id/wp-json/wp/v2/posts?per_page=30&categories=95',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $responseHobiList = curl_exec($curlHobiList);

        curl_close($curlHobiList);

        //Hasil Artikel Terbaru
        $curlTerbaru = curl_init();

        curl_setopt_array($curlTerbaru, array(
        CURLOPT_URL => 'beta.hops.id/wp-json/wp/v2/posts?per_page=10',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $responseTerbaru = curl_exec($curlTerbaru);

        curl_close($curlTerbaru);
        $data['title'] = "Hobi";
        $data['listHobi'] = json_decode($responseHobiList, true);
        $data['hasilTerbaru'] = json_decode($responseTerbaru);
        $this->load->view('V_frontend/templates/header', $data);
        $this->load->view('V_frontend/pages/hobi', $data);
        $this->load->view('V_frontend/templates/footer');
    }
}
