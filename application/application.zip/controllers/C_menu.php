<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_menu extends CI_Controller 
{
    // public function __construct()
    // {
    //     parent::__construct();
    //     is_logged_in();
    // }

    public function index()
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => "beta.hops.id/wp-json/wp/v2/users",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "username: afrhops",
            "email: afrhops@hops.id",
            "password: 12345678",
            "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        $data['title'] = 'Data User'; 
        $data['user'] = $this->session->userdata();
        $data['hasil'] = json_decode($response);
        
        $this->load->view('V_backend/templates/header', $data);
        $this->load->view('V_backend/templates/sidebar');
        $this->load->view('V_backend/templates/topbar');
        $this->load->view('V_backend/pages/menu/user-data.php', $data);
        $this->load->view('V_backend/templates/footer');    
    }
    
    public function addDataUser()
    {
        $this->form_validation->set_rules('password1', 'Password', 'required|trim|min_length[6]|matches[password2]', [
            'matches' => 'Password dont match !',
            'min_length' => 'Password too short !'
        ]);
        $this->form_validation->set_rules('password2', 'Password', 'required|trim|matches[password1]');

        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/users?username=".$this->input->post('username')."&name=".$this->input->post('username')."&email=".$this->input->post('email')."&password=".$this->input->post('password1')."",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        
        redirect('C_menu');
    }

    public function editDataUser()
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(

        CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/users/".$this->input->post('id')."?name=".$this->input->post('name')."&slug=".$this->input->post('slug')."",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "PUT",
        CURLOPT_HTTPHEADER => array(
            "id: ".$this->input->post('id')."",
            "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Data has been changed! <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        redirect('C_menu');
    }

    public function deleteUser($idUser)
	{
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/users/".$idUser."?reassign=0&force=true",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "DELETE",
        CURLOPT_HTTPHEADER => array(
            "id: ".$this->input->post('id')."",
            "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">Delete user has been successfully !</div>');
        redirect('C_menu');
    }

    public function myBlog()
    {
        $curl = curl_init();
        
        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/posts?author=".$this->session->userdata('id')."&status=%5B%5D",
        //   CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/posts?author=".$this->session->userdata('USERNAME')."",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "GET",
          CURLOPT_HTTPHEADER => array(
            "reassign: ",
            "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
          ),
        ));
        $response = curl_exec($curl);
        
        curl_close($curl);

        $data['title'] = 'Data Blog'; 
        $data['hasil'] = json_decode($response);
        $data['user'] = $this->session->userdata();

        $this->load->view('V_backend/templates/header', $data);
        $this->load->view('V_backend/templates/sidebar');
        $this->load->view('V_backend/templates/topbar');
        $this->load->view('V_backend/pages/menu/blog-saya.php', $data);
        $this->load->view('V_backend/templates/footer');    
    }
    
    
    public function formCreateBlog()
    {
        $this->form_validation->set_rules('title', 'Title name', 'required|trim');
        // $this->form_validation->set_rules('tags', 'Tags name', 'required|trim');
        // $this->form_validation->set_rules('imageID', 'Thumbnail photo', 'required');
        if ($this->form_validation->run() == false) {
        $data['title'] = 'Create New Blog';
        $data['user'] = $this->session->userdata();
        $data['categories'] = $this->M_menu->getCategories();
        $data['thumbnail'] = $this->M_menu->getThumbnail();
        // echo "atas";
        // die;
        $this->load->view('V_backend/templates/header-archive', $data);
        $this->load->view('V_backend/templates/header', $data);
        $this->load->view('V_backend/templates/sidebar');
        $this->load->view('V_backend/templates/topbar');
        $this->load->view('V_backend/pages/menu/form-create-blog.php', $data);
        $this->load->view('V_backend/templates/footer-archive');   
        
        } else {
        $ch = curl_init();
        $thumbnail = $this->input->post('thumbnail');
        if ($thumbnail=''){}else{
        $config['upload_path']      = './images/foto/thumbnail/';
        $config['allowed_types']    = 'jpg|png|jpeg|gif';

            $this->load->library('upload', $config);
            if(!$this->upload->do_upload('thumbnail')){
                echo "Upload gagal"; die();
            }else{
                $thumbnail=$this->upload->data('file_name');
            }
        }
        $path = "./images/foto/thumbnail/".$thumbnail;
        
        $file = file_get_contents($path);
        $url = 'https://beta.hops.id/wp-json/wp/v2/media/';
        
        curl_setopt( $ch, CURLOPT_URL, $url );
        curl_setopt( $ch, CURLOPT_POST, 1 );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $file );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, [
            'Content-Disposition: form-data; filename="sample.jpg"',
            "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
        ] );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch, CURLOPT_ENCODING, "" );
        curl_setopt( $ch, CURLOPT_MAXREDIRS, 10 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 0 );
        curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
        curl_setopt( $ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1 );
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, "POST" );
        $response = curl_exec( $ch );
        // print_r($response);

        // die;
        curl_close( $ch );
        $cek = json_decode($response);
            // var_dump($cek);
            //EKSEKUSI ADD DATA
            $curl = curl_init();
            $title = urlencode($this->input->post('title'));
            $name = urlencode($this->input->post('name'));
            $tags = urlencode($this->input->post('tags'));
            $author = urlencode($this->input->post('author'));
            // echo $tags;
            // die;
            // var_dump($author);
            // die;
            //Filter tags 
            $tags = preg_match_all("'%28(.*?)%29'",$tags, $hasil);
            // $tags = preg_match_all("'%23(.*?)%2C'",$tags, $hasil);
            // $tags = preg_match_all("'%23'",$tags, $hasil);
            // echo $tags;
            // die;
            $allTags = '';
            $i = 0;
            
            foreach ($hasil[1] as $tags) {
                if($i==0){
                    $allTags = $tags;
                } else {
                    $allTags = $allTags . ',' . $tags;
                }
                $i++;
            }
            echo $allTags;
            die;
            $content = urlencode($this->input->post('content'));
            $categories = urlencode($this->input->post('categories'));
            $thumbnail = $cek->id;
            // if($thumbnail!="") 
            // {
            //     $thumbnail='&featured_media='.$thumbnail;
            // }
            //Jika content di isi dengan gambar msih error, namun di function edit data, foto dapat diupload
            
            curl_setopt_array($curl, array(
            CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/posts/?title=".$title."&name=".$name."&categories=".$categories."&content=".$content."&tags=".$allTags."&featured_media=".$thumbnail."&author=".$author."",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_HTTPHEADER => array(
                "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
            ),
            ));

            $response = curl_exec($curl);
            curl_close($curl);
            $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">Create new post has been successfully !</div>');
            redirect('C_menu/myBlog');
        }
    }
    
    // public function addNewPost()
    // {

    //     $curl = curl_init();
    //     $title = urlencode($this->input->post('title'));
    //     $name = urlencode($this->input->post('name'));
    //     $tags = urlencode($this->input->post('tags'));
    //     $author = urlencode($this->input->post('author'));

    //     // var_dump($author);
    //     // die;
    //     //Filter tags 
    //     $tags = preg_match_all("'%28(.*?)%29'",$tags, $hasil);
    //     $allTags = '';
    //     $i = 0;
        
    //     foreach ($hasil[1] as $tags) {
    //         if($i==0){
    //             $allTags = $tags;
    //         } else {
    //             $allTags = $allTags . ',' . $tags;
    //         }
    //         $i++;
    //     }
    //     $content = urlencode($this->input->post('content'));
    //     $categories = urlencode($this->input->post('categories'));
    //     $thumbnail = urlencode($this->input->post('imageID'));
    //     //Jika content di isi dengan gambar msih error, namun di function edit data, foto dapat diupload
        
    //     curl_setopt_array($curl, array(
    //     CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/posts/?title=".$title."&name=".$name."&categories=".$categories."&content=".$content."&tags=".$allTags."&featured_media=".$thumbnail."&author=".$author."",
    //     CURLOPT_RETURNTRANSFER => true,
    //     CURLOPT_ENCODING => "",
    //     CURLOPT_MAXREDIRS => 10,
    //     CURLOPT_TIMEOUT => 0,
    //     CURLOPT_FOLLOWLOCATION => true,
    //     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    //     CURLOPT_CUSTOMREQUEST => "POST",
    //     CURLOPT_HTTPHEADER => array(
    //         "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
    //     ),
    //     ));

    //     $response = curl_exec($curl);
    //     curl_close($curl);
        
    //     var_dump($response);
    //     die;
    //     $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">Create new post has been successfully !</div>');
    //     redirect('C_menu/myBlog');
    // }
    
    public function deletePost($idPost)
	{
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/posts/".$idPost."?force=true",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "DELETE",
        CURLOPT_HTTPHEADER => array(
            "id: ".$this->input->post('id')."",
            "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">Delete user has been successfully !</div>');
        redirect('C_menu/myBlog');
    }

    public function formEditPost($id)
    {
        $this->form_validation->set_rules('title', 'Title name', 'required|trim');
        $this->form_validation->set_rules('tags', 'Tags name', 'required|trim');
        if ($this->form_validation->run() == false) {
        $data['title'] = 'Edit Post';
        $data['user'] = $this->session->userdata();
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/posts/".$id,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "id: ".$this->input->post('id')."",
            "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
    
        $data['hasil'] = json_decode($response);
        $data['categories'] = $this->M_menu->getCategories();
        $data['thumbnail'] = $this->M_menu->getThumbnail();
        $data['user'] = $this->session->userdata();
        
        $this->load->view('V_backend/templates/header-archive', $data);
        $this->load->view('V_backend/templates/header', $data);
        $this->load->view('V_backend/templates/sidebar');
        $this->load->view('V_backend/templates/topbar');
        $this->load->view('V_backend/pages/menu/form-edit-blog.php', $data);
        $this->load->view('V_backend/templates/footer-archive'); 
        
    } else {
        //EKSEKUSI UPDATE DATA
        $curl = curl_init();
        $title = urlencode($this->input->post('title'));
        $author = urlencode($this->input->post('author'));
        $content = urlencode($this->input->post('content'));
        $thumbnail = urlencode($this->input->post('imageID'));
        $tags = urlencode($this->input->post('tags'));
        
        $tags = preg_match_all("'%28(.*?)%29'",$tags, $hasil);
        if($thumbnail!="") 
        {
            $thumbnail='&featured_media='.$thumbnail;
        }
        $allTags = '';
        $i = 0;
        
        foreach ($hasil[1] as $tags) {
            if($i==0){
                $allTags = $tags;
            } else {
                $allTags = $allTags . ',' . $tags;
            }
            $i++;
        }
        curl_setopt_array($curl, array(

        CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/posts/".$id."?title=".$title."&author=".$author."&categories=".$this->input->post('categories')."&tags=".$allTags."&content=".$content.$thumbnail."",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "PUT",
        CURLOPT_HTTPHEADER => array(
            "id: ".$this->input->post('id')."",
            "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
        ),
        ));

        $response = curl_exec($curl);
        // var_dump($response);
        // die;
        curl_close($curl);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Data has been changed! <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        redirect('C_menu/myBlog');
        }
    }

    
    public function editPost($id)
    {
        $curl = curl_init();
        $title = urlencode($this->input->post('title'));
        $author = urlencode($this->input->post('author'));
        $content = urlencode($this->input->post('content'));
        $thumbnail = urlencode($this->input->post('imageID'));
        $tags = urlencode($this->input->post('tags'));
        
        $tags = preg_match_all("'%28(.*?)%29'",$tags, $hasil);
        if($thumbnail!="") 
        {
            $thumbnail='&featured_media='.$thumbnail;
        }
        $allTags = '';
        $i = 0;
        
        foreach ($hasil[1] as $tags) {
            if($i==0){
                $allTags = $tags;
            } else {
                $allTags = $allTags . ',' . $tags;
            }
            $i++;
        }
        curl_setopt_array($curl, array(

        CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/posts/".$id."?title=".$title."&author=".$author."&categories=".$this->input->post('categories')."&tags=".$allTags."&content=".$content.$thumbnail."",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "PUT",
        CURLOPT_HTTPHEADER => array(
            "id: ".$this->input->post('id')."",
            "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
        ),
        ));

        $response = curl_exec($curl);
        // var_dump($response);
        // die;
        curl_close($curl);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Data has been changed! <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        redirect('C_menu/myBlog');
    }

    public function thumbnailPage()
    {
        $data['title'] = 'Upload Thumbnail';
        $data['user'] = $this->session->userdata();
        
        $this->load->view('V_backend/templates/header', $data);
        $this->load->view('V_backend/templates/sidebar');
        $this->load->view('V_backend/templates/topbar');
        $this->load->view('V_backend/pages/menu/form-upload-thumbnail', $data);
        $this->load->view('V_backend/templates/footer');   
    }

    public function addThumbnail()
    {
        $ch = curl_init();
        $thumbnail = $this->input->post('thumbnail');
        
        if ($thumbnail=''){}else{
        $config['upload_path']      = './images/foto/thumbnail/';
        $config['allowed_types']    = 'jpg|png|jpeg|gif';

            $this->load->library('upload', $config);
            if(!$this->upload->do_upload('thumbnail')){
                echo "Upload gagal"; die();
            }else{
                $thumbnail=$this->upload->data('file_name');
            }
        }
        $path = "./images/foto/thumbnail/".$thumbnail;
        
        $file = file_get_contents($path);
        $url = 'https://beta.hops.id/wp-json/wp/v2/media/';
        
        curl_setopt( $ch, CURLOPT_URL, $url );
        curl_setopt( $ch, CURLOPT_POST, 1 );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $file );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, [
            'Content-Disposition: form-data; filename="sample.jpg"',
            "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
        ] );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch, CURLOPT_ENCODING, "" );
        curl_setopt( $ch, CURLOPT_MAXREDIRS, 10 );
        curl_setopt( $ch, CURLOPT_TIMEOUT, 0 );
        curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
        curl_setopt( $ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1 );
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, "POST" );
        $response = curl_exec( $ch );
        curl_close( $ch );
        // var_dump($response);
        // die;
        $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">Upload thumbnail has been successfully !</div>');
        redirect('C_menu/thumbnailPage');
    }

    public function dashboard() 
    {
        $data['title'] = "Dashboard";
        $data['user'] = $this->session->userdata();

        $this->load->view('V_backend/templates/header', $data);
        $this->load->view('V_backend/templates/sidebar');
        $this->load->view('V_backend/templates/topbar');
        $this->load->view('V_backend/pages/menu/dashboard.php', $data);
        $this->load->view('V_backend/templates/footer');  
    }

    public function redeem() 
    {
        $data['title'] = "Redeem Point";
        $data['user'] = $this->session->userdata();

        $this->load->view('V_backend/templates/header', $data);
        $this->load->view('V_backend/templates/sidebar');
        $this->load->view('V_backend/templates/topbar');
        $this->load->view('V_backend/pages/menu/dashboard.php', $data);
        $this->load->view('V_backend/templates/footer');  
    }

    public function termAndConditions() 
    {
        $data['title'] = "Redeem Point";
        $data['user'] = $this->session->userdata();

        $this->load->view('V_backend/templates/header', $data);
        $this->load->view('V_backend/templates/sidebar');
        $this->load->view('V_backend/templates/topbar');
        $this->load->view('V_backend/pages/menu/term-and-conditions.php', $data);
        $this->load->view('V_backend/templates/footer');  
    }
}
