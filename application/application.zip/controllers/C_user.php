<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_user extends CI_Controller 
{

    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }
    
    public function index()
    {
        $data['title'] = 'My Profile'; 
        // $data['user'] = $this->db->get_where('ms_users', ['email' => $this->session->userdata('email')])->row_array();
        $data['user'] = $this->session->all_userdata();
        // var_dump($data);
        // echo '<pre>'; print_r($this->session->all_userdata());exit;
        // die;
        $this->load->view('V_backend/templates/header', $data);
        $this->load->view('V_backend/templates/sidebar');
        $this->load->view('V_backend/templates/topbar');
        $this->load->view('V_backend/pages/user/index', $data);
        $this->load->view('V_backend/templates/footer');    
    }
    
    public function editProfile()
    {
        $data['title'] = 'Edit Profile';
        // echo '<pre>'; print_r($this->session->all_userdata());exit;
        $data['user'] = $this->session->userdata();
        $this->form_validation->set_rules('name', 'Full name', 'required');
        // $this->form_validation->set_rules('nohp', 'number phone ', 'min_length[12]', 'max_length[13]');
        // $this->form_validation->set_rules('alamat', 'Address name', 'regex_match[/[a-zA-Z]$/]');

        if($this->form_validation->run() == false){
            $this->load->view('V_backend/templates/header', $data);
            $this->load->view('V_backend/templates/sidebar');
            $this->load->view('V_backend/templates/topbar');
            $this->load->view('V_backend/pages/user/edit-profile', $data);
            $this->load->view('V_backend/templates/footer'); 
        } else {
            $curl = curl_init();

            $name = $this->input->post('name');
            curl_setopt_array($curl, array(
            CURLOPT_URL => "https://beta.hops.id/wp-json/custom-plugin/update?name=".$name."",
            //hasilnya bad request ketika diubah name=".$name."
            // CURLOPT_URL => 'https://beta.hops.id/wp-json/custom-plugin/update?name=AkhillAfril',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk',
                'Cookie: wordpress_logged_in_0b733380a7e602c77d80b550b6596847=akhil%7C1629367411%7CJGmzt4QmqzF54ORIET1lR4DT8UrNJ9uLAydVJTEpbh0%7C7839d95b7b5600e704b148fff0e58e9d685ee63b600dd96dc29fa6670155aa84'
            ),
            ));

            $response = curl_exec($curl);
            var_dump($response);
            die;

            curl_close($curl);
            $this->session->set_userdata('name', $name);
            $this->session->set_userdata('url', $url);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Data has been changed! <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            // print_r($data);
            redirect('C_user');
        }
    }

    // public function changePassword()
    // {
    //     $data['title'] = 'Change Password';
    //     $this->load->view('V_backend/templates/header', $data);
    //     $this->load->view('V_backend/templates/sidebar');
    //     $this->load->view('V_backend/templates/topbar');
    //     $this->load->view('V_backend/pages/user/change-password', $data);
    //     $this->load->view('V_backend/templates/footer');    
    // }

    public function changePassword()
    {
        $data['title'] = 'Change Password';
        // $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user'] = $this->session->userdata();
        //Function dibawah ini adalah apa saja yang dibutuhkan untuk mengganti password
        // $this->form_validation->set_rules('currentPassword', 'Current Password', 'required|trim');
        $this->form_validation->set_rules('new_password', 'new password', 'required|trim|min_length[3]|matches[newPassword2]');
        $this->form_validation->set_rules('newPassword2', 'new password', 'required|trim|min_length[3]|matches[new_password]');
        //min_length[3] adalah jumlah digit password minimal 3 digit.

        if ($this->form_validation->run() == false) {
            $this->load->view('V_backend/templates/header', $data);
            $this->load->view('V_backend/templates/sidebar');
            $this->load->view('V_backend/templates/topbar');
            $this->load->view('V_backend/pages/user/change-password', $data);
            $this->load->view('V_backend/templates/footer');  
        } else {
            //jika password salah
            $curl = curl_init();
            $username = $this->session->userdata('username');
            $password = $this->input->post('password');
            $new_password = $this->input->post('new_password');
            
            curl_setopt_array($curl, array(
            CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/users/changepassword?username=".$username."&password=".$password."&new_password=".$new_password."",

            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_HTTPHEADER => array(
                'Cookie: tk_ai=jetpack%3AKSBPXv170RYnbmLuhVjvnAMa; wordpress_logged_in_0b733380a7e602c77d80b550b6596847=testacc1%7C1628049450%7CmlZsLzwTS5GccrdBO5G0GO4OY3M3u2TCh75seb9vinP%7Ca0d6c732d262a686cbd12263b6fd04a50f3194f7724567ea7d92a299e2f4a02c'
            ),
            ));

            $response = curl_exec($curl);
            $existUser = json_decode($response);
            if($existUser->code===200){
                $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">'.$existUser->msg.' </div>');
            }
            else{
                $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">'.$existUser->msg.' </div>');
            }
            curl_close($curl);
            redirect('C_user/changepassword');
        } 
    }
    // public function changePassword()
    // {
    //     $data['title'] = 'Change Password';
    //     $data['user'] = $this->session->userdata();
    //     //Function dibawah ini adalah apa saja yang dibutuhkan untuk mengganti password
    //     $this->form_validation->set_rules('currentPassword', 'Current Password', 'required|trim');
    //     $this->form_validation->set_rules('newPassword1', 'New Password', 'required|trim|min_length[3]|matches[newPassword2]');
    //     $this->form_validation->set_rules('newPassword2', 'Confirm New Password', 'required|trim|min_length[3]|matches[newPassword1]');
    //     //min_length[3] adalah jumlah digit password minimal 3 digit.

    //     if ($this->form_validation->run() == false) {
    //         $data['title'] = 'Change Password';
    //         $this->load->view('V_backend/templates/header', $data);
    //         $this->load->view('V_backend/templates/sidebar');
    //         $this->load->view('V_backend/templates/topbar');
    //         $this->load->view('V_backend/pages/user/change-password', $data);
    //         $this->load->view('V_backend/templates/footer');  
    //     } else {
    //         //jika password salah
    //         $id = $this->input->post('id');
    //         $username = $this->input->post('username');
    //         $currentPassword = $this->input->post('currentPassword');
    //         $newPassword = $this->input->post('newPassword1');
    //         $curl = curl_init();
    //         curl_setopt_array($curl, array(
    //             CURLOPT_URL => "https://beta.hops.id/wp-json/wp/v2/users/?".$id."?password=".$password."",
    //             CURLOPT_RETURNTRANSFER => true,
    //             CURLOPT_ENCODING => "",
    //             CURLOPT_MAXREDIRS => 10,
    //             CURLOPT_TIMEOUT => 0,
    //             CURLOPT_FOLLOWLOCATION => true,
    //             CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    //             CURLOPT_CUSTOMREQUEST => "PUT",
    //             CURLOPT_HTTPHEADER => array(
    //             "username: " . $username,
    //             "password: " . $newPassword,
    //             "Cookie: wordpress_logged_in_45d7f6c9d55265d57c136b000dfb6996=akhil%7C1605515826%7CVJtSv8uoLQw4FmOStvNN7pZptROxv1m3UdqBXGljNZx%7C51cb5edece4195ccf662f7ac7e8651bcd7d98ed97c8ce7706a126ab37fc200b2"
    //             ),
    //         ));
    //         // var_dump($response);
    //         // die;
    //             $existUser = json_decode($response);
    //             // var_dump($response);
    //             // die;
    //             curl_close($curl);
    //                 //jika password baru sama dengan password lama, maka akan terjadi error password.
    //                 if ($currentPassword == $newPassword) {
    //                     $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">New password cannot be
    //                     the same as current password! </div>');
    //                     redirect('user/changepassword');
    //                 } else {
    //                     //password sudah benar
    //                     $password_hash = password_hash($newPassword, PASSWORD_DEFAULT);
    
                        
    //                     $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">Password changed! </div>');
    //                     redirect('C_user/changepassword');
    //                 }
                
    //     }
        
    }