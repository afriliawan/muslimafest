<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_auth extends CI_Controller 
{

    public function index()
	{
        $this->form_validation->set_rules('username','Username','trim|required');
        $this->form_validation->set_rules('password','Password','trim|required');

        if ($this->form_validation->run() == false){
            $data['title'] = 'Halaman Login';
            // $this->load->view('V_auth/templates/auth_header', $data);
            $this->load->view('V_auth/pages/login');
            // $this->load->view('V_auth/templates/auth_footer');

        } else {
            //validasi sukses
            $this->_login(); //_login adalah method private
        }
    }

    private function _login()
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://beta.hops.id/wp-json/custom-plugin/login?username=".$this->input->post('username')."&password=".$this->input->post('password')."",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
            // "Cookie: wordpress_logged_in_45d7f6c9d55265d57c136b000dfb6996=akhil%7C1605513163%7CQ9PUdGYstcqnerWsgLoPvyEh4AHFhTDjoNU7a3BMkXZ%7Cac05f4a950fd0f571e115ccab300b47a7df41c50bebb07556865c92dc2efd068"
        ),
        ));

        $response = curl_exec($curl);
        // $user = $this->db->get_where('users', ['username' => $username])->row_array();

        //Untuk mengetahui data array apa saja yang tersedia
        $existUser = json_decode($response);
        var_dump($response);
        die;
        // print_r($existUser);
        // print_r($isExistUser['data'];
        // var_dump($existUser->data->ID);
        // die;

        //Mengecek data user berdasarkan ID
        if($existUser->data->ID) {
            $data = [
                //MAPPING SEBELUM MENGAMBIL DATA UNTUK DITAMPILKAN DI VIEW
                //Mengambil data user berdasarkan email (session)
                'id' => $existUser->data->ID,
                'email' => $existUser->data->user_email,
                'name' => $existUser->data->display_name,
                'password' => $existUser->data->user_pass,
                //Mengambil data user berdasarkan username (session)
                'username' => $existUser->data->user_login,
                //No Rek
                'description' => $existUser->data->description,
                'nickname' => $existUser->data->nickname,
            ];
            // var_dump($data);
            $this->session->set_userdata($data);
            // echo 'TEST'; print_r($this->session->all_userdata());exit;
            // die;
            $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">Berhasil login ! Selamat datang.</div>');
            redirect('C_user');
        } else {
            $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Password salah!</div>');
            redirect('C_auth');
        }
        // } else {
        //     $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Email is not registered!</div>');
        //     redirect('C_auth');
        // }
    }

    public function registration()
    {
        // $this->form_validation->set_rules('full_name', 'Full name', 'required|regex_match[/[a-zA-Z]$/]'); //trim berfungsi agar spasi tidak masuk kedalam database
        $this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[6]|max_length[12]'); //trim berfungsi agar spasi tidak masuk kedalam database
        // $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[ms_users.email]', [ 
        //     'is_unique' => 'This email has been registered!'
        // ]); //is_unique[user.email] agar tidak bisa mendaftarkan email yg sudah ada di dalam database
        $this->form_validation->set_rules('password1', 'Password', 'required|trim|min_length[6]|matches[password2]',[
            'matches' => 'Password dont match !',
            'min_length' => 'Password too short !'
        ]);
        $this->form_validation->set_rules('password2', 'Password', 'required|trim|matches[password1]');

        if ($this->form_validation->run() == false) {
            // $data['title'] = 'Hops User Registration';
            // $this->load->view('V_auth/templates/auth_header');
            $this->load->view('V_auth/pages/registration');
            // $this->load->view('V_auth/templates/auth_footer');
        } else {
            $curl = curl_init();
            curl_setopt_array($curl, array(
            CURLOPT_URL => "https://www.hops.id/wp-json/wp/v2/users?username=".$this->input->post('username')."&name=".$this->input->post('username')."&email=".$this->input->post('email')."&password=".$this->input->post('password1')."",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_HTTPHEADER => array(
                "Authorization: Basic YWtoaWw6d2hpNWk4MF5rUjlrSWFUYSY4IShFOVgk"
            ),
            ));
    
            $response = curl_exec($curl);
    
            curl_close($curl);

            $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">Congratulation! Your account has been
            created. Please login.</div>');
            redirect('C_auth');
        }
    }

    public function _sendEmail($token, $type)
    {
        //untuk mengirim email melalui google
        //465 adalah port google
        $config = [
            'protocol'  => 'smtp',
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_user' => 'hopsid.noreply@gmail.com',
            'smtp_pass' => 'smagawi333',
            'smtp_port' => 465,
            'mailtype'  => 'html',
            'charset'   => 'utf-8',
            'newline'   => "\r\n"
        ];

        //$config masuk kedalam parameter library
        // $this->load->library('email', $config);
        $this->email->initialize($config);

        $this->email->from('hopsid.noreply@gmail.com', 'HopsID');
        $this->email->to($this->input->post('email'));

        if ($type == 'verify') {
            $this->email->subject('Verifikasi Akun');
            $this->email->message('Klik link dibawah ini untuk aktivasi akun Anda : <a href="'. base_url() . 'C_auth/verify?email=' . $this->input->post('email') . '&token=' . urlencode($token) . '">Aktifkan</a>');
        } else if ($type == 'forgot') {
            $this->email->subject('Reset Password');
            $this->email->message('Klik link dibawah untuk reset akun Anda: <a href="'. base_url() . 'C_auth/resetPassword?email=' . $this->input->post('email') . '&token=' . urlencode($token) . '">Reset Password</a>');
        }
        
        if ($this->email->send()) {
            return true;
        } else {
            echo $this->email->print_debugger();
            die;
        }

    }

    public function verify()
    {
        $email = $this->input->get('email');
        $token = $this->input->get('token');

        $user = $this->db->get_where('ms_users', ['email' => $email])->row_array(); //satu baris saja

        if($user) {
            $user_token = $this->db->get_where('ms_users_token', ['token' => $token])->row_array();
            if ($user_token) {
                if ($user_token[strtotime('date_created')] < (60 * 60 * 1)) {
                    $this->db->set('is_active', 1);
                    $this->db->where('email', $email);
                    $this->db->update('ms_users');

                    $this->db->delete('ms_users_token', ['email' => $email]);

                    $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">' . $email . ' berhasil diaktifkan. Silahkan login.</div>');
                    redirect('C_auth');
                }
            } else {
                $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Verifikasi akun gagal! Token tidak valid.</div>');
                redirect('C_auth');
            }
        } else {
            $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Verifikasi akun gagal! Email tidak valid.</div>');
            redirect('C_auth');
        }
    }

    
    public function forgotPassword()
    {
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');

        //jika salah
        if ($this->form_validation->run() == false) {
            $data['title'] = 'Forgot Password';
            // $this->load->view('V_auth/templates/auth_header', $data);
            $this->load->view('V_auth/pages/forgot-password');
            // $this->load->view('V_auth/templates/auth_footer');
        } else {
            $email = $this->input->post('email');
            $user = $this->db->get_where('ms_users', ['email' => $email, 'is_active' => 1]) -> row_array();

            if($user) {
                $token = base64_encode(random_bytes(32));
                $user_token = [
                    'email'         => $email,
                    'token'         => $token,
                    'date_created'  => time()
                ];

                $this->db->insert('ms_users_token', $user_token);
                $this->_sendEmail($token, 'forgot');
                $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">Please check your email to reset your password!</div>');
                redirect('C_auth/forgotPassword');

            } else {
                //jika email tidak terdaftar atau belum di aktifkan
                $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Email is not registered or activated!</div>');
                redirect('C_auth/forgotPassword');
            }
        }
    }

    
    public function resetPassword()
    {
        $email = $this->input->get('email');
        $token = $this->input->get('token');

        $user = $this->db->get_where('ms_users', ['email' => $email])->row_array();

        if($user) {
            $user_token = $this->db->get_where('ms_users_token', ['token' => $token])->row_array();

            if ($user_token){
                $this->session->set_userdata('reset_email', $email);
                $this->changePassword();
            }else {
                $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Reset password failed! Wrong token.</div>');
                redirect('C_auth');
            }

        } else {
            //jika user mengubah email secara asal pada URL
            $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Reset password failed! Wrong email.</div>');
            redirect('C_auth');
        }
    }

    public function changePassword() 
    {
        //agar user tidak sembarangan ganti password tanpa lewat email
        if (!$this->session->userdata('reset_email')) {
            redirect ('C_auth');
        }
        
        $this->form_validation->set_rules('password1', 'Password', 'trim|required|min_length[3]|matches[password2]');
        $this->form_validation->set_rules('password2', 'Repeat Password', 'trim|required|min_length[3]|matches[password1]');

        if($this->form_validation->run() == false){
            $data['title'] = 'Change Password';
            // $this->load->view('V_auth/templates/auth_header', $data);
            $this->load->view('V_auth/pages/change-password'); 
            // $this->load->view('V_auth/templates/auth_footer');
        } else {
            $password = password_hash($this->input->post('password1'), PASSWORD_DEFAULT);
            $email = $this->session->userdata('reset_email');

            $this->db->set('password', $password);
            $this->db->where('email', $email);
            $this->db->update('ms_users');

            $this->session->unset_userdata('reset_email');
            $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">Password berhasil diubah. Silahkan login!</div>');
            redirect('C_auth');       
        }
    }

    public function logout()
    {
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('username');
        // $this->session->unset_userdata('role_id');

        $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">You have been logged out!</div>');
        redirect('C_auth');
    }

    public function blocked() 
    {
        $this->load->view('V_auth/pages/blocked');
    }
}